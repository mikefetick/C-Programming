﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleApplicationDemo.WebReferenceDemo;

namespace ConsoleApplicationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Service1 wsd = new Service1(); //This is the name of your web service.

            Console.WriteLine("Enter First Number: ");
            int fNum = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter Second Number: ");
            int sNum = Convert.ToInt32(Console.ReadLine());
            
            int result = wsd.AddNumbers(fNum, sNum);
            
            Console.WriteLine("Result of is {0}", result);
        }
    }
}
