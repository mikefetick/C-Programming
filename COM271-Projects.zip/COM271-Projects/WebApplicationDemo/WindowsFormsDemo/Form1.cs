﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WindowsFormsDemo.WebReferenceDemo;

namespace WindowsFormsDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Service1 servDem = new Service1();
            int value1 = Convert.ToInt32(FirstText.Text);
            int value2 = Convert.ToInt32(SecondText.Text);
            int result = servDem.AddNumbers(value1, value2);
            txtResult.Text = result.ToString();        
        }
    }
}
