﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Practical Exercise 3 -
 *  "Implement a standalone serialization module 
 *   based on the XML code in Lesson 13 of the Student Manual."
 * Date: 22 April 2014
 */
using System;
using System.Collections;
using System.Text;
using System.IO;
using System.Xml;

namespace PE3
{
    class XmlExample
    {
        [STAThread]
        static void Main()
        {
            // The resulting transactions.xml file
            WriteXmlTransactions(@".\transactions.txt",
                                @".\transactions.xml");

            System.Console.WriteLine("\n\nPress ENTER to continue.");
            System.Console.ReadLine();
        }
        
        private static void WriteXmlTransactions(string fileInputName, 
                                                   string fileXmlName)
        {
            string name = string.Empty;
            object obj = null;
            int custId = 0;
            CustomerInfo c = null;

            Hashtable customers = null;

            CreateCustomerHashtable create = new CreateCustomerHashtable();

            customers = 
                create.CreateCustomerHashTableProcess(@"customers.txt");

            if (customers == null)
            { return; }

            string input_value = string.Empty;

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.NewLineOnAttributes = false;

            XmlWriter writer = XmlWriter.Create(fileXmlName, settings);
            writer.WriteStartDocument();
            writer.WriteStartElement("transactions");

            try
            {
                using (FileStream fs = 
                    new FileStream(fileInputName, FileMode.Open))
                {
                    using (StreamReader sr = 
                        new StreamReader(fs, Encoding.UTF8))
                    {
                        input_value = sr.ReadLine();

                        while (input_value != null)
                        {
                            try
                            {
                              string[] info = input_value.Split(',');

                              writer.WriteStartElement("transaction");

                              writer.WriteStartElement("account");
                              writer.WriteAttributeString("number", info[0]);
                              writer.WriteAttributeString("type", info[2]);

                              writer.WriteEndElement();

                              writer.WriteStartElement("customer");
                              writer.WriteAttributeString("id", info[1]);

                              custId = Int32.Parse(info[1]);

                                if (customers.ContainsKey(custId.ToString()))
                                {
                                    obj = customers[custId.ToString()];

                                    if (obj != null)
                                    {
                                        c = (CustomerInfo)obj;

                                        name = c.CustomerName;
                                    }
                                }
                                else
                                {
                                    name = "XXXXXXXXXX";
                                }

                              writer.WriteAttributeString("name", name);
                              writer.WriteEndElement();

                              writer.WriteElementString("amount", info[3]);
                              writer.WriteElementString("transactiontype", 
                                  info[4]);

                                writer.WriteEndElement();
                            }    

                            catch (ArgumentException ex)
                            {
                                Console.WriteLine("ERROR  : " + 
                                    "ArgumentException");
                                Console.WriteLine("MESSAGE: " + ex.Message);
                            }

                            finally
                            { }
                            input_value = sr.ReadLine();
                        }
                    }
                }
            }

            catch (System.IO.FileNotFoundException ex)
            {
                Console.WriteLine("ERROR  : " + "FileNotFoundException");
                Console.WriteLine("MESSAGE: " + ex.Message);
            }

            catch (System.ArgumentException ex)
            {
                Console.WriteLine("ArgumentException");
                Console.WriteLine("\n   SOURCE      : " + ex.Source);
                Console.WriteLine("\n   MESSAGE     : " + ex.Message);
                Console.WriteLine("\n   TARGET SITE : " + ex.TargetSite);
                Console.WriteLine("\n   STACK TRACE : " + ex.StackTrace);
            }

            finally
            {
                //
            }

            writer.WriteEndDocument();

            writer.Flush();
            writer.Close();
        }
    }
}
/*

Press ENTER to continue.

----
Here is the transactions.xml file in the debug directory, which includes the transaction data of the customer:

<?xml version="1.0" encoding="utf-8"?>
<transactions>
  <transaction>
    <account number="22222222" type="1" />
    <customer id="3" name="George Of The Jungle" />
    <amount>1000</amount>
    <transactiontype>1</transactiontype>
  </transaction>
  <transaction>
    <account number="22222222" type="1" />
    <customer id="3" name="George Of The Jungle" />
    <amount>4000</amount>
    <transactiontype>1</transactiontype>
  </transaction>
  <transaction>
    <account number="22222222" type="1" />
    <customer id="3" name="George Of The Jungle" />
    <amount>3000</amount>
    <transactiontype>2</transactiontype>
  </transaction>
  <transaction>
    <account number="11111111" type="1" />
    <customer id="8" name="Edgardo Fernandez" />
    <amount>12000</amount>
    <transactiontype>1</transactiontype>
  </transaction>
  <transaction>
    <account number="11111111" type="1" />
    <customer id="8" name="Edgardo Fernandez" />
    <amount>7000</amount>
    <transactiontype>1</transactiontype>
  </transaction>
  <transaction>
    <account number="22222222" type="1" />
    <customer id="3" name="George Of The Jungle" />
    <amount>10000</amount>
    <transactiontype>1</transactiontype>
  </transaction>
  <transaction>
    <account number="11111111" type="1" />
    <customer id="3" name="George Of The Jungle" />
    <amount>4000</amount>
    <transactiontype>2</transactiontype>
  </transaction>
  <transaction>
    <account number="11111111" type="1" />
    <customer id="3" name="George Of The Jungle" />
    <amount>3000</amount>
    <transactiontype>1</transactiontype>
  </transaction>
  <transaction>
    <account number="22222222" type="1" />
    <customer id="3" name="George Of The Jungle" />
    <amount>2000</amount>
    <transactiontype>2</transactiontype>
  </transaction>
  <transaction>
    <account number="11111111" type="1" />
    <customer id="8" name="Edgardo Fernandez" />
    <amount>1000</amount>
    <transactiontype>2</transactiontype>
  </transaction>
  <transaction>
    <account number="11111111" type="1" />
    <customer id="8" name="Edgardo Fernandez" />
    <amount>2000</amount>
    <transactiontype>1</transactiontype>
  </transaction>
  <transaction>
    <account number="11111111" type="1" />
    <customer id="8" name="Edgardo Fernandez" />
    <amount>1000</amount>
    <transactiontype>2</transactiontype>
  </transaction>
</transactions>
*/