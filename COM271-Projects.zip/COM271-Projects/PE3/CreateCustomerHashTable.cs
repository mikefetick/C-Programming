﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Practical Exercise 3 -
 *  "Implement a standalone serialization module 
 *   based on the XML code in Lesson 13 of the Student Manual."
 * Date: 22 April 2014
 */
using System;
using System.Collections;
using System.Text;
using System.IO;

namespace PE3
{
    // Build a collection of Key(CustomerID) – Value(CustomerInfo object) pairs.
    class CreateCustomerHashtable
    {
        public Hashtable CreateCustomerHashTableProcess(string file_name)
        {
            Hashtable customers = new Hashtable();

            string input_value = string.Empty;

            CustomerInfo c = null;

            try
            {
                using (FileStream fs = new FileStream(file_name,
                                                      FileMode.Open))
                {
                    using (StreamReader sr = new StreamReader(fs,
                                                              Encoding.UTF8))
                    {
                        // Each Transaction is read
                        input_value = sr.ReadLine();

                        while (input_value != null)
                        {

                            try
                            {
                                string[] info = input_value.Split(',');

                                c = new CustomerInfo();

                                // Look up the CutomerID of the transaction
                                c.CustomerID = Int32.Parse(info[0]);

                                // Add the Customer Name
                                c.CustomerName = info[1];

                                // To build the XML file
                                customers.Add(c.CustomerID.ToString(), c);
                            }

                            catch (ArgumentException ex)
                            {
                                Console.WriteLine("ERROR  : " + 
                                    "ArgumentException");
                                Console.WriteLine("MESSAGE: " + ex.Message);
                            }

                            finally
                            { }

                            input_value = sr.ReadLine();

                        }
                    }
                }
            }
            catch (System.IO.FileNotFoundException ex)
            {
                Console.WriteLine("\nERROR  : " + "FileNotFoundException");
                Console.WriteLine("MESSAGE: " + ex.Message);
            }

            catch (System.ArgumentException ex)
            {
                Console.WriteLine("\nERROR  : " + "ArgumentException");
                Console.WriteLine("\n   SOURCE      : " + ex.Source);
                Console.WriteLine("\n   MESSAGE     : " + ex.Message);
                Console.WriteLine("\n   TARGET SITE : " + ex.TargetSite);
                Console.WriteLine("\n   STACK TRACE : " + ex.StackTrace);
            }

            finally
            {
                //
            }

            return customers;
        }
    }
}
/*
Compile to .dll

*/