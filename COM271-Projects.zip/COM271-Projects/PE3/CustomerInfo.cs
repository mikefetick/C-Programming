﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Practical Exercise 3 -
 *  "Implement a standalone serialization module 
 *   based on the XML code in Lesson 13 of the Student Manual."
 * Date: 22 April 2014
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace PE3
{
    // The XML structure is yet another data format.
    [System.Xml.Serialization.XmlRootAttribute()]
    
    class CustomerInfo
    {
        private int customer_id;
        private string customer_name;

        public int CustomerID
        {
            set { this.customer_id = value; }
            get { return this.customer_id; }
        }

        public string CustomerName
        {
            set { this.customer_name = value; }
            get { return this.customer_name; }
        }
    }
}
/*
Compile to .dll

*/