﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Practical Exercise 3 -
 *  "Implement a standalone serialization module 
 *   based on the XML code in Lesson 13 of the Student Manual."
 * Date: 22 April 2014
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace PE3
{
    // XML Serialization highlights
    [System.Xml.Serialization.XmlRootAttribute()]

    public class Employee
    {
        private string name;
        private DateTime dateOfHire;
        private decimal baseSalary;
        private int longevity;

        // XML Serialization highlights
        [XmlElementAttribute]
        public string Name
        {
            set { this.name = value; }
            get { return this.name; }
        }

        // XML Serialization highlights
        [XmlElementAttribute(ElementName = "DATEOFHIRE")]
        public DateTime DateOfHire
        {
            set { this.dateOfHire = value; }
            get { return this.dateOfHire; }
        }

        public decimal BaseSalary
        {
            set { this.baseSalary = value; }
            get { return this.baseSalary; }
        }

        public override string ToString()
        {
            CalculateLongevity();

            return this.name + " began to work in " + this.dateOfHire.Year +
                " and has worked for " + this.longevity.ToString() +
                " years.";
        }

        private void CalculateLongevity()
        {
            this.longevity = DateTime.Now.Year - this.dateOfHire.Year;

            if (this.dateOfHire.AddYears(
                DateTime.Now.Year - this.dateOfHire.Year) > DateTime.Now)
            {
                this.longevity--;
            }
        }
    }
}
/*
Compile: 

csc.exe /t:library /out:Employee.dll Employee.cs
*/