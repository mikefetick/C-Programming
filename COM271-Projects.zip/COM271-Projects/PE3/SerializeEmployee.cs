﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Practical Exercise 3 -
 *  "Implement a standalone serialization module 
 *   based on the XML code in Lesson 13 of the Student Manual."
 * Date: 22 April 2014
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace PE3
{
    public class SerializeEmployee
    {
        static void Main2()
        {
            //WriteEmployee("c:\\c#files\\com271\\lesson13\\employee.xml");
            WriteEmployee(@".\employee.xml");

            //DisplayEmployee("c:\\c#files\\com271\\lesson13\\employee.xml");
            DisplayEmployee(@".\employee.xml");

            System.Console.WriteLine("\n\nPress ENTER to continue.");
            System.Console.ReadLine();
        }

        private static void WriteEmployee(string fileName)
        {
            Employee employee = new Employee();

            employee.Name = "Freddie The Freeloader";
            employee.DateOfHire = DateTime.Parse("12/12/1997 12:01:02 PM");
            employee.BaseSalary = 75000M;

            TextWriter tr = new StreamWriter(fileName);

            XmlSerializer sr = new XmlSerializer(typeof(Employee));

            sr.Serialize(tr, employee);
            tr.Close();
        }

        private static void DisplayEmployee(string fileName)
        {
            Employee employee = null;

            employee = ReadEmployee(fileName);

            if (employee != null)
            {
                System.Console.WriteLine("Name .........: " + employee.Name);

                System.Console.WriteLine("Date Of Hire .: " +
                   employee.DateOfHire.ToShortDateString());

                System.Console.WriteLine("Base Salary ..: {0:C}",
                   employee.BaseSalary);

                System.Console.WriteLine(employee.ToString());
            }
        }

        private static Employee ReadEmployee(string fileName)
        {
            Employee employee = null;

            FileStream fs = new FileStream(fileName, FileMode.Open);

            XmlSerializer xs = new XmlSerializer(typeof(Employee));

            employee = (Employee)xs.Deserialize(fs);

            fs.Close();

            return employee;
        }
    }
}
/*
Name .........: Freddie The Freeloader
Date Of Hire .: 12/12/1997
Base Salary ..: $75,000.00
Freddie The Freeloader began to work in 1997 and has worked for 16 years.


Press ENTER to continue.

---
Here is the employee.xml file in the debug directory, which is written in ‘well formed’ XML:

<?xml version="1.0" encoding="utf-8"?>
<Employee xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
  <Name>Freddie The Freeloader</Name>
  <DATEOFHIRE>1997-12-12T12:01:02</DATEOFHIRE>
  <BaseSalary>75000</BaseSalary>
</Employee>
*/