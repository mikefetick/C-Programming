﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SecondProgram
{
    class MoreVars
    {
        int data;
        const int MAX = 20; //Constant variables need to be initialized
        public readonly int MIN;  //Page 125

        //To create objects with thier own information then use non-static variables
        //To create objects with the same information globally, then use static variables
        static int count = 0;

        public int Data
        {
            get 
            { 
                return data; 
            }
            set 
            {
                if (value > MAX)
                {
                    value = MAX;
                }
                data = value;
            }
        }

        public MoreVars()
        {
            count++;
        }

        public MoreVars(int dValue, int min)
        {
            Data = dValue;
            MIN = min;
            count++;
        }

        /// <summary>
        /// Static methods cannot call a non-static method, i.e. Display
        /// </summary>
        public static void DisplayCount()
        {
            Console.WriteLine("Total number of objects are: {0}", count);
        }

        /// <summary>
        /// Non-static methods can call a static method, i.e. DisplayCount
        /// </summary>
        public void Display()
        {
            Console.WriteLine("Data = {0}", Data);
            Console.WriteLine("MIN = {0}", MIN);
            Console.WriteLine("MAX = {0}", MAX);
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            MoreVars myObj = new MoreVars();
            myObj.Data = 56;
            myObj.Display();

            MoreVars newObj = new MoreVars(14, 5);
            newObj.Display();

            MoreVars otherObj = new MoreVars(7, 3);
            otherObj.Display();

            //For a static method, 
            //use the Class name as its qualifier, instead of the object name
            MoreVars.DisplayCount();
        }
    }
}
