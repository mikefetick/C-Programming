﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 12)
 * Date: 24-27 March 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project1
{
    class Client
    {
        // Declare instance variables. All have private scope
        static ConsoleKeyInfo cki;  // for Console.ReadKey reponse returned 

        // Lists can be sorted easier than arrays, if sorting is later implemented
        // One universal list was considered but three separate lists affords to the separate methods
        static List<FullTimeEmployee> fulltimePersonnel = new List<FullTimeEmployee>(); // FullTimeEmployee objects
        static List<PartTimeEmployee> parttimePersonnel = new List<PartTimeEmployee>(); // PartTimeEmployee objects
        static List<Consultant>     consultantPersonnel = new List<Consultant>();       // Consultant objects
        
        static void CreateHourlyEmployee()
        {
            // Instantiate object
            PartTimeEmployee employeeObj = new PartTimeEmployee();

            // Unique Prompt for user data
            Console.WriteLine("\n\n  Employee Record:\n  1. Type: \tPart-time");

            // Call method to prompt user for data
            PopulateEmployee(employeeObj);

            // Continue to prompt user for data
            Console.Write("  7. Wage:   \t$");
            employeeObj.HourlyRate  = (float) Convert.ToDecimal(Console.ReadLine());
            Console.Write("  8. Hours:  \t");
            employeeObj.HoursWorked = (float) Convert.ToDecimal(Console.ReadLine());

            // Call method to Add element to List<PartTimeEmployee>
            parttimePersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateSalaryEmployee()
        {
            // Instantiate object
            FullTimeEmployee employeeObj = new FullTimeEmployee();

            // Unique Prompt for user data
            Console.WriteLine("\n\n  Employee Record:\n  1. Type: \tFull-time");

            // Call method to prompt user for data
            PopulateEmployee(employeeObj);

            // Continue to prompt user for data
            Console.Write("  7. Salary: \t$");
                employeeObj.Salary = (float) Convert.ToDecimal(Console.ReadLine());

            // Call method to Add element to List<FullTimeEmployee>
            fulltimePersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateConsultant()
        {
            // Instantiate object
            Consultant employeeObj = new Consultant();

            // Unique Prompt for user data
            Console.WriteLine("\n\n  Employee Record:\n  1. Type: \tConsultant");

            // Call method to prompt user for data
            PopulateEmployee(employeeObj);

            // Continue to prompt user for data
            Console.Write("  7. Wage:   \t$");
            employeeObj.HourlyRate  = (float) Convert.ToDecimal(Console.ReadLine());
            Console.Write("  8. Hours:  \t");
            employeeObj.HoursWorked = (float) Convert.ToDecimal(Console.ReadLine());

            // Call method to Add element to List<Consultant>
            consultantPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);       
        }

        static void PopulateEmployee(Employee employeeObj)
        {
            // Prompt user for data
            Console.Write("  2. ID:     \t");
                employeeObj.IdNumber = Console.ReadLine();

            Console.Write("  3. Name:   \t"); 
                employeeObj.Name = Console.ReadLine();

            Console.Write("  4. Hired:  \t{0}", DateTime.Now.ToShortDateString());
            string userInput = "";
            userInput = Console.ReadLine();
            if (userInput == "")
            {
                userInput = DateTime.Now.ToShortDateString();
            }
            employeeObj.DateOfHire = Convert.ToDateTime(userInput);

            Console.Write("  5. Address:\t"); 
                employeeObj.Street = Console.ReadLine();

            Console.Write("  6. Zipcode:\t");
                employeeObj.Zipcode = Convert.ToInt32(Console.ReadLine());
        }

        static void DisplayPersonnelReport()
        {
            Console.WriteLine("\n\nTotals:\t\t\tPersonnel Report (All Employees)");

            // Tally of FullTimeEmployee
            Console.WriteLine("\n({0}) Full-time Employees - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                fulltimePersonnel.Count());
            Console.WriteLine(" ID   \tName \tHired \t  Address \tZip \tSalary \tPay");

            // Loop through elements of personnel array for objects of FullTimeEmployee
            foreach (FullTimeEmployee fullTimeEmployee in fulltimePersonnel)
            {
                // Not implemented - Would be needed for finding an employee type in a 'universal' list
                //if (fullTimeEmployee.GetType().ToString().Equals("Project1.FullTimeEmployee"))
                //{
                    //fullTimeEmployee(Display);
                    Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}\t${6:C.2}",
                        fullTimeEmployee.IdNumber.ToString(),
                        fullTimeEmployee.Name,
                        fullTimeEmployee.DateOfHire.ToShortDateString(),
                        fullTimeEmployee.Street,
                        fullTimeEmployee.Zipcode.ToString(),
                        fullTimeEmployee.Salary.ToString(),
                        (fullTimeEmployee.Salary / 52).ToString());  // Calculate weekly pay from annual salary
                //}
            }

            // Tally of PartTimeEmployee
            Console.WriteLine("\n({0}) Part-time Employees - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                parttimePersonnel.Count());
            Console.WriteLine(" ID    \tName \tHired \t  Address \tZip \tWage \tHours \tPay");

            // Loop through elements of personnel array for objects of FullTimeEmployee
            foreach (PartTimeEmployee partTimeEmployee in parttimePersonnel)
            {
                // Not implemented - Would be needed for finding an employee type in a 'universal' list
                //if (partTimeEmployee.GetType().ToString().Equals("Project1.PartTimeEmployee"))
                //{
                    //partTimeEmployee(Display);
                    Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                        partTimeEmployee.IdNumber.ToString(),
                        partTimeEmployee.Name,
                        partTimeEmployee.DateOfHire.ToShortDateString(),
                        partTimeEmployee.Street,
                        partTimeEmployee.Zipcode.ToString(),
                        partTimeEmployee.HourlyRate.ToString(),
                        partTimeEmployee.HoursWorked.ToString(),
                        partTimeEmployee.RegTimePay.ToString());
                //}
            }

            // Tally of Consultant
            Console.WriteLine("\n({0}) Consultants - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                consultantPersonnel.Count());
            Console.WriteLine(" ID    \tName \tHired \t  Address \tZip \tWage \tHours \tPay \tFee");

            // Loop through elements of personnel array for objects of FullTimeEmployee
            foreach (Consultant consultant in consultantPersonnel)
            {
                // Not implemented - Would be needed for finding an employee type in a 'universal' list
                //if (consultant.GetType().ToString().Equals("Project1.Consultant"))
                //{
                    //consultant(Display);
                    Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}\t${8:C.2}",
                        consultant.IdNumber.ToString(),
                        consultant.Name,
                        consultant.DateOfHire.ToShortDateString(),
                        consultant.Street,
                        consultant.Zipcode.ToString(),
                        consultant.HourlyRate.ToString(),
                        (consultant.HoursWorked + consultant.ExtraHours).ToString(),  // Add together all hours worked
                        consultant.RegTimePay.ToString(),
                        consultant.ConsultantFee.ToString());
                //}
            }
            Console.WriteLine("\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
        }

        static void Main(string[] args)
        {
            
            // Interact with the user at the console with defaults: System, standard out, standard in
            Console.WriteLine("\n  Project 1 - Michael Fetick, 84270");

            bool wantToQuit = false; // default
            do
            {
                // Do-while not wantToQuit (loop)
                if (!wantToQuit)
                {
                    // Prompt user to select employee type
                    Console.WriteLine
                        ("\n  Employee types: 'F' Full-time, 'P' Part-time, 'C' Consultant,");
                    Console.Write
                        ("  Enter letter for employee type or 'Q' to quit: ");

                    // The reponse returned from Console.ReadKey is a ConsoleKeyInfo type,
                    //  refer to the ConsoleKey Enumeration set for values
                    cki = Console.ReadKey();

                    // Switch-Case to match employee type {F, P, C}, fall-through is used, 
                    // call method to prompt user to populate fields of the object;
                    // or quit {Q}. 
                    switch (cki.KeyChar)
                    {
                        case 'F': // Full-time employee
                        case 'f': CreateSalaryEmployee();
                            break;

                        case 'P': // Part-time employee
                        case 'p': CreateHourlyEmployee();

                            break;
                        
                        case 'C': // Consultant employee
                        case 'c': CreateConsultant();
                            break;
                        
                        case 'Q': // Quit and display tally of employee types
                        case 'q':
                            wantToQuit = true; // quit program
                            DisplayPersonnelReport();
                            break;
                        
                        default:
                            break;
                    }
                }
            } while (!wantToQuit);
        }
    }
}
