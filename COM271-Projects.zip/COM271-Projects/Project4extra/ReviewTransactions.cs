﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: 
 * Practical Exercise 4 - GUI App of ATM Machine
 *   With two images of inserting ATM Card, each
 *   with unique card number and pin table lookup.
 * 
 *   Extended from Lesson 19 - Winforms (Student Manual, page 122)
 *   A Windows Form Application that will allow you 
 *   to review the Deposits and Withdrawals 
 *   for a specified Customer Account.
 *
 * Date: 24 April 2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Project4_ATM
{
    public partial class ReviewTransactions : Form
    {
        decimal totalDeposits = 0.00M;
        decimal totalWithdrawals = 0.00M;

        public static SqlConnection GetConnectionAtLocalhost()
        {
            //  Create... Connection
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            /* TO CONNECT AT HOME - LOCALHOST
             */
            builder.DataSource = @"(localdb)\Projects";
            builder.InitialCatalog = "db84270";
            builder.IntegratedSecurity = true;
            builder.ConnectTimeout = 30;
            builder.Encrypt = false;
            builder.TrustServerCertificate = false;
            //
            return new SqlConnection(builder.ConnectionString);
        }

        public static SqlConnection GetConnectionAtNetwork()
        {
            //  Create... Connection
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            /* TO CONNECT AT SCHOOL - COLEMAN UNIVERSITY
             */
            builder.DataSource = "172.16.2.34";
            builder.UserID = "db84270";
            builder.InitialCatalog = "db84270";
            builder.Password = "5a0c1de0";
            //
            return new SqlConnection(builder.ConnectionString);
        }
        public ReviewTransactions()
        {
            InitializeComponent();
            // Display the window in the center of the screen
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        public SqlConnection CreateConnection()
        {
            SqlConnection connection;
            if (ckbConnection.Checked)
            {
                // Call method to get connection at localhost for test purpose
                connection = GetConnectionAtLocalhost();
            }
            else
            {
                // Call method to get connection at network for production purpose
                connection = GetConnectionAtNetwork();
            }
            //SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

        // Call with parameter of Customer Number from user input
        public string GetCustomerName(int custId)
        {
            string name = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Build query string to get customer Name
            string query = @"
                SELECT customer_name 
                FROM customers_t
                WHERE customer_id = " + custId.ToString();

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                name = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("You must enter a Customer Number",
                  "Invalid Customer Number");
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                    connection = null;
            }
            return name;
        }

        // Call with parameter of Account Number from user input
        public string GetATMcardNumber(string acctKey)
        {
            string cardNumber = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Build query string to get customer card number
            string query = @"
                SELECT card_number 
                FROM ATMCard_t
                WHERE account_number = '" + acctKey + "'";

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                cardNumber = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("You must enter a valid Account Number",
                  "Invalid Account Number");
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }

            return cardNumber;
        }

        // Call with parameter of Account Number from user input
        public string GetATMpinNumber(string acctKey)
        {
            string pinNumber = String.Empty;

            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Build query string to get customer card PIN
            string query = @"
                SELECT pin 
                FROM ATMCard_t
                WHERE account_number = '" + acctKey + "'";

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                pinNumber = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("You must enter a valid ATM PIN",
                  "Invalid ATM PIN");
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }

            return pinNumber;
        }

        // Call with parameters of Customer Number and Account Number 
        //  from user input
        public string GetAccountNumber(int custId, string acctType)
        {
            string accountNumber = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Build query string to get customer account number
            string query = @"
                SELECT account_number 
                FROM accounts_t
                WHERE customer_id = '" + custId.ToString() 
                   + "' AND account_type = '" + acctType + "'";
            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                accountNumber = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("You must enter a valid Customer Number",
                  "Invalid Customer Number");
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }

            return accountNumber;
        }

        // Call with parameter of Account Number from user input
        public void PopulateListBox(string acct_num)
        {
            totalDeposits = 0.00M;
            totalWithdrawals = 0.00M;

            string strAmount = string.Empty;

            lstTransactions.Items.Clear();
            lstTransactions.BeginUpdate();

            SqlDataAdapter da = null;
            DataSet ds = null;
            DataTable dt = null;

            // Build query string to get transaction_type and amount
            string query = @"
                SELECT transaction_type, amount
                FROM transactions_t
                WHERE account_number = " + acct_num;

            SqlConnection connection = CreateConnection();
            connection.Open();

            // The keyword using() can get the database to handle the SQL exceptions.
            //using (da = new SqlDataAdapter(query, connection))
            //using (ds = new DataSet())

            // When a data record is missing a foreign key, then a SQL exception of 
            // "Object reference not set to an instance of an object" is thrown...
            // A try-catch block can handle the SQL exceptions.
            try
            {
                da = new SqlDataAdapter(query, connection);
                ds = new DataSet();

                da.Fill(ds, "transactions_t");
                dt = ds.Tables["transactions_t"];

                lstTransactions.Items.Add("Deposits".PadLeft(19) +
                    "Withdrawals".PadLeft(14));

                foreach (DataRow row in dt.Rows)
                {
                    if (row["transaction_type"].Equals("D"))
                    {
                        totalDeposits += Convert.ToDecimal(row["amount"]);

                        strAmount = string.Format("{0:N}", row["amount"]);
                        lstTransactions.Items.Add(strAmount.PadLeft(19));
                    }
                    else
                    {
                        totalWithdrawals += Convert.ToDecimal(row["amount"]);

                        strAmount = string.Format("{0:N}", row["amount"]);
                        lstTransactions.Items.Add("".PadLeft(19) +
                             strAmount.PadLeft(14));
                    }
                }

                lstTransactions.Items.Add("Total:" +
                    string.Format("{0:N}", totalDeposits).PadLeft(13) +
                    string.Format("{0:N}", totalWithdrawals).PadLeft(14));

                lstTransactions.EndUpdate();
            }
            catch (SqlException sqlEx)
            {
                //MessageBox.Show(sqlEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                lstTransactions.EndUpdate();
            }
        }
        // For Connected Objects
        public void SubmitTransaction(string p_account_number, 
                                      string p_amount, 
                                      string p_transaction_type)
        {
            //string aDate = DateTime.Now.ToShortDateString() + " "
            //             + DateTime.Now.ToLongTimeString();
            string aDate = "GETDATE()";
            // Build a query to insert a record into transactions_t 
            string aRecord = string.Format("({0},{1},'{2}',{3})",
                             p_account_number, 
                             p_amount, 
                             p_transaction_type, 
                             aDate);
            // Build query string to insert a transaction
            string query = @"INSERT INTO transactions_t "
                         + "(account_number, "
                         + "amount, "
                         + "transaction_type, "
                         + "last_date_modified)"
                         + " VALUES " + aRecord;

            SqlConnection connection = CreateConnection();
            connection.Open();

            // A try-catch block can handle the SQL exceptions.
            try
            {
                SqlCommand sc = new SqlCommand(query, connection);
                sc.ExecuteNonQuery();
                //Create the SqlCommand to execute the Insert Sql statement.
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show(sqlEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (!txtCustomerNumber.Text.Equals(String.Empty)
             && !txtPINnumber.Text.Equals(String.Empty))
            {

                int id = Convert.ToInt32(this.txtCustomerNumber.Text);

                string acctType = String.Empty;

                if (rbChecking.Checked)
                {
                    acctType = "C";
                }
                else
                {
                    acctType = "S";
                }

                // Call method GetCustomerName(id)
                lblCustName.Text = GetCustomerName(id);

                // Call method GetAccountNumber(id, acctType)
                lblAccountNumber.Text = GetAccountNumber(id, acctType);

                //Call method to add items to the ListBox
                PopulateListBox(lblAccountNumber.Text);

                // If account exists, enable the group to do a transaction
                if (lstTransactions.Items.Count > 0)
                {
                    gbxTransaction.Enabled = true;
                }
                else
                {
                    gbxTransaction.Enabled = false;
                }
            }
            else
            {
                // If the textbox is empty, 
                // then no entry was accepted before this button was pressed
                MessageBox.Show("You must enter a Customer Number and an ATM Card PIN",
                  "No Customer Number");
            }
        }

        private void ReviewTransactions_Load(object sender, EventArgs e)
        {
            btnReset.Visible = false;
            txtCustomerNumber.Select();
            gbxAccount.Enabled = false;
        }

        private void pbox1_Click(object sender, EventArgs e)
        {
            gbxAccount.Enabled = true;
            lblChooseAcct.Visible = true;
            pbox1.Visible = false;
            pbox2.Visible = false;
            pbox1.Enabled = false;
            pbox2.Enabled = false;
            txtCustomerNumber.Text = "3";
            lblImages.Visible = false;
            btnReset.Visible = true;
            lblATMCard.Visible = true;
            lblATMCardNumber.Visible = true;
            lblATMCardNumber.Text = GetATMcardNumber(GetAccountNumber(3, "C"));
            lblPIN.Visible = true;
            txtPINnumber.Visible = true;
            txtPINnumber.Text = GetATMpinNumber(GetAccountNumber(3, "C"));
            btnDisplay_Click(sender, e);
        }

        private void pbox2_Click(object sender, EventArgs e)
        {
            gbxAccount.Enabled = true;
            lblChooseAcct.Visible = true;
            pbox1.Visible = false;
            pbox2.Visible = false;
            pbox1.Enabled = false;
            pbox2.Enabled = false;
            txtCustomerNumber.Text = "7";
            lblImages.Visible = false;
            btnReset.Visible = true;
            lblATMCard.Visible = true;
            lblATMCardNumber.Visible = true;
            lblATMCardNumber.Text = GetATMcardNumber(GetAccountNumber(7, "C"));
            lblPIN.Visible = true;
            txtPINnumber.Visible = true;
            txtPINnumber.Text = GetATMpinNumber(GetAccountNumber(7, "C"));
            btnDisplay_Click(sender, e);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            gbxAccount.Enabled = false;
            lblChooseAcct.Visible = false;
            lstTransactions.Items.Clear();
            btnReset.Visible = false;
            lblATMCard.Visible = false;
            lblATMCardNumber.Visible = false;
            lblPIN.Visible = false;
            txtPINnumber.Visible = false;
            lblImages.Visible = true;
            txtCustomerNumber.Text = "";
            lblAccountNumber.Text = "";
            lblCustName.Text = "";
            txtAmount.Text = "";
            gbxTransaction.Enabled = false;
            pbox1.Visible = true;
            pbox2.Visible = true;
            pbox1.Enabled = true;
            pbox2.Enabled = true;
        }

        #region CreateTransactionNumber()
        private string CreateTransactionNumber()
        {
            string maxTransactionNumber = "";
            int lastTransactionNumber = 0;
            string newTransactionNumber = "";
            SqlCommand command = null;

            // Referred to http://technet.microsoft.com/en-us/library/ms187751.aspx
            string query = @"SELECT MAX(transaction_number) AS Expr1 FROM transactions_t";
            try
            {
                command = new SqlCommand(query, CreateConnection());

                maxTransactionNumber = command.ExecuteScalar().ToString();
                //newTransactionNumber = Convert.ToString(maxTransactionNumber + 10);

                lastTransactionNumber = Convert.ToInt32(maxTransactionNumber);
                newTransactionNumber = Convert.ToString(lastTransactionNumber + 10);
            }

            catch (SqlException ex)
            {
                Console.WriteLine("Error     : " + "SqlException");
                Console.WriteLine("Message   : " + ex.Message);
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error     : " + "Exception");
                Console.WriteLine("Message   : " + ex.Message);
            }

            finally
            {
                command = null;
            }

            return newTransactionNumber;
        }
        #endregion

        private void btnCommit_Click(object sender, EventArgs e)
        {
            if (!txtAmount.Text.Equals(String.Empty))
            {
                // Initialize class variables
                decimalCount = 0;
                centDigitCount = 0;

                //int amt = Convert.ToInt32(this.txtAmount.Text);
                decimal amt = Convert.ToDecimal(this.txtAmount.Text);
                string transType = String.Empty;

                if (rbDeposit.Checked)
                {
                    // Deposit transaction
                    transType = "D";

                    // Submit transaction record into table
                    //SubmitTransaction(CreateTransactionNumber(),
                    SubmitTransaction(lblAccountNumber.Text,
                                      txtAmount.Text,
                                      transType);
                }
                else
                {
                    // Withdrawal transaction
                    transType = "W";

                    // Compare account balance to withdrawal amount 
                    // to approve transaction
                    if (amt <= (totalDeposits - totalWithdrawals))
                    {
                        // TBD - If approved, build insert query 
                        // Submit transaction record into table
                        //SubmitTransaction(CreateTransactionNumber(),
                        SubmitTransaction(lblAccountNumber.Text,
                                          txtAmount.Text,
                                          transType);
                    }
                    else
                    {
                        MessageBox.Show("You cannot withdrawal more than your balance.",
                          "Insufficient Funds");
                    }
                }
                // Display account info after transaction
                PopulateListBox(lblAccountNumber.Text);
            }
            else
            {
                MessageBox.Show("You must enter a Customer Number",
                  "No Customer Number");
            }
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            if (!txtAmount.Text.Equals(String.Empty))
            {
                btnCommit.Enabled = true;
            } else
            {
                btnCommit.Enabled = false;
            }
        }

        // Validate numeric entry during KeyDown and enabled during KeyPress. 
        // Boolean flag used to determine when a character other than a number is entered. 
        private bool nonNumberEntered;

        // Initialize these counts to flag and validate cent digits
        private int decimalCount = 0;
        private int centDigitCount = 0;
        private Keys previousKey;

        // Retrieved from MSDN at
        // http://msdn.microsoft.com/en-us/library/system.windows.forms.control.keypress%28v=vs.110%29.aspx

        // Handle the KeyDown event to determine the type of character entered into the control. 
        private bool NonNumberEntered(object sender, KeyEventArgs e)
        {
            // Initialize the flag to false.
            nonNumberEntered = false;

            // Determine whether the keystroke is a decimal point. 
            if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
            {
                decimalCount++;
                // Limit decimalCount <= 1
                if (decimalCount > 1)
                {
                    nonNumberEntered = true;
                    decimalCount--;
                }
            }
            else
            {
                // Determine whether the keystroke is a number from the top of the keyboard. 
                if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
                {
                    // Determine whether the keystroke is a number from the keypad. 
                    if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                    {
                        // Determine whether the keystroke is a backspace. 
                        if (e.KeyCode != Keys.Back)
                        {
                            // A non-numerical keystroke was pressed. 
                            nonNumberEntered = true;
                        }
                        else
                        {
                            // A backspace deletes the previous entry and...
                            // Was there previously either a decimal point or an OemPeriod (regional)?
                            if (previousKey == Keys.Decimal || previousKey == Keys.OemPeriod)
                            {
                                decimalCount--;
                            }
                            else
                            {
                                // Determine whether the cents digits are started. 
                                if (centDigitCount > 0)
                                {
                                    centDigitCount--;
                                }
                            }
                        }
                    }
                }
                //If shift key was pressed, it's not a number. 
                if (Control.ModifierKeys == Keys.Shift)
                {
                    nonNumberEntered = true;
                }
            }
            if (!nonNumberEntered && decimalCount == 1)
            {
                // Limit centDigitCount <= 2
                if (centDigitCount <= 2)
                {
                    centDigitCount++;
                }
                else
                {
                    nonNumberEntered = true;
                    centDigitCount--;
                }
            }
            if (!nonNumberEntered)
            {
                previousKey = e.KeyCode;
            }
            return nonNumberEntered;
        }

        // Typically, if the KeyChar(0x08) is handled instead of the Key.Back then the KeyDown event method 
        // is not needed and the code can be combined into the KeyPress event method. 
        //
        // Handle the KeyDown event to determine the type of character entered into the control. 
        private void txtCustomerNumber_KeyDown(object sender, KeyEventArgs e)
        {
            // Call the method to determine if NonNumberEntered
            if (NonNumberEntered(sender, e))
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }
            else
            {
                // Allow the character to be entered into the control since it is numerical.
                e.Handled = false;
            }
        }
        // Continue after the KeyDown event...
        // Handle the KeyPress event to prevent characters from entering the control. 
        private void txtCustomerNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check for the flag being set in the KeyDown event. 
            if (nonNumberEntered == true)
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }
        }

        // Handle the KeyDown event to determine the type of character entered into the control. 
        private void txtAmount_KeyDown(object sender, KeyEventArgs e)
        {
            // Call the method to determine if NonNumberEntered
            if (NonNumberEntered(sender, e))
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }
            else
            {
                // Allow the character to be entered into the control since it is numerical.
                e.Handled = false;
            }
        }
        // Continue after the KeyDown event...
        // Handle the KeyPress event to prevent characters from entering the control. 
        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check for the flag being set in the KeyDown event. 
            if (nonNumberEntered == true)
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }
        }

        private void rbDeposit_CheckedChanged(object sender, EventArgs e)
        {
            clearTxtAmount();
         }

        private void rbWithdrawal_CheckedChanged(object sender, EventArgs e)
        {
            clearTxtAmount();
        }

        private void clearTxtAmount()
        {
            txtAmount.Text = "";
            decimalCount = 0;
            centDigitCount = 0;
        }

        private void txtCustomerNumber_TextChanged(object sender, EventArgs e)
        {
            lblCustName.Text = "";
            lblAccountNumber.Text = "";
            txtAmount.Text = "";
            txtPINnumber.Text = "";
            lblATMCardNumber.Text = "";
            lstTransactions.Items.Clear();
        }
    }
}
/*
Note: When you execute this program, only customers 3 and 7 
      have transactions recorded in the database. 
      Only customer 3 has a Checking and a Savings account.
      Customer 7 has only a Checking account.

*/