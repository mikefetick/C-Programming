﻿namespace Project4_ATM
{
    partial class ReviewTransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstTransactions = new System.Windows.Forms.ListBox();
            this.txtCustomerNumber = new System.Windows.Forms.TextBox();
            this.lblCustomerNumber = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblCustName = new System.Windows.Forms.Label();
            this.lblAcctNumber = new System.Windows.Forms.Label();
            this.lblAccountNumber = new System.Windows.Forms.Label();
            this.gbxAccount = new System.Windows.Forms.GroupBox();
            this.rbSavings = new System.Windows.Forms.RadioButton();
            this.rbChecking = new System.Windows.Forms.RadioButton();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pbox2 = new System.Windows.Forms.PictureBox();
            this.pbox1 = new System.Windows.Forms.PictureBox();
            this.lblImages = new System.Windows.Forms.Label();
            this.lblATMCardNumber = new System.Windows.Forms.Label();
            this.lblATMCard = new System.Windows.Forms.Label();
            this.lblPIN = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.gbxTransaction = new System.Windows.Forms.GroupBox();
            this.btnCommit = new System.Windows.Forms.Button();
            this.rbWithdrawal = new System.Windows.Forms.RadioButton();
            this.lblAmount = new System.Windows.Forms.Label();
            this.rbDeposit = new System.Windows.Forms.RadioButton();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.ckbConnection = new System.Windows.Forms.CheckBox();
            this.lblChooseAcct = new System.Windows.Forms.Label();
            this.txtPINnumber = new System.Windows.Forms.TextBox();
            this.gbxAccount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox1)).BeginInit();
            this.gbxTransaction.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstTransactions
            // 
            this.lstTransactions.FormattingEnabled = true;
            this.lstTransactions.Location = new System.Drawing.Point(50, 237);
            this.lstTransactions.Name = "lstTransactions";
            this.lstTransactions.Size = new System.Drawing.Size(346, 147);
            this.lstTransactions.TabIndex = 0;
            // 
            // txtCustomerNumber
            // 
            this.txtCustomerNumber.Location = new System.Drawing.Point(134, 19);
            this.txtCustomerNumber.MaxLength = 6;
            this.txtCustomerNumber.Name = "txtCustomerNumber";
            this.txtCustomerNumber.Size = new System.Drawing.Size(39, 20);
            this.txtCustomerNumber.TabIndex = 1;
            this.txtCustomerNumber.Text = "3";
            this.txtCustomerNumber.TextChanged += new System.EventHandler(this.txtCustomerNumber_TextChanged);
            this.txtCustomerNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCustomerNumber_KeyDown);
            this.txtCustomerNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCustomerNumber_KeyPress);
            // 
            // lblCustomerNumber
            // 
            this.lblCustomerNumber.AutoSize = true;
            this.lblCustomerNumber.Location = new System.Drawing.Point(6, 23);
            this.lblCustomerNumber.Name = "lblCustomerNumber";
            this.lblCustomerNumber.Size = new System.Drawing.Size(122, 13);
            this.lblCustomerNumber.TabIndex = 2;
            this.lblCustomerNumber.Text = "Enter Customer Number:";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(5, 94);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(54, 13);
            this.lblCustomer.TabIndex = 3;
            this.lblCustomer.Text = "Customer:";
            // 
            // lblCustName
            // 
            this.lblCustName.AutoSize = true;
            this.lblCustName.Location = new System.Drawing.Point(65, 94);
            this.lblCustName.Name = "lblCustName";
            this.lblCustName.Size = new System.Drawing.Size(27, 13);
            this.lblCustName.TabIndex = 4;
            this.lblCustName.Text = "cust";
            // 
            // lblAcctNumber
            // 
            this.lblAcctNumber.AutoSize = true;
            this.lblAcctNumber.Location = new System.Drawing.Point(6, 112);
            this.lblAcctNumber.Name = "lblAcctNumber";
            this.lblAcctNumber.Size = new System.Drawing.Size(90, 13);
            this.lblAcctNumber.TabIndex = 5;
            this.lblAcctNumber.Text = "Account Number:";
            // 
            // lblAccountNumber
            // 
            this.lblAccountNumber.AutoSize = true;
            this.lblAccountNumber.Location = new System.Drawing.Point(102, 112);
            this.lblAccountNumber.Name = "lblAccountNumber";
            this.lblAccountNumber.Size = new System.Drawing.Size(28, 13);
            this.lblAccountNumber.TabIndex = 6;
            this.lblAccountNumber.Text = "acct";
            // 
            // gbxAccount
            // 
            this.gbxAccount.Controls.Add(this.rbSavings);
            this.gbxAccount.Controls.Add(this.rbChecking);
            this.gbxAccount.Controls.Add(this.btnDisplay);
            this.gbxAccount.Controls.Add(this.lblCustomerNumber);
            this.gbxAccount.Controls.Add(this.txtCustomerNumber);
            this.gbxAccount.Controls.Add(this.lblCustomer);
            this.gbxAccount.Controls.Add(this.lblCustName);
            this.gbxAccount.Controls.Add(this.lblAcctNumber);
            this.gbxAccount.Controls.Add(this.lblAccountNumber);
            this.gbxAccount.Location = new System.Drawing.Point(51, 97);
            this.gbxAccount.Name = "gbxAccount";
            this.gbxAccount.Size = new System.Drawing.Size(184, 128);
            this.gbxAccount.TabIndex = 7;
            this.gbxAccount.TabStop = false;
            this.gbxAccount.Text = "Account";
            // 
            // rbSavings
            // 
            this.rbSavings.AutoSize = true;
            this.rbSavings.Location = new System.Drawing.Point(98, 46);
            this.rbSavings.Name = "rbSavings";
            this.rbSavings.Size = new System.Drawing.Size(58, 17);
            this.rbSavings.TabIndex = 1;
            this.rbSavings.TabStop = true;
            this.rbSavings.Text = "Saving";
            this.rbSavings.UseVisualStyleBackColor = true;
            // 
            // rbChecking
            // 
            this.rbChecking.AutoSize = true;
            this.rbChecking.Checked = true;
            this.rbChecking.Location = new System.Drawing.Point(18, 46);
            this.rbChecking.Name = "rbChecking";
            this.rbChecking.Size = new System.Drawing.Size(70, 17);
            this.rbChecking.TabIndex = 0;
            this.rbChecking.TabStop = true;
            this.rbChecking.Text = "Checking";
            this.rbChecking.UseVisualStyleBackColor = true;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(53, 65);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(75, 23);
            this.btnDisplay.TabIndex = 8;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(321, 398);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "ATM MACHINE";
            // 
            // pbox2
            // 
            this.pbox2.BackgroundImage = global::Project4_ATM.Properties.Resources.ATMcard2;
            this.pbox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbox2.Location = new System.Drawing.Point(321, 58);
            this.pbox2.Name = "pbox2";
            this.pbox2.Size = new System.Drawing.Size(75, 50);
            this.pbox2.TabIndex = 12;
            this.pbox2.TabStop = false;
            this.pbox2.Click += new System.EventHandler(this.pbox2_Click);
            // 
            // pbox1
            // 
            this.pbox1.BackgroundImage = global::Project4_ATM.Properties.Resources.ATMcard1;
            this.pbox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbox1.Location = new System.Drawing.Point(241, 58);
            this.pbox1.Name = "pbox1";
            this.pbox1.Size = new System.Drawing.Size(74, 50);
            this.pbox1.TabIndex = 11;
            this.pbox1.TabStop = false;
            this.pbox1.Click += new System.EventHandler(this.pbox1_Click);
            // 
            // lblImages
            // 
            this.lblImages.AutoSize = true;
            this.lblImages.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImages.Location = new System.Drawing.Point(54, 38);
            this.lblImages.Name = "lblImages";
            this.lblImages.Size = new System.Drawing.Size(333, 17);
            this.lblImages.TabIndex = 13;
            this.lblImages.Text = "Choose an image to simulate inserting an ATM card";
            // 
            // lblATMCardNumber
            // 
            this.lblATMCardNumber.AutoSize = true;
            this.lblATMCardNumber.Location = new System.Drawing.Point(346, 68);
            this.lblATMCardNumber.Name = "lblATMCardNumber";
            this.lblATMCardNumber.Size = new System.Drawing.Size(27, 13);
            this.lblATMCardNumber.TabIndex = 15;
            this.lblATMCardNumber.Text = "num";
            this.lblATMCardNumber.Visible = false;
            // 
            // lblATMCard
            // 
            this.lblATMCard.AutoSize = true;
            this.lblATMCard.Location = new System.Drawing.Point(249, 68);
            this.lblATMCard.Name = "lblATMCard";
            this.lblATMCard.Size = new System.Drawing.Size(98, 13);
            this.lblATMCard.TabIndex = 14;
            this.lblATMCard.Text = "ATM Card Number:";
            this.lblATMCard.Visible = false;
            // 
            // lblPIN
            // 
            this.lblPIN.AutoSize = true;
            this.lblPIN.Location = new System.Drawing.Point(249, 92);
            this.lblPIN.Name = "lblPIN";
            this.lblPIN.Size = new System.Drawing.Size(28, 13);
            this.lblPIN.TabIndex = 16;
            this.lblPIN.Text = "PIN:";
            this.lblPIN.Visible = false;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(59, 58);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(172, 23);
            this.btnReset.TabIndex = 18;
            this.btnReset.Text = "Reset ATM Card";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // gbxTransaction
            // 
            this.gbxTransaction.Controls.Add(this.btnCommit);
            this.gbxTransaction.Controls.Add(this.rbWithdrawal);
            this.gbxTransaction.Controls.Add(this.lblAmount);
            this.gbxTransaction.Controls.Add(this.rbDeposit);
            this.gbxTransaction.Controls.Add(this.txtAmount);
            this.gbxTransaction.Enabled = false;
            this.gbxTransaction.Location = new System.Drawing.Point(241, 116);
            this.gbxTransaction.Name = "gbxTransaction";
            this.gbxTransaction.Size = new System.Drawing.Size(155, 111);
            this.gbxTransaction.TabIndex = 9;
            this.gbxTransaction.TabStop = false;
            this.gbxTransaction.Text = "Transaction";
            // 
            // btnCommit
            // 
            this.btnCommit.Enabled = false;
            this.btnCommit.Location = new System.Drawing.Point(34, 71);
            this.btnCommit.Name = "btnCommit";
            this.btnCommit.Size = new System.Drawing.Size(75, 23);
            this.btnCommit.TabIndex = 20;
            this.btnCommit.Text = "Commit";
            this.btnCommit.UseVisualStyleBackColor = true;
            this.btnCommit.Click += new System.EventHandler(this.btnCommit_Click);
            // 
            // rbWithdrawal
            // 
            this.rbWithdrawal.AutoSize = true;
            this.rbWithdrawal.Location = new System.Drawing.Point(72, 18);
            this.rbWithdrawal.Name = "rbWithdrawal";
            this.rbWithdrawal.Size = new System.Drawing.Size(78, 17);
            this.rbWithdrawal.TabIndex = 1;
            this.rbWithdrawal.TabStop = true;
            this.rbWithdrawal.Text = "Withdrawal";
            this.rbWithdrawal.UseVisualStyleBackColor = true;
            this.rbWithdrawal.CheckedChanged += new System.EventHandler(this.rbWithdrawal_CheckedChanged);
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(23, 48);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(46, 13);
            this.lblAmount.TabIndex = 19;
            this.lblAmount.Text = "Amount:";
            // 
            // rbDeposit
            // 
            this.rbDeposit.AutoSize = true;
            this.rbDeposit.Checked = true;
            this.rbDeposit.Location = new System.Drawing.Point(9, 19);
            this.rbDeposit.Name = "rbDeposit";
            this.rbDeposit.Size = new System.Drawing.Size(61, 17);
            this.rbDeposit.TabIndex = 0;
            this.rbDeposit.TabStop = true;
            this.rbDeposit.Text = "Deposit";
            this.rbDeposit.UseVisualStyleBackColor = true;
            this.rbDeposit.CheckedChanged += new System.EventHandler(this.rbDeposit_CheckedChanged);
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(75, 45);
            this.txtAmount.MaxLength = 6;
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(57, 20);
            this.txtAmount.TabIndex = 8;
            this.txtAmount.TextChanged += new System.EventHandler(this.txtAmount_TextChanged);
            this.txtAmount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAmount_KeyDown);
            this.txtAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmount_KeyPress);
            // 
            // ckbConnection
            // 
            this.ckbConnection.AutoSize = true;
            this.ckbConnection.Location = new System.Drawing.Point(57, 402);
            this.ckbConnection.Name = "ckbConnection";
            this.ckbConnection.Size = new System.Drawing.Size(129, 17);
            this.ckbConnection.TabIndex = 19;
            this.ckbConnection.Text = "Localhost Connection";
            this.ckbConnection.UseVisualStyleBackColor = true;
            // 
            // lblChooseAcct
            // 
            this.lblChooseAcct.AutoSize = true;
            this.lblChooseAcct.Location = new System.Drawing.Point(84, 84);
            this.lblChooseAcct.Name = "lblChooseAcct";
            this.lblChooseAcct.Size = new System.Drawing.Size(140, 13);
            this.lblChooseAcct.TabIndex = 20;
            this.lblChooseAcct.Text = "Or choose another account:";
            this.lblChooseAcct.Visible = false;
            // 
            // txtPINnumber
            // 
            this.txtPINnumber.Location = new System.Drawing.Point(283, 88);
            this.txtPINnumber.MaxLength = 4;
            this.txtPINnumber.Name = "txtPINnumber";
            this.txtPINnumber.Size = new System.Drawing.Size(35, 20);
            this.txtPINnumber.TabIndex = 21;
            this.txtPINnumber.Visible = false;
            // 
            // ReviewTransactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 466);
            this.Controls.Add(this.pbox1);
            this.Controls.Add(this.txtPINnumber);
            this.Controls.Add(this.lblChooseAcct);
            this.Controls.Add(this.ckbConnection);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblPIN);
            this.Controls.Add(this.lblATMCardNumber);
            this.Controls.Add(this.lblATMCard);
            this.Controls.Add(this.lblImages);
            this.Controls.Add(this.pbox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lstTransactions);
            this.Controls.Add(this.gbxTransaction);
            this.Controls.Add(this.gbxAccount);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ReviewTransactions";
            this.Text = "Project 4 - ATM";
            this.Load += new System.EventHandler(this.ReviewTransactions_Load);
            this.gbxAccount.ResumeLayout(false);
            this.gbxAccount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox1)).EndInit();
            this.gbxTransaction.ResumeLayout(false);
            this.gbxTransaction.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstTransactions;
        private System.Windows.Forms.TextBox txtCustomerNumber;
        private System.Windows.Forms.Label lblCustomerNumber;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblCustName;
        private System.Windows.Forms.Label lblAcctNumber;
        private System.Windows.Forms.Label lblAccountNumber;
        private System.Windows.Forms.GroupBox gbxAccount;
        private System.Windows.Forms.RadioButton rbSavings;
        private System.Windows.Forms.RadioButton rbChecking;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbox1;
        private System.Windows.Forms.PictureBox pbox2;
        private System.Windows.Forms.Label lblImages;
        private System.Windows.Forms.Label lblATMCardNumber;
        private System.Windows.Forms.Label lblATMCard;
        private System.Windows.Forms.Label lblPIN;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.GroupBox gbxTransaction;
        private System.Windows.Forms.RadioButton rbWithdrawal;
        private System.Windows.Forms.RadioButton rbDeposit;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Button btnCommit;
        private System.Windows.Forms.CheckBox ckbConnection;
        private System.Windows.Forms.Label lblChooseAcct;
        private System.Windows.Forms.TextBox txtPINnumber;
    }
}

