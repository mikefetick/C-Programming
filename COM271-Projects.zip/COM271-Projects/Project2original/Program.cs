﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 2 - Student Handbook (Pages 46)
 * Date: 31 March 2014 - 7 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Payroll
{
    class Client
    {
        // Declare instance variables. All have private scope
        static ConsoleKeyInfo cki;  // for Console.ReadKey reponse returned 

        // Lists can be sorted easier than arrays, if sorting is later implemented
        static List<SalariedEmployee> salariedPersonnel = new List<SalariedEmployee>(); // SalariedEmployee objects
        static List<HourlyEmployee> hourlyPersonnel = new List<HourlyEmployee>(); // HourlyEmployee objects
        static List<CommissionEmployee> commissionPersonnel = new List<CommissionEmployee>();       // CommissionEmployee objects
        
        static void CreateHourlyEmployee()
        {
            // Instantiate object
            HourlyEmployee employeeObj = new HourlyEmployee();

            // Unique Prompt for user data
            Console.WriteLine("\n\n  Employee Record:\n  1. Type: \tPart-time");

            // Call method to prompt user for data
            PopulateEmployee(employeeObj);

            // Continue to prompt user for data
            Console.Write("  7. Wage:   \t$");
            employeeObj.HourlyRate  = (float) Convert.ToDecimal(Console.ReadLine());
            Console.Write("  8. Hours:  \t");
            employeeObj.HoursWorked = (float) Convert.ToDecimal(Console.ReadLine());

            // Call method to Add element to List<HourlyEmployee>
            hourlyPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateSalariedEmployee()
        {
            // Instantiate object
            SalariedEmployee employeeObj = new SalariedEmployee();

            // Unique Prompt for user data
            Console.WriteLine("\n\n  Employee Record:\n  1. Type: \tFull-time");

            // Call method to prompt user for data
            PopulateEmployee(employeeObj);

            // Continue to prompt user for data
            Console.Write("  7. Salary: \t$");
                employeeObj.Salary = (float) Convert.ToDecimal(Console.ReadLine());

            // Call method to Add element to List<SalariedEmployee>
            salariedPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateCommissionEmployee()
        {
            // Instantiate object
            CommissionEmployee employeeObj = new CommissionEmployee();

            // Unique Prompt for user data
            Console.WriteLine("\n\n  Employee Record:\n  1. Type: \tCommissionEmployee");

            // Call method to prompt user for data
            PopulateEmployee(employeeObj);

            // Continue to prompt user for data
            Console.Write("  7. Wage:   \t$");
            employeeObj.HourlyRate  = (float) Convert.ToDecimal(Console.ReadLine());
            Console.Write("  8. Hours:  \t");
            employeeObj.HoursWorked = (float) Convert.ToDecimal(Console.ReadLine());

            // Call method to Add element to List<CommissionEmployee>
            commissionPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);       
        }

        static void PopulateEmployee(Employee employeeObj)
        {
            // Prompt user for data
            Console.Write("  2. ID:     \t");
                employeeObj.IdNumber = Console.ReadLine();

            Console.Write("  3. Name:   \t"); 
                employeeObj.Name = Console.ReadLine();

            Console.Write("  4. Hired:  \t{0}", DateTime.Now.ToShortDateString());
            string userInput = "";
            userInput = Console.ReadLine();
            if (userInput == "")
            {
                userInput = DateTime.Now.ToShortDateString();
            }
            employeeObj.DateOfHire = Convert.ToDateTime(userInput);

            Console.Write("  5. Address:\t"); 
                employeeObj.Street = Console.ReadLine();

            Console.Write("  6. Zipcode:\t");
                employeeObj.Zipcode = Convert.ToInt32(Console.ReadLine());
        }

        static void DisplayPersonnelReport()
        {
            Console.WriteLine("\n\nTotals:\t\t\tPersonnel Report (All Employees)");

            // Tally of SalariedEmployee
            Console.WriteLine("\n({0}) Full-time Employees - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                salariedPersonnel.Count());
            Console.WriteLine(" ID   \tName \tHired \t  Address \tZip \tSalary \tPay");

            // Loop through elements of personnel array for objects of SalariedEmployee
            foreach (SalariedEmployee salariedEmployee in salariedPersonnel)
            {
                Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}\t${6:C.2}",
                    salariedEmployee.IdNumber.ToString(),
                    salariedEmployee.Name,
                    salariedEmployee.DateOfHire.ToShortDateString(),
                    salariedEmployee.Street,
                    salariedEmployee.Zipcode.ToString(),
                    salariedEmployee.Salary.ToString(),
                    (salariedEmployee.Salary / 52).ToString());  // Calculate weekly pay from annual salary
            }

            // Tally of HourlyEmployee
            Console.WriteLine("\n({0}) Part-time Employees - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                hourlyPersonnel.Count());
            Console.WriteLine(" ID    \tName \tHired \t  Address \tZip \tWage \tHours \tPay");

            // Loop through elements of personnel array for objects of SalariedEmployee
            foreach (HourlyEmployee hourlyEmployee in hourlyPersonnel)
            {
                Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                    hourlyEmployee.IdNumber.ToString(),
                    hourlyEmployee.Name,
                    hourlyEmployee.DateOfHire.ToShortDateString(),
                    hourlyEmployee.Street,
                    hourlyEmployee.Zipcode.ToString(),
                    hourlyEmployee.HourlyRate.ToString(),
                    hourlyEmployee.HoursWorked.ToString(),
                    hourlyEmployee.RegTimePay.ToString());
            }

            // Tally of CommissionEmployee
            Console.WriteLine("\n({0}) Consultants - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                commissionPersonnel.Count());
            Console.WriteLine(" ID    \tName \tHired \t  Address \tZip \tWage \tHours \tPay \tFee");

            // Loop through elements of personnel array for objects of SalariedEmployee
            foreach (CommissionEmployee commissionEmployee in commissionPersonnel)
            {
                Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}\t${8:C.2}",
                    commissionEmployee.IdNumber.ToString(),
                    commissionEmployee.Name,
                    commissionEmployee.DateOfHire.ToShortDateString(),
                    commissionEmployee.Street,
                    commissionEmployee.Zipcode.ToString(),
                    commissionEmployee.HourlyRate.ToString(),
                    (commissionEmployee.HoursWorked + commissionEmployee.ExtraHours).ToString(),  // Add together all hours worked
                    commissionEmployee.RegTimePay.ToString(),
                    commissionEmployee.ConsultantFee.ToString());
            }
            Console.WriteLine("\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
        }

        static void Main(string[] args)
        {
            
            // Interact with the user at the console with defaults: System, standard out, standard in
            Console.WriteLine("\n  Project 2 - Michael Fetick, 84270");

            bool wantToQuit = false; // default
            do
            {
                // Do-while not wantToQuit (loop)
                if (!wantToQuit)
                {
                    // Prompt user to select employee type
                    Console.WriteLine
                        ("\n  Employee types: 'S' Salaried, 'H' Hourly, 'C' Commission,");
                    Console.Write
                        ("  Enter letter for employee type or 'Q' to quit: ");

                    // The reponse returned from Console.ReadKey is a ConsoleKeyInfo type,
                    //  refer to the ConsoleKey Enumeration set for values
                    cki = Console.ReadKey();

                    // Switch-Case to match employee type {F, P, C}, fall-through is used, 
                    // call method to prompt user to populate fields of the object;
                    // or quit {Q}. 
                    switch (cki.KeyChar)
                    {
                        case 'S': // Salaried employee
                        case 's': CreateSalariedEmployee();
                            break;

                        case 'H': // Hourly employee
                        case 'h': CreateHourlyEmployee();

                            break;
                        
                        case 'C': // Commission employee
                        case 'c': CreateCommissionEmployee();
                            break;
                        
                        case 'Q': // Quit and display tally of employee types
                        case 'q':
                            wantToQuit = true; // quit program
                            DisplayPersonnelReport();
                            break;
                        
                        default:
                            break;
                    }
                }
            } while (!wantToQuit);
        }
    }
}
