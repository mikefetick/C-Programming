﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 2 - Student Handbook (Pages 46)
 * Date: 31 March 2014 - 7 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Payroll
{
    public class Address1
    {
        private string street;
        public string Street
        {
            get { return street; }
            set { street = value; }
        }
        private int zipcode;
        public int Zipcode
        {
            get { return zipcode; }
            set
            {
                if ((value > 9999) && (value < 100000))
                { zipcode = value; }
                else
                { zipcode = 0; }
            }
        }
        public Address1()
        {
            Street = "Unknown";
            Zipcode = 0;
        }
        public Address1(string streetParm, int zipCodeParm)
        {
            Street = streetParm;
            Zipcode = zipCodeParm;
        }
    }

    public class Employee : Address1
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string idNumber;
        public string IdNumber
        {
            get { return idNumber; }
            set { idNumber = value; }
        }
        private DateTime dateOfHire;
        public DateTime DateOfHire
        {
            get { return dateOfHire; }
            set 
            {
                if (value != null)
                { dateOfHire = value; }
                else
                { dateOfHire = DateTime.Now; }
            }
        }
        /// <summary>
        /// Static constructor cannot be explicitly invoked
        /// </summary>
        static Employee()
        {
            //Console.WriteLine("Static constructor was called.");
        }
        /// <summary>
        /// Non-Static constructor is explicitly invoked
        /// </summary>
        public Employee()
        {
            //Console.WriteLine("Non-Static constructor was invoked.");
        }
        /// <summary>
        /// Overloaded Employee constructor to be explicitly invoked
        /// </summary>
        public Employee(string idParm, string nameParm, DateTime dohParm, 
            string streetParm, int zipCodeParm)
            : base(streetParm, zipCodeParm)
        {
            IdNumber = idParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
        }
    }

    public class SalariedEmployee : Employee
    {
        private float salary;
        public float Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        /// <summary>
        /// Default and Overloaded SalariedEmployee constructors to be explicitly invoked
        /// </summary>
        public SalariedEmployee()
        { Salary = 0; }

        public SalariedEmployee(string idParm, string nameParm, DateTime dohParm, 
                                string streetParm, int zipCodeParm,
                                float salaryParm)
            : base(idParm, nameParm, dohParm, streetParm, zipCodeParm)
        {
            IdNumber = idParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            Salary = salaryParm;
        }
        public void Display(SalariedEmployee employeeObj)
        {
            //SalariedEmployee(Display);
            Console.WriteLine("\n ID    \tName \t  Hired Address \tZip \tSalary \tPay");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}\t${6:C.2}",
                employeeObj.IdNumber.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.Salary.ToString(),
                (employeeObj.Salary / 52).ToString());  // Calculate weekly pay from annual salary
        }
    }

    public class HourlyEmployee : Employee
    {
        const int MINRATE = 8;   // California Minimum Wage Rate
        const int MAXRATE = 50;  // Company Maximum Wage Rate
        const int MINHOURS = 0;  // Minimum Regular Hours Worked per week
        const int MAXHOURS = 40; // Maximum Regular Hours Worked per week

        public int MaxHours  // Maximum Regular Hours Worked per week
        {
            get { return MAXHOURS; }  // Return constant MAXHOURS 
        }

        public int MinHours 
        {
            get { return MINHOURS; }  // Return constant MINHOURS
        }   

        private float hourlyRate;
        public float HourlyRate
        {
            get { return hourlyRate; }
            set
            {
                if ((value >= MINRATE) && (value <= MAXRATE))   // Acceptable wages (CA min, Company max)
                { hourlyRate = value; }
                else
                { hourlyRate = 0; }
            }
        }

        private float hoursWorked;
        public virtual float HoursWorked
        {
            get { return hoursWorked; }
            set
            {
                if ((value >= MinHours) && (value <= 168))   // Accepting valid input of HoursWorked, 24x7=168
                {
                    if (value > MaxHours)   // Hours worked Over maximum regular hours
                    {
                        hoursWorked = value;         // Hours worked as regular hours
                        OverTime = value - MaxHours;  // Hours worked as overtime hours
                        hoursWorked = MaxHours;         // Hours worked as regular hours
                    }
                    else   // Hours worked Under maximum regular hours
                    {
                        hoursWorked = value;            // Hours worked as regular hours
                    }
                }
                else   // Not accepting invalid input of hours worked
                {
                    hoursWorked = 0;
                }
            }
        }

        public float RegTimePay
        {
            get { return HourlyRate * HoursWorked; }
            set { }
        }

        private float overTime;
        public float OverTime
        {
            get { return overTime; }

            // Value is the amount Over the constant MAXHOURS // Maximum Regular Hours Worked per week
            set
            {
                // Calculate the value only if the result will not be negative
                if (HoursWorked <= MaxHours)  // Hours worked weekly as regular time (min:0, max:40)
                { overTime = 0; }

                if (HoursWorked > MaxHours)   // Hours worked weekly over regular time maximum.
                { overTime = HoursWorked - MaxHours; }
            }
        }

        public float OverTimePay  // OverTimePay
        {
            get { return (OverTime * HourlyRate * (float)1.5); }
            set { }
        }

        /// <summary>
        /// Default and Overloaded HourlyEmployee constructors to be explicitly invoked
        /// </summary>
        public HourlyEmployee() { }

        public HourlyEmployee(string idParm, string nameParm, DateTime dohParm, 
                                string streetParm, int zipCodeParm,
                                float hourlyRateParm, float hoursWorkedParm, float regTimePayParm, float overTimeParm, float overTimePayParm)
            : base(idParm, nameParm, dohParm, streetParm, zipCodeParm)
        {
            IdNumber = idParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            HourlyRate = hourlyRateParm;
            HoursWorked = hoursWorkedParm;
            RegTimePay = regTimePayParm;
            OverTime = overTimeParm;
            OverTimePay = overTimePayParm;
        }

        public void Display(HourlyEmployee employeeObj)
        {
            //HourlyEmployee(Display);
            Console.WriteLine("\n ID    \tName \tHired \t  Address \tZip \tWage \tHours \tPay");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                employeeObj.IdNumber.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.HourlyRate.ToString(),
                employeeObj.HoursWorked.ToString(),
                employeeObj.RegTimePay.ToString());
        }
    }

    public class CommissionEmployee : Employee
    {
        private float hoursWorked;
        public override float HoursWorked
        {
            get { return hoursWorked; }
            set
            {
                if ((value >= MinHours) && (value <= 168))   // Accepting valid input of HoursWorked, 24x7=168
                {
                    if (value > MaxHours)   // Hours worked Over maximum regular hours
                    {
                        hoursWorked = value;         // Hours worked as regular hours
                        ExtraHours = value - MaxHours;  // Hours worked as extra hours
                        hoursWorked = MaxHours;         // Hours worked as regular hours
                    }
                    else   // Hours worked Under maximum regular hours
                    {
                        hoursWorked = value;            // Hours worked as regular hours
                    }
                }
                else   // Not accepting invalid input of hours worked
                {
                    hoursWorked = 0;
                }
            }
        }

        private float extraHours;
        public float ExtraHours
        {
            get { return extraHours; }

            // Value is the amount Over the constant MAXHOURS // Maximum Regular Hours Worked per week
            set
            {
                // Calculate the value only if the result will not be negative
                if (HoursWorked <= MaxHours)  // Hours worked weekly as regular time (min:0, max:40)
                { extraHours = 0; }

                if (HoursWorked > MaxHours)   // Hours worked weekly over regular time maximum.
                { extraHours = HoursWorked - MaxHours; }
            }
        }

        public float ConsultantFee  // OverTimePay
        {
            get { return (ExtraHours * HourlyRate * (float) 1.5); }
            set { }
        }

        /// <summary>
        /// Default and Overloaded HourlyEmployee constructors implicitly invoked
        /// </summary>
        public CommissionEmployee() { }

        public CommissionEmployee(string idParm, string nameParm,
                                DateTime dohParm, string streetParm, int zipCodeParm, float hourlyRateParm, float hoursWorkedParm, 
                                float extraHoursParm, float consultantFeeParm, float regTimePayParm)
            : base(idParm, nameParm, dohParm, streetParm, zipCodeParm, hourlyRateParm, hoursWorkedParm, regTimePayParm)
        {
            IdNumber = idParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            HourlyRate = hourlyRateParm;
            HoursWorked = hoursWorkedParm;
            ExtraHours = extraHoursParm;
            ConsultantFee = consultantFeeParm;
        }

        public void Display(CommissionEmployee employeeObj)
        {
            //CommissionEmployee(Display);
            Console.WriteLine("\n ID    \tName \tHired \t  Address \tZip \tWage \tHours \tPay \tFee");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}\t${8:C.2}",
                employeeObj.IdNumber.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.HourlyRate.ToString(),
                (employeeObj.HoursWorked + employeeObj.ExtraHours).ToString(),   // Add together all hours worked
                employeeObj.RegTimePay.ToString(),
                employeeObj.ConsultantFee.ToString());
        }
    }

    public class BasePlusCommissionEmployee : HourlyEmployee
    {
        private float hoursWorked;
        public override float HoursWorked
        {
            get { return hoursWorked; }
            set
            {
                if ((value >= MinHours) && (value <= 168))   // Accepting valid input of HoursWorked, 24x7=168
                {
                    if (value > MaxHours)   // Hours worked Over maximum regular hours
                    {
                        hoursWorked = value;         // Hours worked as regular hours
                        ExtraHours = value - MaxHours;  // Hours worked as extra hours
                        hoursWorked = MaxHours;         // Hours worked as regular hours
                    }
                    else   // Hours worked Under maximum regular hours
                    {
                        hoursWorked = value;            // Hours worked as regular hours
                    }
                }
                else   // Not accepting invalid input of hours worked
                {
                    hoursWorked = 0;
                }
            }
        }

        private float extraHours;
        public float ExtraHours
        {
            get { return extraHours; }

            // Value is the amount Over the constant MAXHOURS // Maximum Regular Hours Worked per week
            set
            {
                // Calculate the value only if the result will not be negative
                if (HoursWorked <= MaxHours)  // Hours worked weekly as regular time (min:0, max:40)
                { extraHours = 0; }

                if (HoursWorked > MaxHours)   // Hours worked weekly over regular time maximum.
                { extraHours = HoursWorked - MaxHours; }
            }
        }

        public float ConsultantFee  // OverTimePay
        {
            get { return (ExtraHours * HourlyRate * (float)1.5); }
            set { }
        }

        /// <summary>
        /// Default and Overloaded HourlyEmployee constructors implicitly invoked
        /// </summary>
        public CommissionEmployee() { }

        public CommissionEmployee(string idParm, string nameParm,
                                DateTime dohParm, string streetParm, int zipCodeParm, float hourlyRateParm, float hoursWorkedParm,
                                float extraHoursParm, float consultantFeeParm, float regTimePayParm)
            : base(idParm, nameParm, dohParm, streetParm, zipCodeParm, hourlyRateParm, hoursWorkedParm, regTimePayParm)
        {
            IdNumber = idParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            HourlyRate = hourlyRateParm;
            HoursWorked = hoursWorkedParm;
            ExtraHours = extraHoursParm;
            ConsultantFee = consultantFeeParm;
        }

        public void Display(BasePlusCommissionEmployee employeeObj)
        {
            //BasePlusCommissionEmployee(Display);
            Console.WriteLine("\n ID    \tName \tHired \t  Address \tZip \tWage \tHours \tPay \tFee");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}\t${8:C.2}",
                employeeObj.IdNumber.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.HourlyRate.ToString(),
                (employeeObj.HoursWorked + employeeObj.ExtraHours).ToString(),   // Add together all hours worked
                employeeObj.RegTimePay.ToString(),
                employeeObj.ConsultantFee.ToString());
        }
    }
}
