﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 2 - Student Handbook (Pages 46)
 * Date: 31 March 2014 - 7 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Payroll
{
    class Client
    {
        // Declare instance variables. All have private scope
        static ConsoleKeyInfo cki;  // for Console.ReadKey reponse returned 

        // Lists can be sorted easier than arrays, if sorting is later implemented
        static List<SalariedEmployee> salariedPersonnel = new List<SalariedEmployee>(); // SalariedEmployee objects
        static List<HourlyEmployee> hourlyPersonnel = new List<HourlyEmployee>(); // HourlyEmployee objects
        static List<CommissionEmployee> commissionPersonnel = new List<CommissionEmployee>();       // CommissionEmployee objects
        static List<BasePlusCommissionEmployee> basePlusCommissionPersonnel = new List<BasePlusCommissionEmployee>();       // BasePlusCommissionEmployee objects
        
        static void CreateHourlyEmployee()
        {
            // Declare the object
            HourlyEmployee employeeObj;
            
            // Prompt for auto-generated data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tHourly Employee \t(Auto-generate data) Y/N? ");
            char input = Convert.ToChar(Console.ReadLine());
            if (input.Equals('Y') || input.Equals('y'))
            {
                // Instantiate the object initialized
                // of HourlyEmployee(ssn, name, doh, earnings, address, zip, rate, regTime, pay, overTime, OTpay)
                employeeObj = new HourlyEmployee("1234", "Jones", DateTime.Parse("04/04/2014"), 0, "123 Blue Dr", 91945, 20, 45, 0, 0, 0);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new HourlyEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data
                Console.Write("  7. Wage:   \t$");
                employeeObj.HourlyRate = (float)Convert.ToDecimal(Console.ReadLine());
                Console.Write("  8. Hours:  \t");
                employeeObj.HoursWorked = (float)Convert.ToDecimal(Console.ReadLine());
            }
                // Call method to Add element to List<HourlyEmployee>
                hourlyPersonnel.Add(employeeObj);

                // Call object's method to display the object
                employeeObj.Display(employeeObj);
        }

        static void CreateSalariedEmployee()
        {
            // Declare the object
            SalariedEmployee employeeObj;

            // Prompt for auto-generated data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tSalaried Employee \t(Auto-generate data) Y/N? ");
            char input = Convert.ToChar(Console.ReadLine());
            if (input.Equals('Y') || input.Equals('y'))
            {
                // Instantiate the object initialized
                // of SalariedEmployee(ssn, name, doh, earnings, address, zip, salary)
                employeeObj = new SalariedEmployee("3456", "Smith", DateTime.Parse("03/03/2013"), 0, "123 Day Ave", 91945, 40000);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new SalariedEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data
                Console.Write("  7. Salary: \t$");
                    employeeObj.Salary = (float) Convert.ToDecimal(Console.ReadLine());
            }
            // Call method to Add element to List<SalariedEmployee>
            salariedPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateCommissionEmployee()
        {
            // Declare the object
            CommissionEmployee employeeObj;

            // Prompt for auto-generated data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tCommission Employee \t(Auto-generate data) Y/N? ");
            char input = Convert.ToChar(Console.ReadLine());
            if (input.Equals('Y') || input.Equals('y'))
            {
                // Instantiate the object initialized
                // of CommissionEmployee(ssn, name, doh, earnings, address, zip, sales made, percent take)
                employeeObj = new CommissionEmployee("5678", "Kramer", DateTime.Parse("02/02/2012"), 0, "555 Man Lane", 91945, 3800, 10);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new CommissionEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data
                Console.Write("  7. Sales:  \t$");
                employeeObj.SalesMade = (float)Convert.ToDecimal(Console.ReadLine());
                Console.Write("  8. %Take:  \t");
                employeeObj.SalesPercent = (float)Convert.ToDecimal(Console.ReadLine());
            }
            // Call method to Add element to List<CommissionEmployee>
            commissionPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateBasePlusCommissionEmployee()
        {
            // Declare the object
            BasePlusCommissionEmployee employeeObj;

            // Unique Prompt for user data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tBase + Commission Employee \t(Auto-generate data) Y/N? ");
            char input = Convert.ToChar(Console.ReadLine());
            if (input.Equals('Y') || input.Equals('y'))
            {
                // Instantiate the object initialized
                // of BasePlusCommissionEmployee(ssn, name, doh, earnings, address, zip, sales made, percent take, salary)
                employeeObj = new BasePlusCommissionEmployee("6789", "Tyler", DateTime.Parse("01/01/2011"), 0, "789 Tree Dr", 91945, 2500, 10, 52000);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new BasePlusCommissionEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data
                Console.Write("  7. Salary: \t$");
                employeeObj.Salary = (float)Convert.ToDecimal(Console.ReadLine());
                Console.Write("  8. Sales:  \t$");
                employeeObj.SalesMade = (float)Convert.ToDecimal(Console.ReadLine());
                Console.Write("  9. %Take:  \t");
                employeeObj.SalesPercent = (float)Convert.ToDecimal(Console.ReadLine());

            }
            // Call method to Add element to List<CommissionEmployee>
            basePlusCommissionPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void PopulateEmployee(Employee employeeObj)
        {
            // Prompt user for data
            Console.Write("  2. ID:     \t");
                employeeObj.Ssn = Console.ReadLine();

            Console.Write("  3. Name:   \t"); 
                employeeObj.Name = Console.ReadLine();

            Console.Write("  4. Hired:  \t{0}", DateTime.Now.ToShortDateString());
            string userInput = "";
            userInput = Console.ReadLine();
            if (userInput == "")
            {
                userInput = DateTime.Now.ToShortDateString();
            }
            employeeObj.DateOfHire = Convert.ToDateTime(userInput);

            Console.Write("  5. Address:\t"); 
                employeeObj.Street = Console.ReadLine();

            Console.Write("  6. Zipcode:\t");
                employeeObj.Zipcode = Convert.ToInt32(Console.ReadLine());
        }

        static void DisplayPersonnelReport()
        {
            Console.WriteLine("\n\n  Totals:\t\t\tPersonnel Report (All Employees)");

            // Tally of SalariedEmployee
            Console.WriteLine("\n  ({0}) Salaried Employees - - - - - - - - - - - - - - - - - - - - - - - - - - -",
                salariedPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSalary \tPay");

            // Loop through elements of SalariedEmployee(ssn, name, doh, address, zip, salary, pay)
            foreach (SalariedEmployee salariedEmployee in salariedPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t${6:C.2}",
                    salariedEmployee.Ssn,
                    salariedEmployee.Name,
                    salariedEmployee.DateOfHire.ToShortDateString(),
                    salariedEmployee.Street,
                    salariedEmployee.Zipcode.ToString(),
                    salariedEmployee.Salary.ToString(),
                    salariedEmployee.Earnings.ToString());  // Calculated weekly pay from annual salary
            }

            // Tally of HourlyEmployee
            Console.WriteLine("\n  ({0}) Hourly Employees - - - - - - - - - - - - - - - - - - - - - - - - - - - -",
                hourlyPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tWage \tHours \tPay");

            // Loop through elements of HourlyEmployee(ssn, name, doh, address, zip, rate, regTime, pay, overTime, OTpay)
            foreach (HourlyEmployee hourlyEmployee in hourlyPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                    hourlyEmployee.Ssn,
                    hourlyEmployee.Name,
                    hourlyEmployee.DateOfHire.ToShortDateString(),
                    hourlyEmployee.Street,
                    hourlyEmployee.Zipcode.ToString(),
                    hourlyEmployee.HourlyRate.ToString(),
                    hourlyEmployee.HoursWorked.ToString(),
                    hourlyEmployee.Earnings.ToString());
            }

            // Tally of CommissionEmployee
            Console.WriteLine("\n  ({0}) Commission Employee  - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                commissionPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tPay");

            // Loop through elements of CommissionEmployee(ssn, name, doh, address, zip, sales made, percent take, pay)
            foreach (CommissionEmployee commissionEmployee in commissionPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6}%\t${7:C.2}",
                    commissionEmployee.Ssn,
                    commissionEmployee.Name,
                    commissionEmployee.DateOfHire.ToShortDateString(),
                    commissionEmployee.Street,
                    commissionEmployee.Zipcode.ToString(),
                    commissionEmployee.SalesMade.ToString(),
                    commissionEmployee.SalesPercent.ToString(),
                    commissionEmployee.Earnings.ToString());
            }
            // Tally of BasePlusCommissionEmployee
            Console.WriteLine("\n  ({0}) Base+ Commission Employee  - - - - - - - - - - - - - - - - - - - - - - - ",
                basePlusCommissionPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tSalary \tPay");

            // Loop through elements of BasePlusCommissionEmployee(ssn, name, doh, address, zip, sales made, percent take, salary, pay)
            foreach (BasePlusCommissionEmployee basePlusCommissionEmployee in basePlusCommissionPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6}%\t${7:C.2}\t${8:C.2}",
                    basePlusCommissionEmployee.Ssn,
                    basePlusCommissionEmployee.Name,
                    basePlusCommissionEmployee.DateOfHire.ToShortDateString(),
                    basePlusCommissionEmployee.Street,
                    basePlusCommissionEmployee.Zipcode.ToString(),
                    basePlusCommissionEmployee.SalesMade.ToString(),
                    basePlusCommissionEmployee.SalesPercent.ToString(),
                    basePlusCommissionEmployee.Salary.ToString(),
                    basePlusCommissionEmployee.Earnings.ToString());
            }
            Console.WriteLine("\n   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
        }

        static void Main(string[] args)
        {
            // Interact with the user at the console with defaults: System, standard out, standard in
            Console.WriteLine("\n  Project 2 - Michael Fetick, 84270");

            bool wantToQuit = false; // default
            do
            {
                // Do-while not wantToQuit (loop)
                if (!wantToQuit)
                {
                    // Prompt user to select employee type
                    Console.WriteLine
                        ("\n  Employee types: 'S' Salaried, 'H' Hourly, 'C' Commission, 'B' Base+Commission");
                    Console.Write
                        ("  Enter letter for employee type or 'Q' to quit: ");

                    // The reponse returned from Console.ReadKey is a ConsoleKeyInfo type,
                    //  refer to the ConsoleKey Enumeration set for values
                    cki = Console.ReadKey();

                    // Switch-Case to match employee type {S, H, C, B}, fall-through is used, 
                    // call method to prompt user to populate fields of the object;
                    // or quit {Q}. 
                    switch (cki.KeyChar)
                    {
                        case 'S': // Salaried employee
                        case 's': CreateSalariedEmployee();
                            break;

                        case 'H': // Hourly employee
                        case 'h': CreateHourlyEmployee();

                            break;

                        case 'C': // Commission employee
                        case 'c': CreateCommissionEmployee();
                            break;

                        case 'B': // BasePlusCommission employee
                        case 'b': CreateBasePlusCommissionEmployee();
                            break;

                        case 'Q': // Quit and display tally of employee types
                        case 'q':
                            wantToQuit = true; // quit program
                            DisplayPersonnelReport();
                            break;
                        
                        default:
                            break;
                    }
                }
            } while (!wantToQuit);
        }
    }
}
