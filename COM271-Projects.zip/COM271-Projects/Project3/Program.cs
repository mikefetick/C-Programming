﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 3 -
 *   Project 3 uses interfaces to extend the payroll system 
 *   developed in Project 2 to perform several accounting operations 
 *   in a single accounts-payable application. 
 *   We introduce an interface named IPayable that describes the 
 *   functionality of any object capable of being paid and declares 
 *   a method to calculate payment due. Polymorphically, it
 *   calculates payroll earnings paid to salaried employees and
 *   it calculates the payment due on invoices. 
 * Date: 14 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AccountsPayable
{
    // Delegates are declared with no body and prefaced with the keyword delegate.
    delegate void payrollReportGeneration();

    class Program
    {
        // Declare instance variables. All have private scope
        static ConsoleKeyInfo cki;  // for Console.ReadKey reponse returned
        static bool valid = false;
        static string userInput = "";

        // Lists can be sorted easier than arrays, if sorting is later implemented
        static List<SalariedEmployee>           listSalaried           = new List<SalariedEmployee>();          // Salaried
        static List<HourlyEmployee>             listHourly             = new List<HourlyEmployee>();            // Hourly
        static List<CommissionEmployee>         listCommission         = new List<CommissionEmployee>();        // Commission
        static List<BasePlusCommissionEmployee> listBasePlusCommission = new List<BasePlusCommissionEmployee>();// Base + Commission
        
        static void CreateHourlyEmployee()
        {
            // Declare the object
            HourlyEmployee employeeObj;

            // Prompt to choose auto-generated data for Hourly Employee
            Console.Write("\n\n  Employee Record:\n  1. Type: \tHourly Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of HourlyEmployee(ssn, name, doh, earnings, address, zip, rate, regTime, pay, overTime, OTpay)
                employeeObj = new HourlyEmployee("1234", "Jones", DateTime.Parse("04/04/2014"), 0, "123 Blue Dr", 91945, 20, 45, 0, 0, 0);
            }
            else
            // or ask for user input
            {
                // Instantiate the object uninitialized
                employeeObj = new HourlyEmployee();

                // Call method to ask for Personal Identifiable Information (PII)
                AskForPII(employeeObj);

                // Ask for pay data and loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Wage:   \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();
                    
                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.HourlyRate = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter a wage between "
                                                + employeeObj.MinRate + " and " + employeeObj.MaxRate);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  8. Hours:  \t");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.HoursWorked = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter hours worked between "
                                                + employeeObj.MinHours + " and " + employeeObj.MaxHours);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
                // Add element to List<HourlyEmployee>
                listHourly.Add(employeeObj);

                // Display the object
                employeeObj.Display(employeeObj);
        }

        static void CreateSalariedEmployee()
        {
            // Declare the object
            SalariedEmployee employeeObj;

            // Prompt to choose auto-generated data for Salaried Employee
            Console.Write("\n\n  Employee Record:\n  1. Type: \tSalaried Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of SalariedEmployee(ssn, name, doh, earnings, address, zip, salary)
                employeeObj = new SalariedEmployee("3456", "Smith", DateTime.Parse("03/03/2013"), 0, "123 Day Ave", 91945, 40000);
                float diffEarnings = (float)employeeObj.GetPaymentAmount();
                employeeObj.Earnings = diffEarnings;
            }
            else
            // or ask for user input
            {
                // Instantiate the object uninitialized
                employeeObj = new SalariedEmployee();

                // Call method to ask for Personal Identifiable Information (PII)
                AskForPII(employeeObj);

                // Ask for pay data and loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Salary: \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.Salary = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter salary between "
                                                + employeeObj.MinSalary + " and " + employeeObj.MaxSalary);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
            // Add element to List<SalariedEmployee>
            listSalaried.Add(employeeObj);

            // Display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateCommissionEmployee()
        {
            // Declare the object
            CommissionEmployee employeeObj;

            // Prompt to choose auto-generated data for Commission Employee
            Console.Write("\n\n  Employee Record:\n  1. Type: \tCommission Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of CommissionEmployee(ssn, name, doh, earnings, address, zip, sales made, percent take)
                employeeObj = new CommissionEmployee("5678", "Kramer", DateTime.Parse("02/02/2012"), 0, "555 Man Lane", 91945, 3800, 10);
            }
            else
            // or ask for user input
            {
                // Instantiate the object uninitialized
                employeeObj = new CommissionEmployee();

                // Call method to ask for Personal Identifiable Information (PII)
                AskForPII(employeeObj);

                // Ask for pay data and loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Sales:  \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesMade = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales made between "
                                                + employeeObj.MinSalesMade + " and " + employeeObj.MaxSalesMade);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  8. %Take:  \t");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesPercent = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales percentage between "
                                                + employeeObj.MinSalesPerc + " and " + employeeObj.MaxSalesPerc);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
            // Add element to List<CommissionEmployee>
            listCommission.Add(employeeObj);

            // Display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateBasePlusCommissionEmployee()
        {
            // Declare the object
            BasePlusCommissionEmployee employeeObj;

            // Prompt to choose auto-generated data for Salary-Base + Commission Employee
            Console.Write("\n\n  Employee Record:\n  1. Type: \tBase + Commission Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of BasePlusCommissionEmployee(ssn, name, doh, earnings, address, zip, sales made, percent take, salary)
                employeeObj = new BasePlusCommissionEmployee("6789", "Tyler", DateTime.Parse("01/01/2011"), 0, "789 Tree Dr", 91945, 2500, 10, 52000);
            }
            else
            // or ask for user input
            {
                // Instantiate the object uninitialized
                employeeObj = new BasePlusCommissionEmployee();

                // Call method to ask for Personal Identifiable Information (PII)
                AskForPII(employeeObj);

                // Ask for pay data and loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Salary: \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.Salary = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter salary between "
                                                + employeeObj.MinSalary + " and " + employeeObj.MaxSalary);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  8. Sales:  \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesMade = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales made between "
                                                + employeeObj.MinSalesMade + " and " + employeeObj.MaxSalesMade);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  9. %Take:  \t");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesPercent = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales percentage between "
                                                + employeeObj.MinSalesPerc + " and " + employeeObj.MaxSalesPerc);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
            // Add element to List<CommissionEmployee>
            listBasePlusCommission.Add(employeeObj);

            // Display the object
            employeeObj.Display(employeeObj);
        }

        public static string ReadUserInput()
        {
            userInput = Console.ReadLine();
            Console.CursorTop = Console.CursorTop + 1;
            ClearLine();
            return userInput;
        }

        public static void DisplayErrorMessage(string errMsg)
        {
            Console.Write(errMsg);
            ClearLine();
        }

        public static void ClearLine()
        {
            Console.SetCursorPosition(0, Console.CursorTop - 1);
            Console.Write(new string(' ', Console.WindowWidth));
            Console.SetCursorPosition(0, Console.CursorTop - 1);
        }

        public static void ResetLine()
        {
            Console.CursorTop = Console.CursorTop - 1;
            ClearLine();
            Console.WriteLine();
        }

        // Method called to ask for Personal Identifiable Information (PII)
        static void AskForPII(Employee employeeObj)
        {
            /// Avoid exceptions during runtime

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  2. SSN-last4:\t");
                employeeObj.Ssn = ReadUserInput();

                // Uses Regular Expression to validate data
                string reg = @"^\d{4}$";

                if (Regex.IsMatch(employeeObj.Ssn, reg))
                {
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  3. LastName:\t");
                employeeObj.Name = ReadUserInput();

                if (!string.IsNullOrEmpty(employeeObj.Name))
                {
                    // Accept substring of fixed length
                    if (employeeObj.Name.Length > 6)
                    {
                        employeeObj.Name = string.Format(employeeObj.Name).Substring(0, 6);
                    }
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Present today's date as a default for user
                string dateToday = DateTime.Now.ToShortDateString();
                Console.Write("  4. Hired:  \t{0}", dateToday);

                // Position the prompt for data at the beginning of the date
                Console.CursorLeft = Console.CursorLeft - dateToday.Length;
                userInput = ReadUserInput();

                if (userInput == "")
                {
                    userInput = dateToday;
                }

                // Handle exceptions during runtime
                try
                {
                    employeeObj.DateOfHire = Convert.ToDateTime(userInput);
                    valid = true;
                }
                catch (FormatException)
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  5. Address:\t");
                employeeObj.Street = ReadUserInput();

                if (!string.IsNullOrEmpty(employeeObj.Street))
                {
                    // Accept substring of fixed length
                    if (employeeObj.Street.Length > 8)
                    {
                        employeeObj.Street = string.Format(employeeObj.Street).Substring(0, 8);
                    }
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  6. Zipcode:\t");

                // Uses Regular Expression to validate data
                string reg = @"^\d{5}$";
                userInput = ReadUserInput();

                if (Regex.IsMatch(userInput, reg))
                {
                    employeeObj.Zipcode = Convert.ToInt32(userInput);
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);
        }

        // Method to use delegate referencing delegate objects
        static private void UseDelegate(payrollReportGeneration payrollRG)
        {
            payrollRG();
        }

        // Method called to display personnel report of all employees
        static void DisplayPayrollReportHeader()
        {
            Console.WriteLine("\n\n  Totals:\t\t\tPersonnel Report (All Employees)");
        }

        // Method called to display Hourly personnel data
        static void DisplayHourlyPersonnelData()
        {
            // Tally of HourlyEmployee
            Console.WriteLine("\n  ({0}) Hourly Employees - - - - - - - - - - - - - - - - - - - - - - - - - - - -",
                listHourly.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tWage \tHours \tPay");

            // Loop through elements of HourlyEmployee(ssn, name, doh, address, zip, rate, regTime, pay, overTime, OTpay)
            foreach (HourlyEmployee hourlyEmployee in listHourly)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                    hourlyEmployee.Ssn,
                    hourlyEmployee.Name,
                    hourlyEmployee.DateOfHire.ToShortDateString(),
                    hourlyEmployee.Street,
                    hourlyEmployee.Zipcode.ToString(),
                    hourlyEmployee.HourlyRate.ToString(),
                    hourlyEmployee.HoursWorked.ToString(),
                    hourlyEmployee.Earnings.ToString());
            }
        }

        // Method called to display Salaried personnel data
        static void DisplaySalaryPersonnelData()
        {
            // Tally of SalariedEmployee
            Console.WriteLine("\n  ({0}) Salaried Employees - - - - - - - - - - - - - - - - - - - - - - - - - - -",
                listSalaried.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSalary \tPay");

            // Loop through elements of SalariedEmployee(ssn, name, doh, address, zip, salary, pay)
            foreach (SalariedEmployee salariedEmployee in listSalaried)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t${6:C.2}",
                    salariedEmployee.Ssn,
                    salariedEmployee.Name,
                    salariedEmployee.DateOfHire.ToShortDateString(),
                    salariedEmployee.Street,
                    salariedEmployee.Zipcode.ToString(),
                    salariedEmployee.Salary.ToString(),
                    salariedEmployee.Earnings.ToString());  // Calculated weekly pay from annual salary
            }
        }

        // Method called to display Commission personnel data
        static void DisplayCommissionPersonnelData()
        {
            // Tally of CommissionEmployee
            Console.WriteLine("\n  ({0}) Commission Employee  - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                listCommission.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tPay");

            // Loop through elements of CommissionEmployee(ssn, name, doh, address, zip, sales made, percent take, pay)
            foreach (CommissionEmployee commissionEmployee in listCommission)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6}%\t${7:C.2}",
                    commissionEmployee.Ssn,
                    commissionEmployee.Name,
                    commissionEmployee.DateOfHire.ToShortDateString(),
                    commissionEmployee.Street,
                    commissionEmployee.Zipcode.ToString(),
                    commissionEmployee.SalesMade.ToString(),
                    commissionEmployee.SalesPercent.ToString(),
                    commissionEmployee.Earnings.ToString());
            }
        }

        // Method called to display Base Plus Commission personnel data
        static void DisplayBasePlusCommissionPersonnelData()
        {
            // Tally of BasePlusCommissionEmployee
            Console.WriteLine("\n  ({0}) Base+ Commission Employee  - - - - - - - - - - - - - - - - - - - - - - - ",
                listBasePlusCommission.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tSalary \tPay");

            // Loop through elements of BasePlusCommissionEmployee(ssn, name, doh, address, zip, sales made, percent take, salary, pay)
            foreach (BasePlusCommissionEmployee basePlusCommissionEmployee in listBasePlusCommission)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6}%\t${7:C.2}\t${8:C.2}",
                    basePlusCommissionEmployee.Ssn,
                    basePlusCommissionEmployee.Name,
                    basePlusCommissionEmployee.DateOfHire.ToShortDateString(),
                    basePlusCommissionEmployee.Street,
                    basePlusCommissionEmployee.Zipcode.ToString(),
                    basePlusCommissionEmployee.SalesMade.ToString(),
                    basePlusCommissionEmployee.SalesPercent.ToString(),
                    basePlusCommissionEmployee.Salary.ToString(),
                    basePlusCommissionEmployee.Earnings.ToString());
            }
            Console.WriteLine("\n   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
        }

        static void Main(string[] args)
        {
            //Delegate can be thought of as an object that contains an ordered list of methods 
            //(from any class or struct) with the same signature and return type. It is a type 
            //like a class. This is a contiguous list of methods that can be executed at any time.
            //
            // Create delegate object, referencing first method to display AccountsPayable Report header
            payrollReportGeneration payrollRG = new payrollReportGeneration(DisplayPayrollReportHeader);
            // Add methods to delegate
            payrollRG += DisplayHourlyPersonnelData;
            payrollRG += DisplaySalaryPersonnelData;
            payrollRG += DisplayCommissionPersonnelData;
            payrollRG += DisplayBasePlusCommissionPersonnelData;

            // Interact with the user at the console with defaults: System, standard out, standard in
            Console.WriteLine("\n  Project 2 - Michael Fetick, 84270");

            bool wantToQuit = false; // default
            do
            {
                // Do-while not wantToQuit (loop)
                if (!wantToQuit)
                {
                    // Prompt user to select employee type
                    Console.WriteLine
                        ("\n  Employee types: 'S' Salaried, 'H' Hourly, 'C' Commission, 'B' Base+Commission");
                    Console.Write
                        ("  Enter letter for employee type or 'Q' to quit: ");

                    // The reponse returned from Console.ReadKey is a ConsoleKeyInfo type,
                    //  refer to the ConsoleKey Enumeration set for values
                    cki = Console.ReadKey();

                    // Switch-Case to match employee type {S, H, C, B}, fall-through is used, 
                    // call the method to prompt user to populate fields of the object;
                    // or quit {Q}. 
                    switch (cki.KeyChar)
                    {
                        case 'S': // Salaried employee
                        case 's': 
                            ResetLine();
                            CreateSalariedEmployee();
                            break;

                        case 'H': // Hourly employee
                        case 'h': 
                            ResetLine();
                            CreateHourlyEmployee();
                            break;

                        case 'C': // Commission employee
                        case 'c': 
                            ResetLine();
                            CreateCommissionEmployee();
                            break;

                        case 'B': // BasePlusCommission employee
                        case 'b': 
                            ResetLine();
                            CreateBasePlusCommissionEmployee();
                            break;

                        case 'Q': // Quit and display tally of employee types
                        case 'q':
                            wantToQuit = true; // quit program
                            ResetLine();
                            //DisplayPersonnelReport();
                            // Replaced by a delegate for payrollReportGeneration
                            UseDelegate(payrollRG);

                            // Use the GetPaymentAmount method in the Invoice class
                            // that is implemented from the Ipayable interface
                            Invoice oneInvoice = new Invoice();
                            Console.WriteLine("\n  Invoice amount with GetPaymentAmount method: $" 
                                + oneInvoice.GetPaymentAmount()
                                + "\n");

                            break;
                        
                        default:
                            Console.WriteLine();
                            DisplayErrorMessage("     Error, please try again.");
                            Console.CursorTop = Console.CursorTop - 2;
                            break;
                    }
                }
            } while (!wantToQuit);
        }
    }
}
