﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 3 -
 *   Project 3 uses interfaces to extend the payroll system 
 *   developed in Project 2 to perform several accounting operations 
 *   in a single accounts-payable application. 
 *   We introduce an interface named IPayable that describes the 
 *   functionality of any object capable of being paid and declares 
 *   a method to calculate payment due. Polymorphically, it
 *   calculates payroll earnings paid to salaried employees and
 *   it calculates the payment due on invoices. 
 * Date: 14 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AccountsPayable
{
    class Invoice : IPayable
    {
        // With the IPayable interface, GetPaymentAmount returns salary
        decimal paymentAmount = 99;  // The standard, monthly invoice paymentAmount
        public decimal GetPaymentAmount()
        {
            return (decimal) paymentAmount;
        }
    }
}
