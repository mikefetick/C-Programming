﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 3 -
 *   Project 3 uses interfaces to extend the payroll system 
 *   developed in Project 2 to perform several accounting operations 
 *   in a single accounts-payable application. 
 *   We introduce an interface named IPayable that describes the 
 *   functionality of any object capable of being paid and declares 
 *   a method to calculate payment due. Polymorphically, it
 *   calculates payroll earnings paid to salaried employees and
 *   it calculates the payment due on invoices. 
 * Date: 14 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AccountsPayable
{
    //Interface is a reference type that represents a set of function members,
    //but does not implement them. They cannot have constructors.
    //It is like a class where all methods are abstract.

    //Interface can only contain declaration of following kinds of function members:
    //  -- Methods
    //  -- Properties
    //  -- Events
    //  -- Indexers

    //Cannot contain 
    //  --any implementations
    //  --data members

    //by convention must begin with a "I" prefix    // An interfaces is named with an 'I' character prefix

    // Interface for objects capable of being paid
    interface IPayable
    {
        decimal GetPaymentAmount();
    }
}