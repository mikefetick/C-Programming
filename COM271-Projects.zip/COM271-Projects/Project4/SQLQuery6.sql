﻿CREATE TABLE transactions_t
(
    transaction_number  INT NOT NULL IDENTITY(1,10),
	account_number    NUMERIC(6),
    amount              MONEY,
    transaction_type    CHAR(1),
    last_date_modified  DATETIME 
                        DEFAULT    GETDATE(),

    CONSTRAINT          pk_transaction_number
    PRIMARY KEY         CLUSTERED (transaction_number) 
)
GO

INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(22222, 1000, 'D');
INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(22222, 4000, 'D');
INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(22222, 3000, 'W');
INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(33333, 12000, 'D');
INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(33333, 7000, 'D');
INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(22222, 10000, 'D');
INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(33333, 4000, 'W');
INSERT INTO transactions_t (account_number, amount, transaction_type) 
VALUES(33333, 3000, 'D');

