﻿CREATE TABLE ATMCard_t
(
    card_number         INT NOT NULL IDENTITY(1111,10),
    account_number      NUMERIC(6),
    pin                 CHAR(4),
    last_date_modified  DATETIME DEFAULT GETDATE(),
    
    CONSTRAINT          pk_card_number
    PRIMARY KEY         CLUSTERED (card_number),
    
    CONSTRAINT          fk_account_number
    FOREIGN KEY         (account_number)
    REFERENCES          accounts_t (account_number)
)
GO

INSERT INTO ATMCard_t (account_number, pin) 
VALUES(22222, '1234');
INSERT INTO ATMCard_t (account_number, pin) 
VALUES(33333, '5678');

