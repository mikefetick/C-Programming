﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: 
 * Practical Exercise 4 - GUI App of ATM Machine
 *   With two images of inserting ATM Card, each
 *   with unique card number and pin table lookup.
 * 
 *   Extended from Lesson 19 - Winforms (Student Manual, page 122)
 *   A Windows Form Application that will allow you 
 *   to review the Deposits and Withdrawals 
 *   for a specified Customer Account.
 *
 * Date: 24 April 2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Project4_ATM
{
    public partial class ReviewTransactions : Form
    {
        decimal totalDeposits = 0.00M;
        decimal totalWithdrawals = 0.00M;

        //string connectionString = "Data Source=172.16.2.34;" +
        string networkConnectionString = "Data Source=172.16.2.34;" +
                "User id=db84270;" +
                "password=5a0c1de0;" +
                "Initial Catalog=db84270";

        string localhostConnectionString = "Data Source=(localdb)\\Projects;" +
                "Integrated Security=True;" +
                "Connect Timeout=15;" +
                "Encrypt=False;" +
                "TrustServerCertificate=False;" +
                "User id=db84270;" +
                "password=5a0c1de0;" +
                "Initial Catalog=db84270";

        public ReviewTransactions()
        {
            InitializeComponent();
            // Display the window in the center of the screen
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        public SqlConnection CreateConnection()
        {
            SqlConnection connection;
            if (ckbConnection.Checked)
            {
                connection = new SqlConnection(localhostConnectionString);
            }
            else
            {
                connection = new SqlConnection(networkConnectionString);
            }
            //SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

        public string GetCustomerName(int custId)
        {
            string name = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            string query = @"
                SELECT customer_name 
                FROM customers_t
                WHERE customer_id = " + custId.ToString();

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                name = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                    connection = null;
            }
            return name;
        }

        public string GetATMcardNumber(string acctKey)
        {
            string cardNumber = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Include tick marks in the string for the variable
            string query = @"
                SELECT card_number 
                FROM ATMCard_t
                WHERE account_number = '" + acctKey + "'";

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                cardNumber = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }

            return cardNumber;
        }

        public string GetATMpinNumber(string acctKey)
        {
            string pinNumber = String.Empty;

            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Include tick marks in the string for the variable
            string query = @"
                SELECT pin 
                FROM ATMCard_t
                WHERE account_number = '" + acctKey + "'";

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                pinNumber = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }

            return pinNumber;
        }

        public string GetAccountNumber(int custId, string acctType)
        {
            string accountNumber = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Include tick marks in the string for the variable
            string query = @"
                SELECT account_number 
                FROM accounts_t
                WHERE customer_id = '" + custId.ToString() 
                   + "' AND account_type = '" + acctType + "'";

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                accountNumber = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }

            return accountNumber;
        }

        public void PopulateListBox(string acct_num)
        {
            totalDeposits = 0.00M;
            totalWithdrawals = 0.00M;

            string strAmount = string.Empty;

            lstTransactions.Items.Clear();
            lstTransactions.BeginUpdate();

            SqlDataAdapter da = null;
            DataSet ds = null;
            DataTable dt = null;

            string query = @"
                SELECT transaction_type, amount
                FROM transactions_t
                WHERE account_number = " + acct_num;

            SqlConnection connection = CreateConnection();
            connection.Open();

            // The keyword using() can get the database to handle the SQL exceptions.
            //using (da = new SqlDataAdapter(query, connection))
            //using (ds = new DataSet())

            // When a data record is missing a foreign key, then a SQL exception of 
            // "Object reference not set to an instance of an object" is thrown...
            // A try-catch block can handle the SQL exceptions.
            try
            {
                da = new SqlDataAdapter(query, connection);
                ds = new DataSet();

                da.Fill(ds, "transactions_t");
                dt = ds.Tables["transactions_t"];

                lstTransactions.Items.Add("Deposits".PadLeft(19) +
                    "Withdrawals".PadLeft(14));

                foreach (DataRow row in dt.Rows)
                {
                    if (row["transaction_type"].Equals("D"))
                    {
                        totalDeposits += Convert.ToDecimal(row["amount"]);

                        strAmount = string.Format("{0:N}", row["amount"]);
                        lstTransactions.Items.Add(strAmount.PadLeft(19));
                    }
                    else
                    {
                        totalWithdrawals += Convert.ToDecimal(row["amount"]);

                        strAmount = string.Format("{0:N}", row["amount"]);
                        lstTransactions.Items.Add("".PadLeft(19) +
                             strAmount.PadLeft(14));
                    }
                }

                lstTransactions.Items.Add("Total:" +
                    string.Format("{0:N}", totalDeposits).PadLeft(13) +
                    string.Format("{0:N}", totalWithdrawals).PadLeft(14));

                lstTransactions.EndUpdate();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show(sqlEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                lstTransactions.EndUpdate();
            }
        }
        // For Connected Objects
        public void SubmitTransaction(string p_account_number, 
                                      string p_amount, 
                                      string p_transaction_type)
        {
            SqlDataAdapter da = null;

            //string aDate = DateTime.Now.ToShortDateString() + " "
            //             + DateTime.Now.ToLongTimeString();
            string aDate = "GETDATE()";
            // Build a query to insert a record into transactions_t 
            //string aRecord = string.Format("({0},{1},{2},{3},{4})",
                             //p_transaction_number,
            string aRecord = string.Format("({0},{1},'{2}',{3})",
                             p_account_number, 
                             p_amount, 
                             p_transaction_type, 
                             aDate);
/*
            string query = @"INSERT INTO transactions_t" 
                         + @"(account_number, "
                         + @"amount, "
                         + @"transaction_type, "
                         + @"last_date_modified)"
                         + @" VALUES " + aRecord;
*/
            string query = @"INSERT INTO transactions_t "
                         + "(account_number, "
                         + "amount, "
                         + "transaction_type, "
                         + "last_date_modified)"
                         + " VALUES " + aRecord;

            SqlConnection connection = CreateConnection();
            connection.Open();

            // A try-catch block can handle the SQL exceptions.
            try
            {
                //da = new SqlDataAdapter(query, connection);
                SqlCommand sc = new SqlCommand(query, connection);
                sc.ExecuteNonQuery();
                //Create the SqlCommand to execute the Insert Sql statement.
                //da.InsertCommand = new SqlCommand(query, connection);
                //da.InsertCommand.CommandType = CommandType.Text;

/*                
                // Add the parameter for the LastName. Specifying the
                // ParameterDirection for an input parameter is not required.
                da.InsertCommand.Parameters.Add(
                    new SqlParameter("@CustId", SqlDbType.UniqueIdentifier, 0, "CustId"));

                // Add the SqlParameter to retrieve the new identity value.
                // Specify the ParameterDirection as Output.
                SqlParameter parameter =
                    da.InsertCommand.Parameters.Add(
                    "@CustomerOrderId", SqlDbType.UniqueIdentifier, 0, "NEWID()");
                parameter.Direction = ParameterDirection.Output;
*/                
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show(sqlEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (!txtCustomerNumber.Text.Equals(String.Empty))
            {

                int id = Convert.ToInt32(this.txtCustomerNumber.Text);
                string acctType = String.Empty;

                if (rbChecking.Checked)
                {
                    acctType = "C";
                }
                else
                {
                    acctType = "S";
                }

                lblCustName.Text = GetCustomerName(id);
                lblAccountNumber.Text = GetAccountNumber(id, acctType);
                PopulateListBox(lblAccountNumber.Text);

                // If account exists, enable transactions
                if (lstTransactions.Items.Count > 0)
                {
                    gbxTransaction.Enabled = true;
                }
                else
                {
                    gbxTransaction.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("You must enter a Customer Number",
                  "No Customer Number");
            }
        }

        private void ReviewTransactions_Load(object sender, EventArgs e)
        {
            btnReset.Visible = false;
            txtCustomerNumber.Select();
        }

        private void pbox1_Click(object sender, EventArgs e)
        {
            pbox1.Visible = false;
            pbox2.Visible = false;
            pbox1.Enabled = false;
            pbox2.Enabled = false;
            txtCustomerNumber.Text = "3";
            lblImages.Visible = false;
            btnReset.Visible = true;
            lblATMCard.Visible = true;
            lblATMCardNumber.Visible = true;
            lblATMCardNumber.Text = GetATMcardNumber(GetAccountNumber(3, "C"));
            lblPIN.Visible = true;
            lblPINnumber.Visible = true;
            lblPINnumber.Text = GetATMpinNumber(GetAccountNumber(3, "C"));
            btnDisplay_Click(sender, e);
        }

        private void pbox2_Click(object sender, EventArgs e)
        {
            pbox1.Visible = false;
            pbox2.Visible = false;
            pbox1.Enabled = false;
            pbox2.Enabled = false;
            txtCustomerNumber.Text = "7";
            lblImages.Visible = false;
            btnReset.Visible = true;
            lblATMCard.Visible = true;
            lblATMCardNumber.Visible = true;
            lblATMCardNumber.Text = GetATMcardNumber(GetAccountNumber(7, "C"));
            lblPIN.Visible = true;
            lblPINnumber.Visible = true;
            lblPINnumber.Text = GetATMpinNumber(GetAccountNumber(7, "C"));
            btnDisplay_Click(sender, e);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            btnReset.Visible = false;
            lblATMCard.Visible = false;
            lblATMCardNumber.Visible = false;
            lblPIN.Visible = false;
            lblPINnumber.Visible = false;
            lblImages.Visible = true;
            pbox1.Visible = true;
            pbox2.Visible = true;
            pbox1.Enabled = true;
            pbox2.Enabled = true;
        }

        // Validate numeric entry into txtCustomerNumber
        // Retrieved from MSDN at
        // http://msdn.microsoft.com/en-us/library/system.windows.forms.control.keypress%28v=vs.110%29.aspx
        // Boolean flag used to determine when a character other than a number is entered. 
        private bool nonNumberEntered = false;

        // Handle the KeyDown event to determine the type of character entered into the control. 
        private void txtCustomerNumber_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            // Initialize the flag to false.
            nonNumberEntered = false;

            // Determine whether the keystroke is a number from the top of the keyboard. 
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                // Determine whether the keystroke is a number from the keypad. 
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    // Determine whether the keystroke is a backspace. 
                    if(e.KeyCode != Keys.Back)
                    {
                        // A non-numerical keystroke was pressed. 
                        // Set the flag to true and evaluate in KeyPress event.
                        nonNumberEntered = true;
                    }
                }
            }
            //If shift key was pressed, it's not a number. 
            if (Control.ModifierKeys == Keys.Shift) {
                nonNumberEntered = true;
            }
        }
        // Continue..
        // This event occurs after the KeyDown event and can be used to prevent 
        // characters from entering the control. 
        private void txtCustomerNumber_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            // Check for the flag being set in the KeyDown event. 
            if (nonNumberEntered == true)
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }
        }

        // Validate numeric entry into txtAmount
        // Retrieved from MSDN at
        // http://msdn.microsoft.com/en-us/library/system.windows.forms.control.keypress%28v=vs.110%29.aspx
        // Boolean flag used to determine when a character other than a number is entered. 
        private bool nonNumberAmount = false;

        // Handle the KeyDown event to determine the type of character entered into the control. 
        private void txtAmount_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            // Initialize the flag to false.
            nonNumberAmount = false;

            // Determine whether the keystroke is a number from the top of the keyboard. 
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                // Determine whether the keystroke is a number from the keypad. 
                if (e.KeyCode < Keys.NumPad0 || e.KeyCode > Keys.NumPad9)
                {
                    // Determine whether the keystroke is a backspace. 
                    if (e.KeyCode != Keys.Back)
                    {
                        // A non-numerical keystroke was pressed. 
                        // Set the flag to true and evaluate in KeyPress event.
                        nonNumberAmount = true;
                    }
                }
            }
            //If shift key was pressed, it's not a number. 
            if (Control.ModifierKeys == Keys.Shift)
            {
                nonNumberAmount = true;
            }
        }
        // Continue..
        // This event occurs after the KeyDown event and can be used to prevent 
        // characters from entering the control. 
        private void txtAmount_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            // Check for the flag being set in the KeyDown event. 
            if (nonNumberAmount == true)
            {
                // Stop the character from being entered into the control since it is non-numerical.
                e.Handled = true;
            }
        }

        #region CreateTransactionNumber()
        private string CreateTransactionNumber()
        {
            string maxTransactionNumber = "";
            int lastTransactionNumber = 0;
            string newTransactionNumber = "";
            SqlCommand command = null;

            // Referred to http://technet.microsoft.com/en-us/library/ms187751.aspx
            string query = @"SELECT MAX(transaction_number) AS Expr1 FROM transactions_t";
            try
            {
                command = new SqlCommand(query, CreateConnection());

                maxTransactionNumber = command.ExecuteScalar().ToString();
                //newTransactionNumber = Convert.ToString(maxTransactionNumber + 10);

                lastTransactionNumber = Convert.ToInt32(maxTransactionNumber);
                newTransactionNumber = Convert.ToString(lastTransactionNumber + 10);
            }

            catch (SqlException ex)
            {
                Console.WriteLine("Error     : " + "SqlException");
                Console.WriteLine("Message   : " + ex.Message);
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error     : " + "Exception");
                Console.WriteLine("Message   : " + ex.Message);
            }

            finally
            {
                command = null;
            }

            return newTransactionNumber;
        }
        #endregion


        private void btnCommit_Click(object sender, EventArgs e)
        {
            if (!txtAmount.Text.Equals(String.Empty))
            {

                int amt = Convert.ToInt32(this.txtAmount.Text);
                string transType = String.Empty;

                if (rbDeposit.Checked)
                {
                    // Deposit transaction
                    transType = "D";

                    // Submit transaction record into table
                    //SubmitTransaction(CreateTransactionNumber(),
                    SubmitTransaction(lblAccountNumber.Text,
                                      txtAmount.Text,
                                      transType);
                }
                else
                {
                    // Withdrawal transaction
                    transType = "W";

                    // Compare account balance to withdrawal amount 
                    // to approve transaction
                    if (amt <= (totalDeposits - totalWithdrawals))
                    {
                        // TBD - If approved, build insert query 
                        // Submit transaction record into table
                        //SubmitTransaction(CreateTransactionNumber(),
                        SubmitTransaction(lblAccountNumber.Text,
                                          txtAmount.Text,
                                          transType);
                    }
                    else
                    {
                        MessageBox.Show("You cannot withdrawal more than your balance.",
                          "Insufficient Funds");
                    }
                }
                // Display account info after transaction
                PopulateListBox(lblAccountNumber.Text);
            }
            else
            {
                MessageBox.Show("You must enter a Customer Number",
                  "No Customer Number");
            }
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            if (!txtAmount.Text.Equals(String.Empty))
            {
                btnCommit.Enabled = true;
            }
        }
    }
}
/*
Note: When you execute this program, only customers 3 and 7 
      have transactions recorded in the database. 
      Only customer 3 has a Checking and a Savings account.
      Customer 7 has only a Checking account.

*/