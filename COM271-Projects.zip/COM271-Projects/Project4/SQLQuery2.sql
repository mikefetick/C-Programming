﻿CREATE TABLE accounts_t
(
    account_number      NUMERIC(6),
    account_type        CHAR(1),
    customer_id         INT,
    total_deposit       MONEY,
    total_withdrawal    MONEY,
    last_date_modified  DATETIME 
                        DEFAULT    GETDATE(),

    CONSTRAINT          pk_account_number
    PRIMARY KEY         CLUSTERED (account_number) 
)
GO
INSERT INTO accounts_t (account_number, account_type, customer_id) VALUES(22222, 'C', 7);
INSERT INTO accounts_t (account_number, account_type, customer_id) 
VALUES(33333, 'C', 3);
INSERT INTO accounts_t (account_number, account_type, customer_id) 
VALUES(33343, 'S', 3);

