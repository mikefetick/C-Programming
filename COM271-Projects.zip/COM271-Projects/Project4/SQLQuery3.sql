﻿CREATE TABLE	
  customers_t
  (
    customer_id                INT IDENTITY (1,1)  NOT NULL,
    customer_name              VARCHAR(50)         NOT NULL,
    last_date_modified		 DATETIME            NOT NULL
                               DEFAULT             GETDATE(),
    
    CONSTRAINT                 pk_customer_id
    PRIMARY KEY                CLUSTERED (customer_id),
  )
 
GO

INSERT INTO customers_t(customer_name) VALUES ('Freddie The Freeloader')
INSERT INTO customers_t(customer_name) VALUES ('Susan Of The Savanah')
INSERT INTO customers_t(customer_name) VALUES ('George Of The Jungle')
INSERT INTO customers_t(customer_name) VALUES ('Mary Quite Contrary')
INSERT INTO customers_t(customer_name) VALUES ('Moe Rocca')
INSERT INTO customers_t(customer_name) VALUES ('Kathleen Turner')
INSERT INTO customers_t(customer_name) VALUES ('Adalwolf Heinz')
INSERT INTO customers_t(customer_name) VALUES ('Edgardo Fernandez')
INSERT INTO customers_t(customer_name) VALUES ('Zuleika Andressa')
INSERT INTO customers_t(customer_name) VALUES ('Winona Franklin')

