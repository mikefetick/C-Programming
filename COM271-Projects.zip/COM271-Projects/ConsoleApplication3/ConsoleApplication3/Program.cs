﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lesson2
{
    public class Address1
    {
        private string street;
        private int zipcode;

        public string Street
        {
            set { this.street = value; }
            get { return this.street; }
        }

        public int Zipcode
        {
            set { this.zipcode = value; }
            get { return this.zipcode; }
        }

        static void Main(string[] args)
        {

        }
    }
}
