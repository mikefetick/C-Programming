﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Practical Exercise 1
 *   Define a set of application-specific Exception classes (2 hours)          
 *   implemented to project 2 - Student Handbook (Pages 46)
 * Date: 9 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Payroll
{
     public class Address1
    {
        private string street;
        public string Street
        {
            get { return street; }
            set { street = value; }
        }
        private int zipCode;
        public int ZipCode
        {
            get { return zipCode; }
            set { zipCode = value; }
        }

        public Address1()
        {
            Street = "{Unknown}";
            Zipcode = 0;
        }

        public Address1(string streetParm, int zipCodeParm)
        {
            Street = streetParm;
            Zipcode = zipCodeParm;
        }

        public int Zipcode { get; set; }
    }

    public class Employee : Address1
    {
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string ssn;
        public string Ssn
        {
            get { return ssn; }
            set { ssn = value; }
        }
        private DateTime dateOfHire;
        public DateTime DateOfHire
        {
            get { return dateOfHire; }
            set 
            {
                if (value != null)
                { dateOfHire = value; }
                else
                { dateOfHire = DateTime.Now; }
            }
        }
        private float earnings;
        public float Earnings
        {
          get { return earnings; }
          set { earnings = value; }
        }

        /// <summary>
        /// Method to CalculateEarnings of Employee
        /// </summary>
        public virtual void CalculateEarnings()
        {
             Earnings = 0;
        }

        /// <summary>
        /// Static constructor cannot be explicitly invoked
        /// </summary>
        static Employee() { }

        /// <summary>
        /// Non-Static constructor is explicitly invoked
        /// </summary>
        public Employee() { }

        /// <summary>
        /// Overloaded Employee constructor to be explicitly invoked
        /// </summary>
        public Employee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm,
            string streetParm, int zipCodeParm)
            : base(streetParm, zipCodeParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Earnings = earningsParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
        }
    }

    public class SalariedEmployee : Employee
    {
        const int MINSALARY = 20000;   // Company Minimum Salary
        const int MAXSALARY = 100000;  // Company Maximum Salary

        public int MinSalary
        {
            get { return MINSALARY; }  // Return constant MINSALARY
        }

        public int MaxSalary  // Maximum Salary paid by the company
        {
            get { return MAXSALARY; }  // Return constant MAXSALARY 
        }

        private float salary;
        public float Salary
        {
            get { return salary; }
            set
            {
                if ((value >= MINSALARY) && (value <= MAXSALARY))   // Acceptable wages (CA min, Company max)
                { salary = value; }
                else
                { 
                    salary = 0;
                    ArgumentOutOfRangeException argOORexc = new ArgumentOutOfRangeException();
                    throw argOORexc;
                }
            }
        }
        /// <summary>
        /// Default and Overloaded SalariedEmployee constructors to be explicitly invoked
        /// </summary>
        public SalariedEmployee()
        { Salary = 0; }

        public SalariedEmployee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm,
                                string streetParm, int zipCodeParm,
                                float salaryParm)
            : base(ssnParm, nameParm, dohParm, earningsParm, streetParm, zipCodeParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Earnings = earningsParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            Salary = salaryParm;
            CalculateEarnings();
        }
        /// <summary>
        /// Override Employee class method to CalculateEarnings of SalariedEmployee
        /// </summary>
        public override void CalculateEarnings()
        {
            Earnings = Salary / 52;  // Calculate weekly pay from annual salary
        }

        public void Display(SalariedEmployee employeeObj)
        {
            //SalariedEmployee(Display);
            Console.WriteLine("\n  SSN \tName \tHired \t\tAddress \tZip \tSalary \tPay");
            Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C}\t${6:C}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.Salary.ToString(),
                employeeObj.Earnings.ToString());
        }
    }

    public class HourlyEmployee : Employee
    {
        const int MINRATE = 8;   // California Minimum Wage Rate
        const int MAXRATE = 50;  // Company Maximum Wage Rate
        const int MINHOURS = 0;  // Minimum Hours Worked per week
        const int MAXHOURS = 168; // Maximum Hours Worked per week, 24x7=168
        const int MINREGHOURS = 0;  // Minimum Regular Hours Worked per week
        const int MAXREGHOURS = 40; // Maximum Regular Hours Worked per week

        public int MinRate
        {
            get { return MINRATE; }  // Return constant MINRATE
        }

        public int MaxRate  // Maximum Regular Hours Worked per week
        {
            get { return MAXRATE; }  // Return constant MAXRATE 
        }

        public int MinHours
        {
            get { return MINHOURS; }  // Return constant MINHOURS
        }

        public int MaxHours  // Maximum Regular Hours Worked per week
        {
            get { return MAXHOURS; }  // Return constant MAXHOURS 
        }

        private float hourlyRate;
        public float HourlyRate
        {
            get { return hourlyRate; }
            set
            {
                if ((value >= MINRATE) && (value <= MAXRATE))   // Acceptable wages (CA min, Company max)
                { hourlyRate = value; }
                else
                { 
                    hourlyRate = 0;
                    ArgumentOutOfRangeException argOORexc = new ArgumentOutOfRangeException();
                    throw argOORexc;
                }
            }
        }

        private float hoursWorked;
        public virtual float HoursWorked
        {
            get { return hoursWorked; }
            set
            {
                if ((value >= MINHOURS) && (value <= MAXHOURS))  // Accepting valid input
                { hoursWorked = value; }
                else
                { 
                    hoursWorked = 0;
                    ArgumentOutOfRangeException argOORexc = new ArgumentOutOfRangeException();
                    throw argOORexc;
                }
            }
        }

        public float RegTimePay
        {
            get
            {
                if ((HoursWorked >= MINHOURS) && (HoursWorked <= MAXHOURS))   // Accepting valid input
                {
                    if (HoursWorked >= MAXREGHOURS)   // Hours worked Over maximum regular hours
                    {
                        return HourlyRate * MAXREGHOURS;  // Pay up to max reg time
                    }
                    else   // Hours worked Under maximum regular hours
                    {
                        return HourlyRate * HoursWorked;  // Pay actual reg time
                    }
                }
                else   // Not accepting invalid input of hours worked
                {
                    return 0;
                }
            }
            //get { return HourlyRate * HoursWorked; }
            set { }
        }

        private float overTime;
        public float OverTime
        {
            get 
            {
                if ((HoursWorked >= MINHOURS) && (HoursWorked <= MAXHOURS))   // Accepting valid input
                {
                    if (HoursWorked >= MAXREGHOURS)   // Hours worked Over maximum regular hours
                    {
                        return HoursWorked - MAXREGHOURS;
                    }
                    else   // Hours worked Under maximum regular hours
                    {
                        return 0;
                    }
                }
                else   // Not accepting invalid input of hours worked
                {
                    return 0;
                }
            }

            // Value is the amount Over the Maximum Regular Hours Worked per week
            set
            {
                if (HoursWorked > MAXREGHOURS)   // Hours worked weekly over regular time maximum.
                { 
                    overTime = HoursWorked - MAXREGHOURS; // Result will not be negative
                }
                else
                { 
                    overTime = 0; 
                }

            }
        }

        public float OverTimePay  // OverTimePay
        {
            get { return (OverTime * HourlyRate * (float)1.5); }
            set { }
        }

        /// <summary>
        /// Default and Overloaded HourlyEmployee constructors to be explicitly invoked
        /// </summary>
        public HourlyEmployee() { }

        public HourlyEmployee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm,
                                string streetParm, int zipCodeParm,
                                float hourlyRateParm, float hoursWorkedParm, float regTimePayParm, float overTimeParm, float overTimePayParm)
            : base(ssnParm, nameParm, dohParm, earningsParm, streetParm, zipCodeParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            HourlyRate = hourlyRateParm;
            HoursWorked = hoursWorkedParm;
            RegTimePay = regTimePayParm;
            OverTime = overTimeParm;
            OverTimePay = overTimePayParm;
            CalculateEarnings();
        }

        /// <summary>
        /// Override Employee class method to CalculateEarnings of HourlyEmployee
        /// </summary>
        public override void CalculateEarnings() 
        { 
             Earnings = RegTimePay + OverTimePay;  // Calculate weekly pay for time worked
        }

        public void Display(HourlyEmployee employeeObj)
        {
            //HourlyEmployee(Display);
            Console.WriteLine("\n  SSN \tName \tHired \t\tAddress \tZip \tWage \tHours \tPay");
            Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.HourlyRate.ToString(),
                employeeObj.HoursWorked.ToString(),
                employeeObj.Earnings.ToString());
        }
    }

    public class CommissionEmployee : Employee
    {
        const int MINSALESMADE = 0;   // Company Minimum Sales Made
        const int MAXSALESMADE = 10000;  // Company Maximum Sales Made

        const int MINSALESPERC = 0;   // Company Minimum SalesPercent Take
        const int MAXSALESPERC = 15;  // Company Maximum SalesPercent Take

        public int MinSalesMade
        {
            get { return MINSALESMADE; }  // Return constant MINSALESMADE
        }

        public int MaxSalesMade  // Company Maximum Sales Made
        {
            get { return MAXSALESMADE; }  // Return constant MAXSALESMADE 
        }

        public int MinSalesPerc
        {
            get { return MINSALESPERC; }  // Return constant MINSALESPERC
        }

        public int MaxSalesPerc  // Company Maximum SalesPercent Take
        {
            get { return MAXSALESPERC; }  // Return constant MAXSALESPERC 
        }

        private float salesMade;
        public float SalesMade
        {
          get { return salesMade; }
          set
            {
                if ((value >= MINSALESMADE) && (value <= MAXSALESMADE))   // Acceptable wages (CA min, Company max)
                { salesMade = value; }
                else
                { 
                    salesMade = 0;
                    ArgumentOutOfRangeException argOORexc = new ArgumentOutOfRangeException();
                    throw argOORexc;
                }
            }
        }

        private float salesPercent;
        public float SalesPercent
        {
          get { return salesPercent; }
          set
            {
                if ((value >= MINSALESPERC) && (value <= MAXSALESPERC))   // Acceptable wages (CA min, Company max)
                { salesPercent = value; }
                else
                { 
                    salesPercent = 0;
                    ArgumentOutOfRangeException argOORexc = new ArgumentOutOfRangeException();
                    throw argOORexc;
                }
            }
       }

        /// <summary>
        /// Default and Overloaded CommissionEmployee constructors to be explicitly invoked
        /// </summary>
        public CommissionEmployee() { }

        public CommissionEmployee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm, string streetParm, int zipCodeParm, 
                                  float salesMadeParm, float salesPercentageParm)
            : base(ssnParm, nameParm, dohParm, earningsParm, streetParm, zipCodeParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            SalesMade = salesMadeParm;
            SalesPercent = salesPercentageParm;
            CalculateEarnings();
        }

        /// <summary>
        /// Override Employee class method to CalculateEarnings of CommissionEmployee
        /// </summary>
        public override void CalculateEarnings()
        { 
             Earnings = SalesMade * SalesPercent / 100;  // Calculate weekly pay for sales made
        }

        public void Display(CommissionEmployee employeeObj)
        {
            //CommissionEmployee(Display);
            Console.WriteLine("\n  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tPay");
            Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6:C.2}%\t${7:C.2}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.SalesMade.ToString(),
                employeeObj.SalesPercent.ToString(),
                employeeObj.Earnings.ToString());
        }
    }

    public class BasePlusCommissionEmployee : CommissionEmployee
    {
        const int MINSALARY = 20000;   // Company Minimum Salary
        const int MAXSALARY = 100000;  // Company Maximum Salary

        public int MinSalary
        {
            get { return MINSALARY; }  // Return constant MINSALARY
        }

        public int MaxSalary  // Maximum Salary paid by the company
        {
            get { return MAXSALARY; }  // Return constant MAXSALARY 
        }

        private float salary;
        public float Salary
        {
            get { return salary; }
            set
            {
                if ((value >= MINSALARY) && (value <= MAXSALARY))   // Acceptable wages (CA min, Company max)
                { salary = value; }
                else
                { 
                    salary = 0;
                    ArgumentOutOfRangeException argOORexc = new ArgumentOutOfRangeException();
                    throw argOORexc;
                }
            }
        }
        /// <summary>
        /// Default and Overloaded BasePlusCommissionEmployee constructors to be explicitly invoked
        /// </summary>
        public BasePlusCommissionEmployee() { }

        public BasePlusCommissionEmployee(string ssnParm, string nameParm, DateTime dohParm, 
                                          float earningsParm, string streetParm, int zipCodeParm, 
                                          float salesMadeParm, float salesPercentageParm, float salaryParm)
            : base(ssnParm, nameParm, dohParm, earningsParm, streetParm, zipCodeParm, salesMadeParm, salesPercentageParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            SalesMade = salesMadeParm;
            SalesPercent = salesPercentageParm;
            Salary = salaryParm;
            CalculateEarnings();
        }

        /// <summary>
        /// Override Employee class method to CalculateEarnings of BasePlusCommissionEmployee
        /// </summary>
        public override void CalculateEarnings() 
        {
            Earnings = SalesMade * SalesPercent / 100;  // Calculate weekly pay for portion of sales made

            Earnings += Salary / 52;  // Calculate weekly pay adding portion of base salary
        }

        public void Display(BasePlusCommissionEmployee employeeObj)
        {
            //BasePlusCommissionEmployee(Display);
            Console.WriteLine("\n  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tSalary \tPay");
            Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6}%\t${7:C.2}\t${8:C.2}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.SalesMade.ToString(),
                employeeObj.SalesPercent.ToString(),
                employeeObj.Salary.ToString(),
                employeeObj.Earnings.ToString());
        }
    }
}
