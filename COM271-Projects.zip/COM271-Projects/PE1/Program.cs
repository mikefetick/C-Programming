﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Practical Exercise 1
 *   Define a set of application-specific Exception classes (2 hours)          
 *   implemented to project 2 - Student Handbook (Pages 46)
 * Date: 9 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Payroll
{
    class Client
    {
        // Declare instance variables. All have private scope
        static ConsoleKeyInfo cki;  // for Console.ReadKey reponse returned
        static bool valid = false;
        static string userInput = "";

        // Lists can be sorted easier than arrays, if sorting is later implemented
        static List<SalariedEmployee>           salariedPersonnel           = new List<SalariedEmployee>();          // Salaried
        static List<HourlyEmployee>             hourlyPersonnel             = new List<HourlyEmployee>();            // Hourly
        static List<CommissionEmployee>         commissionPersonnel         = new List<CommissionEmployee>();        // Commission
        static List<BasePlusCommissionEmployee> basePlusCommissionPersonnel = new List<BasePlusCommissionEmployee>();// Base + Commission
        
        static void CreateHourlyEmployee()
        {
            // Declare the object
            HourlyEmployee employeeObj;
            
            // Prompt for auto-generated data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tHourly Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of HourlyEmployee(ssn, name, doh, earnings, address, zip, rate, regTime, pay, overTime, OTpay)
                employeeObj = new HourlyEmployee("1234", "Jones", DateTime.Parse("04/04/2014"), 0, "123 Blue Dr", 91945, 20, 45, 0, 0, 0);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new HourlyEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Wage:   \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.HourlyRate = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter a wage between "
                                                + employeeObj.MinRate + " and " + employeeObj.MaxRate );
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  8. Hours:  \t");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.HoursWorked = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter hours worked between "
                                                + employeeObj.MinHours + " and " + employeeObj.MaxHours);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
                // Call method to Add element to List<HourlyEmployee>
                hourlyPersonnel.Add(employeeObj);

                // Call object's method to display the object
                employeeObj.Display(employeeObj);
        }

        static void CreateSalariedEmployee()
        {
            // Declare the object
            SalariedEmployee employeeObj;

            // Prompt for auto-generated data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tSalaried Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of SalariedEmployee(ssn, name, doh, earnings, address, zip, salary)
                employeeObj = new SalariedEmployee("3456", "Smith", DateTime.Parse("03/03/2013"), 0, "123 Day Ave", 91945, 40000);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new SalariedEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Salary: \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.Salary = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter salary between "
                                                + employeeObj.MinSalary + " and " + employeeObj.MaxSalary);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
            // Call method to Add element to List<SalariedEmployee>
            salariedPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateCommissionEmployee()
        {
            // Declare the object
            CommissionEmployee employeeObj;

            // Prompt for auto-generated data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tCommission Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of CommissionEmployee(ssn, name, doh, earnings, address, zip, sales made, percent take)
                employeeObj = new CommissionEmployee("5678", "Kramer", DateTime.Parse("02/02/2012"), 0, "555 Man Lane", 91945, 3800, 10);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new CommissionEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Sales:  \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesMade = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales made between "
                                                + employeeObj.MinSalesMade + " and " + employeeObj.MaxSalesMade);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  8. %Take:  \t");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesPercent = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales percentage between "
                                                + employeeObj.MinSalesPerc + " and " + employeeObj.MaxSalesPerc);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
            // Call method to Add element to List<CommissionEmployee>
            commissionPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        static void CreateBasePlusCommissionEmployee()
        {
            // Declare the object
            BasePlusCommissionEmployee employeeObj;

            // Unique Prompt for user data
            Console.Write("\n\n  Employee Record:\n  1. Type: \tBase + Commission Employee \t(Auto-generate data) Y/N? ");
            cki = Console.ReadKey();
            Console.WriteLine();
            if (cki.KeyChar.Equals('Y') || cki.KeyChar.Equals('y'))
            {
                // Instantiate the object initialized
                // of BasePlusCommissionEmployee(ssn, name, doh, earnings, address, zip, sales made, percent take, salary)
                employeeObj = new BasePlusCommissionEmployee("6789", "Tyler", DateTime.Parse("01/01/2011"), 0, "789 Tree Dr", 91945, 2500, 10, 52000);
            }
            else
            // or display unique prompts for user data
            {
                // Instantiate the object uninitialized
                employeeObj = new BasePlusCommissionEmployee();

                // Call method to prompt user for data
                PopulateEmployee(employeeObj);

                // Continue to prompt user for data

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  7. Salary: \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.Salary = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter hours worked between "
                                                + employeeObj.MinSalary + " and " + employeeObj.MaxSalary);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  8. Sales:  \t$");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesMade = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales made between "
                                                + employeeObj.MinSalesMade + " and " + employeeObj.MaxSalesMade);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

                // Loop for valid input
                valid = false;
                do
                {
                    Console.Write("  9. %Take:  \t");

                    // Uses Regular Expression to validate any positive, real number, with optional decimal point 
                    // and numbers after the decimal. http://regexlib.com/REDetails.aspx?regexp_id=117
                    string reg = @"^\d+(\.\d+)?$";
                    userInput = ReadUserInput();

                    try
                    {
                        if (Regex.IsMatch(userInput, reg))
                        {
                            employeeObj.SalesPercent = (float)Convert.ToDecimal(userInput);
                            valid = true;
                        }
                        else
                        {
                            DisplayErrorMessage("     Error, please enter sales percentage between "
                                                + employeeObj.MinSalesPerc + " and " + employeeObj.MaxSalesPerc);
                        }
                    }
                    catch (ArgumentOutOfRangeException aoore)
                    {
                        DisplayErrorMessage("     Error. " + aoore.Message);
                    }
                }
                while (!valid);

            }
            // Call method to Add element to List<CommissionEmployee>
            basePlusCommissionPersonnel.Add(employeeObj);

            // Call object's method to display the object
            employeeObj.Display(employeeObj);
        }

        public static string ReadUserInput()
        {
            userInput = Console.ReadLine();
            Console.CursorTop = Console.CursorTop + 1;
            ClearLine();
            return userInput;
        }

        public static void DisplayErrorMessage(string errMsg)
        {
            Console.Write(errMsg);
            ClearLine();
        }

        public static void ClearLine()
        {
            Console.SetCursorPosition(0, Console.CursorTop - 1);
            Console.Write(new string(' ', Console.WindowWidth));
            Console.SetCursorPosition(0, Console.CursorTop - 1);
        }

        public static void ResetLine()
        {
            Console.CursorTop = Console.CursorTop - 1;
            ClearLine();
            Console.WriteLine();
        }

        static void PopulateEmployee(Employee employeeObj)
        {
            /// Avoid exceptions during runtime

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  2. SSN-last4:\t");
                employeeObj.Ssn = ReadUserInput();

                // Uses Regular Expression to validate data
                string reg = @"^\d{4}$";

                if (Regex.IsMatch(employeeObj.Ssn, reg))
                {
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  3. LastName:\t");
                employeeObj.Name = ReadUserInput();

                if (!string.IsNullOrEmpty(employeeObj.Name))
                {
                    // Accept substring of fixed length
                    if (employeeObj.Name.Length > 6)
                    {
                        employeeObj.Name = string.Format(employeeObj.Name).Substring(0, 6);
                    }
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Present today's date as a default for user
                string dateToday = DateTime.Now.ToShortDateString();
                Console.Write("  4. Hired:  \t{0}", dateToday);

                // Position the prompt for data at the beginning of the date
                Console.CursorLeft = Console.CursorLeft - dateToday.Length;
                userInput = ReadUserInput();

                if (userInput == "")
                {
                    userInput = dateToday;
                }

                // Handle exceptions during runtime
                try
                {
                    employeeObj.DateOfHire = Convert.ToDateTime(userInput);
                    valid = true;
                }
                catch (FormatException)
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  5. Address:\t");
                employeeObj.Street = ReadUserInput();

                if (!string.IsNullOrEmpty(employeeObj.Street))
                {
                    // Accept substring of fixed length
                    if (employeeObj.Street.Length > 8)
                    {
                        employeeObj.Street = string.Format(employeeObj.Street).Substring(0, 8);
                    }
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);

            // Loop for valid input
            valid = false;
            do
            {
                // Prompt user for data
                Console.Write("  6. Zipcode:\t");

                // Uses Regular Expression to validate data
                string reg = @"^\d{5}$";
                userInput = ReadUserInput();

                if (Regex.IsMatch(userInput, reg))
                {
                    employeeObj.Zipcode = Convert.ToInt32(userInput);
                    valid = true;
                }
                else
                {
                    DisplayErrorMessage("     Error, please try again.");
                }
            }
            while (!valid);
        }

        static void DisplayPersonnelReport()
        {
            Console.WriteLine("\n\n  Totals:\t\t\tPersonnel Report (All Employees)");

            // Tally of SalariedEmployee
            Console.WriteLine("\n  ({0}) Salaried Employees - - - - - - - - - - - - - - - - - - - - - - - - - - -",
                salariedPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSalary \tPay");

            // Loop through elements of SalariedEmployee(ssn, name, doh, address, zip, salary, pay)
            foreach (SalariedEmployee salariedEmployee in salariedPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t${6:C.2}",
                    salariedEmployee.Ssn,
                    salariedEmployee.Name,
                    salariedEmployee.DateOfHire.ToShortDateString(),
                    salariedEmployee.Street,
                    salariedEmployee.Zipcode.ToString(),
                    salariedEmployee.Salary.ToString(),
                    salariedEmployee.Earnings.ToString());  // Calculated weekly pay from annual salary
            }

            // Tally of HourlyEmployee
            Console.WriteLine("\n  ({0}) Hourly Employees - - - - - - - - - - - - - - - - - - - - - - - - - - - -",
                hourlyPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tWage \tHours \tPay");

            // Loop through elements of HourlyEmployee(ssn, name, doh, address, zip, rate, regTime, pay, overTime, OTpay)
            foreach (HourlyEmployee hourlyEmployee in hourlyPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                    hourlyEmployee.Ssn,
                    hourlyEmployee.Name,
                    hourlyEmployee.DateOfHire.ToShortDateString(),
                    hourlyEmployee.Street,
                    hourlyEmployee.Zipcode.ToString(),
                    hourlyEmployee.HourlyRate.ToString(),
                    hourlyEmployee.HoursWorked.ToString(),
                    hourlyEmployee.Earnings.ToString());
            }

            // Tally of CommissionEmployee
            Console.WriteLine("\n  ({0}) Commission Employee  - - - - - - - - - - - - - - - - - - - - - - - - - - ",
                commissionPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tPay");

            // Loop through elements of CommissionEmployee(ssn, name, doh, address, zip, sales made, percent take, pay)
            foreach (CommissionEmployee commissionEmployee in commissionPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6}%\t${7:C.2}",
                    commissionEmployee.Ssn,
                    commissionEmployee.Name,
                    commissionEmployee.DateOfHire.ToShortDateString(),
                    commissionEmployee.Street,
                    commissionEmployee.Zipcode.ToString(),
                    commissionEmployee.SalesMade.ToString(),
                    commissionEmployee.SalesPercent.ToString(),
                    commissionEmployee.Earnings.ToString());
            }
            // Tally of BasePlusCommissionEmployee
            Console.WriteLine("\n  ({0}) Base+ Commission Employee  - - - - - - - - - - - - - - - - - - - - - - - ",
                basePlusCommissionPersonnel.Count());
            Console.WriteLine("  SSN \tName \tHired \t\tAddress \tZip \tSales \t%Take \tSalary \tPay");

            // Loop through elements of BasePlusCommissionEmployee(ssn, name, doh, address, zip, sales made, percent take, salary, pay)
            foreach (BasePlusCommissionEmployee basePlusCommissionEmployee in basePlusCommissionPersonnel)
            {
                Console.WriteLine("  {0}\t{1}\t{2}\t{3}\t{4}\t${5:C.2}\t{6}%\t${7:C.2}\t${8:C.2}",
                    basePlusCommissionEmployee.Ssn,
                    basePlusCommissionEmployee.Name,
                    basePlusCommissionEmployee.DateOfHire.ToShortDateString(),
                    basePlusCommissionEmployee.Street,
                    basePlusCommissionEmployee.Zipcode.ToString(),
                    basePlusCommissionEmployee.SalesMade.ToString(),
                    basePlusCommissionEmployee.SalesPercent.ToString(),
                    basePlusCommissionEmployee.Salary.ToString(),
                    basePlusCommissionEmployee.Earnings.ToString());
            }
            Console.WriteLine("\n   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \n");
        }

        static void Main(string[] args)
        {
            // Interact with the user at the console with defaults: System, standard out, standard in
            Console.WriteLine("\n  Project 2 - Michael Fetick, 84270");

            bool wantToQuit = false; // default
            do
            {
                // Do-while not wantToQuit (loop)
                if (!wantToQuit)
                {
                    // Prompt user to select employee type
                    Console.WriteLine
                        ("\n  Employee types: 'S' Salaried, 'H' Hourly, 'C' Commission, 'B' Base+Commission");
                    Console.Write
                        ("  Enter letter for employee type or 'Q' to quit: ");

                    // The reponse returned from Console.ReadKey is a ConsoleKeyInfo type,
                    //  refer to the ConsoleKey Enumeration set for values
                    cki = Console.ReadKey();

                    // Switch-Case to match employee type {S, H, C, B}, fall-through is used, 
                    // call method to prompt user to populate fields of the object;
                    // or quit {Q}. 
                    switch (cki.KeyChar)
                    {
                        case 'S': // Salaried employee
                        case 's': 
                            ResetLine();
                            CreateSalariedEmployee();
                            break;

                        case 'H': // Hourly employee
                        case 'h': 
                            ResetLine();
                            CreateHourlyEmployee();
                            break;

                        case 'C': // Commission employee
                        case 'c': 
                            ResetLine();
                            CreateCommissionEmployee();
                            break;

                        case 'B': // BasePlusCommission employee
                        case 'b': 
                            ResetLine();
                            CreateBasePlusCommissionEmployee();
                            break;

                        case 'Q': // Quit and display tally of employee types
                        case 'q':
                            wantToQuit = true; // quit program
                            ResetLine();
                            DisplayPersonnelReport();
                            break;
                        
                        default:
                            Console.WriteLine();
                            DisplayErrorMessage("     Error, please try again.");
                            Console.CursorTop = Console.CursorTop - 2;
                            break;
                    }
                }
            } while (!wantToQuit);
        }
    }
}
