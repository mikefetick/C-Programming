﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: 
 * Practical Exercise 4 - 
 * 
 * Lesson 19 - Winforms (Student Manual, page 122)
 *   A Windows Form Application that will allow you 
 *   to review the Deposits and Withdrawals 
 *   for a specified Customer Account.
 *
 * Date: 24 April 2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lesson19App
{
    public partial class ReviewTransactions : Form
    {
        string connectionString = "Data Source=172.16.2.34;" +
                "User id=db84270;" +
                "password=5a0c1de0;" +
                "Initial Catalog=db84270";

        public ReviewTransactions()
        {
            InitializeComponent();
            // Display the window in the center of the screen
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        public SqlConnection CreateConnection()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

        public string GetCustomerName(int custId)
        {
            string name = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            string query = @"
                SELECT customer_name 
                FROM customers_t
                WHERE customer_id = " + custId.ToString();

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                name = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                    connection = null;
            }
            return name;
        }

        public string GetAccountNumber(int custId, string acctType)
        {
            string accountNumber = String.Empty;
            SqlConnection connection = CreateConnection();

            SqlCommand command = null;

            // Include tick marks in the string for the variable
            string query = @"
                SELECT account_number 
                FROM accounts_t
                WHERE customer_id = '" + custId.ToString() 
                   + "' AND account_type = '" + acctType + "'";

            try
            {
                connection.Open();
                command = new SqlCommand(query, connection);
                accountNumber = command.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                    connection.Close();
                connection = null;
            }

            return accountNumber;
        }

        public void PopulateListBox(string acct_num)
        {
            decimal totalDeposits = 0.00M;
            decimal totalWithdrawals = 0.00M;

            string strAmount = string.Empty;

            lstTransactions.Items.Clear();
            lstTransactions.BeginUpdate();
            lstTransactions.Items.Add("Deposits".PadLeft(19) +
                "Withdrawals".PadLeft(14));

            SqlDataAdapter da = null;
            DataSet ds = null;
            DataTable dt = null;

            string query = @"
                SELECT transaction_type, amount
                    FROM transactions_t
                    WHERE account_number = " + acct_num;

            SqlConnection connection = CreateConnection();
            connection.Open();

            // The keyword using() can get the database to handle the SQL exceptions.
            //using (da = new SqlDataAdapter(query, connection))
            //using (ds = new DataSet())

            // When a data record is missing a foreign key, then a SQL exception of 
            // "Object reference not set to an instance of an object" is thrown...
            // A try-catch block can handle the SQL exceptions.
            try
            {
                da = new SqlDataAdapter(query, connection);
                ds = new DataSet();

                da.Fill(ds, "transactions_t");
                dt = ds.Tables["transactions_t"];

                foreach (DataRow row in dt.Rows)
                {
                    if (row["transaction_type"].Equals("D"))
                    {
                        totalDeposits += Convert.ToDecimal(row["amount"]);

                        strAmount = string.Format("{0:N}", row["amount"]);
                        lstTransactions.Items.Add(strAmount.PadLeft(19));
                    }
                    else
                    {
                        totalWithdrawals += Convert.ToDecimal(row["amount"]);

                        strAmount = string.Format("{0:N}", row["amount"]);
                        lstTransactions.Items.Add("".PadLeft(19) +
                             strAmount.PadLeft(14));
                    }
                }

                lstTransactions.Items.Add("Total:" +
                    string.Format("{0:N}", totalDeposits).PadLeft(13) +
                    string.Format("{0:N}", totalWithdrawals).PadLeft(14));

                lstTransactions.EndUpdate();
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show(sqlEx.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                lstTransactions.EndUpdate();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            if (!txtCustomerNumber.Text.Equals(String.Empty))
            {

                int id = Convert.ToInt32(this.txtCustomerNumber.Text);
                string acctType = String.Empty;

                if (rbChecking.Checked)
                {
                    acctType = "C";
                }
                else
                {
                    acctType = "S";
                }

                lblCustName.Text = GetCustomerName(id);
                lblAccountNumber.Text = GetAccountNumber(id, acctType);
                PopulateListBox(lblAccountNumber.Text);
            }
            else
            {
                MessageBox.Show("You must enter a Customer Number",
                  "No Customer Number");
            }
        }

        private void ReviewTransactions_Load(object sender, EventArgs e)
        {

        }
    }
}
/*
Note: When you execute this program, only customers 3 and 7 
      have transactions recorded in the database. 
      Only customer 3 has a Checking and a Savings account.

*/