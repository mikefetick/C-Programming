﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FirstProgram
{
    //A class doesn't do any work until I instatiate an object of the class
    class FirstClass  
    {
        //Data Members -- state 
        int bananas;
        int apples = 15; //Field

        public int Apples
        {
            get { return apples; }
            set { apples = value; }
        }

        //Properties
        public int Bananas
        {
            get { return bananas; }
            set 
            { 
                if (value > 100)
                {
                    value = 100;
                }
                bananas = value; 
            }
        }

        //Member Functions -- behavior

        //Instance Constructor
        public FirstClass() //Default constructor
        {
            Bananas = 56;
        }

        //Overloaded Constructor
        public FirstClass(int Bvalue, int apples) 
        {
            Bananas = Bvalue;
            this.apples = apples;  //instance variable is used because we don't have a property created for it.
        }

        public void Display()
        {
            Console.WriteLine("Bananas = {0}", bananas);
            Console.WriteLine("Apples = {0}", apples);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Instantiation of the class
            FirstClass fcObj = new FirstClass();
            //fcObj.Bananas = 120;  //Not needed because we have a constructor

            //Make the method Display public to access it below
            fcObj.Display();
            //Debug - Start without Debugging 

            //Create another object
            FirstClass otherObj = new FirstClass();
            fcObj.Bananas = 32;
            otherObj.Display();

            Console.WriteLine();

            //Instantiate an object by using the overloaded constructor
            FirstClass oObj = new FirstClass(12, 45);
            oObj.Display();
        }
    }
}
