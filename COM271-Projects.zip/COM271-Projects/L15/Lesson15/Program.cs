﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Lesson 15 -
 *   Log on to MS SqlServer with the Management Studio
 *   and create the table customers_t,
 *   Use a data reader to display field values.
 *
 * Date: 21 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Lesson15
{
    public class DisplayCustomerTable
    {
        static void Main(string[] args)
        {
            DisplayCustomerInfo();
            System.Console.WriteLine("\n\nPress ENTER to continue.");
            System.Console.ReadLine();
        }

        private static void DisplayCustomerInfo()
        {
            SqlConnection connection = null;

            SqlCommand command = null;

            // You use a data reader to read data in a forward only mode, 
            // to only display field values, 
            // or to loop through thousands or millions of rows.
            SqlDataReader reader = null;

            string connection_string = "Data Source=172.16.2.34;" +
                    "User id=db84270;" +
                    "password=5a0c1de0;" +
                    "Initial Catalog=db84270";

            string query = @"
                    SELECT
                        c.customer_id         AS 'ID',
                        c.customer_name       AS 'NAME' 
                    FROM  customers_t   AS  c";

            try
            {
                connection = new SqlConnection(connection_string);

                connection.Open();
                System.Console.WriteLine("Connection  Opened");


                command = new SqlCommand(query, connection);

                System.Console.WriteLine("Command     Configuration");

                reader = command.ExecuteReader();

                System.Console.WriteLine("Command     Executed");

                do
                {
                    while (reader.Read())
                    {
                        Console.WriteLine("CUSTOMER_ID     : {0}", reader["ID"]);
                        Console.WriteLine("CUSTOMER_NAME   : {0}", reader["NAME"]);
                    }

                } while (reader.NextResult());

                reader.Close();
            }

            catch (SqlException ex)
            {
                System.Console.WriteLine("Error     : " + "SqlException");
                System.Console.WriteLine("Message   : " + ex.Message);
            }

            catch (Exception ex)
            {
                System.Console.WriteLine("Error     : " + "Exception");
                System.Console.WriteLine("Message   : " + ex.Message);
            }

            finally
            {
                reader = null;

                command = null;

                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    System.Console.WriteLine("Connection  Closed");
                }

                connection.Dispose();
            }

        }
    }
}
/*
Connection  Opened
Command     Configuration
Command     Executed
CUSTOMER_ID     : 1
CUSTOMER_NAME   : Freddie The Freeloader
CUSTOMER_ID     : 2
CUSTOMER_NAME   : Susan Of The Savanah
CUSTOMER_ID     : 3
CUSTOMER_NAME   : George Of The Jungle
CUSTOMER_ID     : 4
CUSTOMER_NAME   : Mary Quite Contrary
CUSTOMER_ID     : 5
CUSTOMER_NAME   : Moe Rocca
CUSTOMER_ID     : 6
CUSTOMER_NAME   : Kathleen Turner
CUSTOMER_ID     : 7
CUSTOMER_NAME   : Adalwolf Heinz
CUSTOMER_ID     : 8
CUSTOMER_NAME   : Edgardo Fernandez
CUSTOMER_ID     : 9
CUSTOMER_NAME   : Zuleika Andressa
CUSTOMER_ID     : 10
CUSTOMER_NAME   : Winona Franklin
Connection  Closed


Press ENTER to continue.
*/