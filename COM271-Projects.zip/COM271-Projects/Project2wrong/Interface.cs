﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 2 - Student Handbook (Pages 46)
 * Date: 31 March 2014 - 7 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Payroll
{
    //Interface is a reference type that represents a set of function members,
    //but does not implement them. They cannot have constructors.
    //It is like a class where all methods are abstract.

    //Interface can only contain declaration of following kinds of function members:
    //  -- Methods
    //  -- Properties
    //  -- Events
    //  -- Indexers

    //Cannot contain 
    //  --any implementations
    //  --data members

    //by convention must begin with a "I" prefix    // An interfaces is named with an 'I' character prefix

    interface IAddress1
    {
        private string street;
        public string Street
        {
            get { return street; }
            set { street = value; }
        }
        private int zipCode;
        public int ZipCode
        {
            get { return zipCode; }
            set { zipCode = value; }
        }
    }

    // Interfaces can inherit from other interfaces
    interface IEmployee : IAddress1
    {
        private string street;
        public string Street
        {
            get { return street; }
            set { street = value; }
        }
        private int zipcode;
        public int Zipcode
        {
            get { return zipcode; }
            set
            {
                if ((value > 9999) && (value < 100000))
                { zipcode = value; }
                else
                { zipcode = 0; }
            }
        }
        private string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string ssn;
        public string Ssn
        {
            get { return ssn; }
            set { ssn = value; }
        }
        private DateTime dateOfHire;
        public DateTime DateOfHire
        {
            get { return dateOfHire; }
            set
            {
                if (value != null)
                { dateOfHire = value; }
                else
                { dateOfHire = DateTime.Now; }
            }
        }
        private float earnings;
        public float Earnings
        {
            get { return earnings; }
            set { earnings = value; }
        }
        //void CalculateEarnings();
        /// <summary>
        /// Abstract class to CalculateEarnings of Employee
        /// </summary>
        public abstract void CalculateEarnings()
        {
            Earnings = 0;
        }
    }
    // Type inherited from another interface
    interface ISalariedEmployee : IEmployee
    {
        private float salary;
        public float Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        void CalculateEarnings();
        /// <summary>
        /// Override Employee class method to CalculateEarnings of SalariedEmployee
        /// </summary>
        public override void CalculateEarnings
        { 
             Earnings = Salary / 52;  // Calculate weekly pay from annual salary
        }
    }

    // Type inherited from another interface
    interface IHourlyEmployee : IEmployee
    {
        const int MINRATE = 8;   // California Minimum Wage Rate
        const int MAXRATE = 50;  // Company Maximum Wage Rate
        const int MINHOURS = 0;  // Minimum Regular Hours Worked per week
        const int MAXHOURS = 40; // Maximum Regular Hours Worked per week

        public int MaxHours  // Maximum Regular Hours Worked per week
        {
            get { return MAXHOURS; }  // Return constant MAXHOURS 
        }

        public int MinHours 
        {
            get { return MINHOURS; }  // Return constant MINHOURS
        }   

        private float hourlyRate;
        public float HourlyRate
        {
            get { return hourlyRate; }
            set
            {
                if ((value >= MINRATE) && (value <= MAXRATE))   // Acceptable wages (CA min, Company max)
                { hourlyRate = value; }
                else
                { hourlyRate = 0; }
            }
        }

        private float hoursWorked;
        public virtual float HoursWorked
        {
            get { return hoursWorked; }
            set
            {
                if ((value >= MinHours) && (value <= 168))   // Accepting valid input of HoursWorked, 24x7=168
                {
                    if (value > MaxHours)   // Hours worked Over maximum regular hours
                    {
                        hoursWorked = value;         // Hours worked as regular hours
                        OverTime = value - MaxHours;  // Hours worked as overtime hours
                        hoursWorked = MaxHours;         // Hours worked as regular hours
                    }
                    else   // Hours worked Under maximum regular hours
                    {
                        hoursWorked = value;            // Hours worked as regular hours
                    }
                }
                else   // Not accepting invalid input of hours worked
                {
                    hoursWorked = 0;
                }
            }
        }

        public float RegTimePay
        {
            get { return HourlyRate * HoursWorked; }
            set { }
        }

        private float overTime;
        public float OverTime
        {
            get { return overTime; }

            // Value is the amount Over the constant MAXHOURS // Maximum Regular Hours Worked per week
            set
            {
                // Calculate the value only if the result will not be negative
                if (HoursWorked <= MaxHours)  // Hours worked weekly as regular time (min:0, max:40)
                { overTime = 0; }

                if (HoursWorked > MaxHours)   // Hours worked weekly over regular time maximum.
                { overTime = HoursWorked - MaxHours; }
            }
        }

        public float OverTimePay  // OverTimePay
        {
            get { return (OverTime * HourlyRate * (float)1.5); }
            set { }
        }

        /// <summary>
        /// Override Employee class method to CalculateEarnings of HourlyEmployee
        /// </summary>
        public override void CalculateEarnings() 
        { 
             Earnings = RegTimePay + OverTimePay;  // Calculate weekly pay for time worked
        }

        void CalculateEarnings();
    }

    // Type inherited from another interface
    interface ICommissionEmployee : IEmployee
    {
        private float salesMade;
        public float SalesMade
        {
          get { return salesMade; }
          set { salesMade = value; }
        }

        private float salesPercent;
        public float SalesPercent
        {
          get { return salesPercent; }
          set { salesPercent = value; }
        }

        /// <summary>
        /// Override Employee class method to CalculateEarnings of CommissionEmployee
        /// </summary>
        public override void CalculateEarnings() 
        { 
             Earnings = SalesMade * SalesPercent;  // Calculate weekly pay for sales made
        }

        void CalculateEarnings();
    }

    // Type multi-inherited from other interfaces
    interface IBasePlusCommissionEmployee : ICommissionEmployee, ISalariedEmployee
    {
        /// <summary>
        /// Override Employee class method to CalculateEarnings of BasePlusCommissionEmployee
        /// </summary>
        override void CalculateEarnings() 
        {
            Earnings = SalesMade * SalesPercent;  // Calculate weekly pay for portion of sales made

            Earnings =+ Salary;  // Calculate weekly pay adding portion of base salary
        }

        void CalculateEarnings();
    }
}
