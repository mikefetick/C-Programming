﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: Project 2 - Student Handbook (Pages 46)
 * Date: 31 March 2014 - 7 April 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Payroll
{
    public class Employee : IAddress1, IEmployee
    {

        /// <summary>
        /// Abstract class to CalculateEarnings of Employee
        /// </summary>
        abstract void CalculateEarnings()
        {
             Earnings = 0;
        }

        /// <summary>
        /// Static constructor cannot be explicitly invoked
        /// </summary>
        static Employee() { }

        /// <summary>
        /// Non-Static constructor is explicitly invoked
        /// </summary>
        public Employee() { }

        /// <summary>
        /// Overloaded Employee constructor to be explicitly invoked
        /// </summary>
        public Employee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm,
            string streetParm, int zipCodeParm)
  
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Earnings = earningsParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
        }
    }
     
    public class SalariedEmployee : ISalariedEmployee
    {
        /// <summary>
        /// Default and Overloaded SalariedEmployee constructors to be explicitly invoked
        /// </summary>
        public SalariedEmployee()
        { Salary = 0; }

        public SalariedEmployee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm,
                                string streetParm, int zipCodeParm,
                                float salaryParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Earnings = earningsParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            Salary = salaryParm;
            CalculateEarnings();
        }

        public void Display(SalariedEmployee employeeObj)
        {
            //SalariedEmployee(Display);
            Console.WriteLine("\n SSN   \tName \t  Hired Address \tZip \tSalary \tPay");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}\t${6:C.2}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.Salary.ToString(),
                employeeObj.Earnings.ToString());
        }
    }

    public class HourlyEmployee : IEmployee
    {
        /// <summary>
        /// Default and Overloaded HourlyEmployee constructors to be explicitly invoked
        /// </summary>
        public HourlyEmployee() { }

        public HourlyEmployee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm,
                                string streetParm, int zipCodeParm,
                                float hourlyRateParm, float hoursWorkedParm, float regTimePayParm, float overTimeParm, float overTimePayParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            HourlyRate = hourlyRateParm;
            HoursWorked = hoursWorkedParm;
            RegTimePay = regTimePayParm;
            OverTime = overTimeParm;
            OverTimePay = overTimePayParm;
            CalculateEarnings();
        }

        public void Display(HourlyEmployee employeeObj)
        {
            //HourlyEmployee(Display);
            Console.WriteLine("\n SSN   \tName \tHired \t  Address \tZip \tWage \tHours \tPay");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.HourlyRate.ToString(),
                employeeObj.HoursWorked.ToString(),
                employeeObj.Earnings.ToString());
        }
    }

    public class CommissionEmployee : IEmployee
    {
        /// <summary>
        /// Default and Overloaded CommissionEmployee constructors to be explicitly invoked
        /// </summary>
        public CommissionEmployee() { }

        public CommissionEmployee(string ssnParm, string nameParm, DateTime dohParm, float earningsParm, string streetParm, int zipCodeParm, 
                                  float salesMadeParm, float salesPercentageParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            SalesMade = salesMadeParm;
            SalesPercent = salesPercentageParm;
            CalculateEarnings();
        }

        public void Display(CommissionEmployee employeeObj)
        {
            //CommissionEmployee(Display);
            Console.WriteLine("\n SSN   \tName \tHired \t  Address \tZip \tSales \tTake \tPay");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}\t{6:C.2}%\t${7:C.2}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.SalesMade.ToString(),
                employeeObj.SalesPercent.ToString(),
                employeeObj.Earnings.ToString());
        }
    }

    public class BasePlusCommissionEmployee : ICommissionEmployee
    {
        /// <summary>
        /// Default and Overloaded BasePlusCommissionEmployee constructors to be explicitly invoked
        /// </summary>
        public BasePlusCommissionEmployee() { }

        public BasePlusCommissionEmployee(string ssnParm, string nameParm, DateTime dohParm, 
                                          float earningsParm, string streetParm, int zipCodeParm, 
                                          float salesMadeParm, float salesPercentageParm, float salaryParm)
        {
            Ssn = ssnParm;
            Name = nameParm;
            DateOfHire = dohParm;
            Street = streetParm;
            Zipcode = zipCodeParm;
            SalesMade = salesMadeParm;
            SalesPercent = salesPercentageParm;
            Salary = salaryParm;
            CalculateEarnings();
        }

        public void Display(BasePlusCommissionEmployee employeeObj)
        {
            //BasePlusCommissionEmployee(Display);
            Console.WriteLine("\n SSN   \tName \tHired \t  Address \tZip \tWage \tHours \tPay \tFee");
            Console.WriteLine(" {0}\t{1}\t{2} {3}\t{4}\t${5:C.2}/hr\t{6}\t${7:C.2}\t${8:C.2}",
                employeeObj.Ssn.ToString(),
                employeeObj.Name,
                employeeObj.DateOfHire.ToShortDateString(),
                employeeObj.Street,
                employeeObj.Zipcode.ToString(),
                employeeObj.SalesMade.ToString(),
                employeeObj.SalesPercent.ToString(),
                employeeObj.Earnings.ToString());
        }
    }
}
