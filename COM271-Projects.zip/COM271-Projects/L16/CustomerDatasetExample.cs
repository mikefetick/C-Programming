﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM271A-0314 C# Programming II (Ganore) 006
 * Student: Michael Fetick, 84270
 * Assignment: 
 * Practical Exercise 4 - 
 *   Implement a connection pool of SQL Connection objects 
 *   using generic data structure
 * Lesson 16 -
 *   Microsoft SqlServer – Disconnected Objects
 *   SqlDataAdapter, DataSets, DataTable, and DataRow
 *
 * Date: 24 April 2014
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Lesson16
{
    class CustomerDatasetExample
    {
        static void Main(string[] args)
        {
            DisplayCustomerInfo();

            System.Console.WriteLine("\n\nPress ENTER to continue.");
            System.Console.ReadLine();
        }

        private static void DisplayCustomerInfo()
        {
            SqlConnection connection = null;

            // You use a DataAdapter to read data for disconnected processing.
            SqlDataAdapter da = null;

            DataSet ds = null;

            DataTable dt = null;

            string connection_string = "Data Source=172.16.2.34;" +
                    "User id=db84270;" +
                    "password=5a0c1de0;" +
                    "Initial Catalog=db84270";
 
            string query = @"
                     SELECT
                         c.customer_id         AS 'ID',
                         c.customer_name       AS 'NAME' 
                     FROM  customers_t   AS  c";
            try
            {
                connection = new SqlConnection(connection_string);

                connection.Open();

                System.Console.WriteLine("Connection  Opened");

                da = new SqlDataAdapter(query, connection);

                ds = new DataSet();

                da.Fill (ds, "CUSTOMERS");

                dt = ds.Tables["CUSTOMERS"];

                foreach (DataRow row in dt.Rows)
                {

                    System.Console.WriteLine("{0} {1}", 
                        row["ID"], row["NAME"]);
                }
            }

            catch (SqlException ex)
            {
                System.Console.WriteLine("Error     : " + "SqlException");
                System.Console.WriteLine("Message   : " + ex.Message);
            }

            catch (Exception ex)
            {
                System.Console.WriteLine("Error     : " + "Exception");
                System.Console.WriteLine("Message   : " + ex.Message);
            }

            finally
            {
                dt = null;

                da = null;

                ds = null; 
                
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                    System.Console.WriteLine("Connection  Closed");
                }
                connection.Dispose();
            }
        }
    }
}
/*
Connection  Opened
1 Freddie The Freeloader
2 Susan Of The Savanah
3 George Of The Jungle
4 Mary Quite Contrary
5 Moe Rocca
6 Kathleen Turner
7 Adalwolf Heinz
8 Edgardo Fernandez
9 Zuleika Andressa
10 Winona Franklin
Connection  Closed


Press ENTER to continue.
*/