﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Textbox
{
   public partial class _Default : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         lblMessage.Text = "Provided by the Page_Load event";
      }
      protected void txtInput_TextChanged(object sender, EventArgs e)
      {
         txtEcho.Text = txtInput.Text;
      }
   }
}