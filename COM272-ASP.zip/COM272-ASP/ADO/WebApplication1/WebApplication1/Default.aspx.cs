﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data.SqlClient; // have to add this to the item

namespace WebApplication1
{
   public partial class _Default : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {

      }

      public static SqlConnection GetConnectionAtHome()
      {
         //  Create... Connection
         SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

         /* TO CONNECT AT HOME - LOCALHOST
          */
         builder.DataSource = @"(localdb)\Projects";
         builder.InitialCatalog = "db84270";
         builder.IntegratedSecurity = true;
         builder.ConnectTimeout = 30;
         builder.Encrypt = false;
         builder.TrustServerCertificate = false;
         //
         return new SqlConnection(builder.ConnectionString);
      }

      public static SqlConnection GetConnectionAtSchool()
      {
         //  Create... Connection
         SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

         /* TO CONNECT AT SCHOOL - COLEMAN UNIVERSITY
          */
         builder.DataSource = "mssql-2-34";
         builder.UserID = "db84270";
         builder.InitialCatalog = "db84270";
         builder.Password = "5a0c1de0";
         //
         return new SqlConnection(builder.ConnectionString);
      }

      protected void submitButton_Click(object sender, EventArgs e)
      {
         // Declare objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;

         // Select a connection between AtHome or AtSchool
         //conn = GetConnectionAtSchool();
         conn = GetConnectionAtHome();
/*
         // Initialize connection
         conn = new SqlConnection(
            @"Data Source=172.16.2.34; 
            Initial Catalog=db84270; 
            User ID=db84270; 
            Password=5a0c1de0");
*/

         // Create command
         comm = new SqlCommand(
            "SELECT EmployeeId, Name, Username, Password " +
            "FROM gp_Employee WHERE EmployeeId = @EmployeeId", conn);

         // Verify if the ID entered by the visitor is numeric
         int employeeId;
         if (!int.TryParse(idTextBox.Text, out employeeId))
         {
            // If the user didn't enter numeric ID
            userLabel.Text = "Please enter a numeric ID!";
         }
         else
         {
            // Add parameter    
            comm.Parameters.Add("@EmployeeId", System.Data.SqlDbType.Int);
            comm.Parameters["@EmployeeId"].Value = employeeId;

            // Enclose database code in Try-Catch-Finally
            try
            {
               // Open the connection
               conn.Open();

               // Execute the command
               reader = comm.ExecuteReader();

               // Bind the repeater to the data source
               myRepeater.DataSource = reader;
               myRepeater.DataBind();

               // Display the requested data
               if (reader.Read())
               {
                  userLabel.Text =
                     "Employee Id: " + reader["EmployeeId"] + "<br />"
                         + "Name: " + reader["Name"] + "<br />"
                     + "Username: " + reader["Username"] + "<br />"
                     + "Password: " + reader["Password"];
               }
               else
               {
                  userLabel.Text =
                     "There is no user with this Id: " + employeeId;
               }

               // Close the reader and the connection
               reader.Close();
            }  // end try

            catch
            {
               // Display error message
               userLabel.Text = "Error retrieving user data.";
            }  // end catch

            finally
            {
               // Close the connection
               conn.Close();
            }  // end finally

         }  // end of submitButton_Click()
      }
   }
}