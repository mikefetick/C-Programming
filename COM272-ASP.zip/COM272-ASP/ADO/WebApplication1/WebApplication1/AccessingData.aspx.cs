﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient; // have to add this to the item

namespace WebApplication1
{
   public partial class AccessingData : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         // Define database connection
         SqlConnection conn = new SqlConnection(
            @"Data Source=172.16.2.34; 
            Initial Catalog=db84270; 
            User ID=db84270; 
            Password=5a0c1de0");
      
         // Create command object
         SqlCommand comm = new SqlCommand(
         "SELECT EmployeeId, Name FROM gp_Employee", conn);

         // Open connection
         conn.Open();
         
         // Execute the command
         SqlDataReader reader = comm.ExecuteReader();

         // Read and display the data
         while (reader.Read())
         {
            employeesLabel.Text += reader["Name"] + "<br />";
         }

         // Do something with the data
         // Close the reader and the connection
         reader.Close();
         conn.Close();
      }
   }
}