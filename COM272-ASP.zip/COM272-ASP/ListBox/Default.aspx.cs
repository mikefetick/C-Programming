﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RadioButton
{
   public partial class _Default : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {

      }
      protected void grpColor_CheckedChanged(object sender, EventArgs e)
      {
         if (rdoRed.Checked)
         {
            lblColor.Text = "The radio button changed the color to Red.";
            lblColor.ForeColor = System.Drawing.Color.Red;
         }
         else
            if (rdoBlue.Checked)
            {
               lblColor.Text = "The radio button changed the color to Blue.";
               lblColor.ForeColor = System.Drawing.Color.Blue;
            }
            else
            {
               lblColor.Text = "The radio button changed the color to Green.";
               lblColor.ForeColor = System.Drawing.Color.Green;
            }
      }
      protected void lblColor_Init(object sender, EventArgs e)
      {
         lblColor.Font.Name = "Verdana";
         lblColor.Font.Size = 20;
         lblColor.Font.Bold = true;
         lblColor.Font.Italic = true;
         lblColor.Text = "The color has not been selected.";
      }

      protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
      {
         lblColor.Text = "The RadioButtonList selected item changed the color to " + RadioButtonList1.SelectedItem.Text;
         lblColor.ForeColor = System.Drawing.Color.FromName(RadioButtonList1.SelectedItem.Value);
      }

      protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
      {
         lblColor.Text = "The ListBox selected item changed the color to " + ListBox1.SelectedItem.Text;
         lblColor.ForeColor = System.Drawing.Color.FromName(ListBox1.SelectedItem.Value);
      }

      protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
      {
         lblColor.Text = "The DropDownList selected item changed the color to " + DropDownList1.SelectedItem.Text;
         lblColor.ForeColor = System.Drawing.Color.FromName(DropDownList1.SelectedItem.Value);
      }
   }
}