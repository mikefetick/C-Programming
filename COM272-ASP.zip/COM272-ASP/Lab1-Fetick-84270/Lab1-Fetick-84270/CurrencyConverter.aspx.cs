﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab1_Fetick_84270
{
   public partial class CurrencyConverter : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         Currency.Items.Add("Euros");
         Currency.Items.Add("Japanese Yen");
         Currency.Items.Add("Canadian Dollars");
      }
      protected void Convert_ServerClick(object sender, EventArgs e)
      {
         decimal amount = decimal.Parse(US.Value);

         ListItem item = Currency.Items[Currency.SelectedIndex];
         decimal newAmount = amount * Decimal.Parse(item.Value);
         Result.InnerText = amount.ToString() + " U.S. dollars = ";
         Result.InnerText += newAmount.ToString() + " " + item.Text;
         
         /*
         decimal USAmount = decimal.Parse(US.Value);
         decimal euroAmount = USAmount * 0.85M;
         Result.InnerText = USAmount.ToString() + " U.S. dollars = ";
         Result.InnerText += euroAmount.ToString() + " Euros.";
         */
      }
   }
}