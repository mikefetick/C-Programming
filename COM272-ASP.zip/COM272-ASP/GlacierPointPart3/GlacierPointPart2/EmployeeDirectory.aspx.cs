﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient; // have to add this to the item
using System.Configuration;

namespace GlacierPoint
{
   public partial class EmployeeDirectory : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;

         // Select a connection between AtHome or AtSchool
         //conn = GetConnectionAtSchool();
         //conn = GetConnectionAtHome();

         // Read the connection string from Web.config 
         // AtSchool
         string connectionString = ConfigurationManager.ConnectionStrings["GlacierPoint"].ConnectionString;
         // AtHome
         //string connectionString = ConfigurationManager.ConnectionStrings["GlacierPointAtHome"].ConnectionString;

         // Initialize connection
         conn = new SqlConnection(connectionString);
                 
         // Create command
         comm = new SqlCommand(
         "SELECT EmployeeId, Name, Username FROM gp_Employee", conn);
         
         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            
            // Execute the command
            reader = comm.ExecuteReader();
            
            // Bind the reader to the repeater
            employeesRepeater.DataSource = reader;
            employeesRepeater.DataBind();
            
            // Close the reader
            reader.Close();
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
      }
      public static SqlConnection GetConnectionAtHome()
      {
         //  Create... Connection
         SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

         /* TO CONNECT AT HOME - LOCALHOST
          */
         builder.DataSource = @"(localdb)\Projects";
         builder.InitialCatalog = "db84270";
         builder.IntegratedSecurity = true;
         builder.ConnectTimeout = 30;
         builder.Encrypt = false;
         builder.TrustServerCertificate = false;
         //
         return new SqlConnection(builder.ConnectionString);
      }

      public static SqlConnection GetConnectionAtSchool()
      {
         //  Create... Connection
         SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

         /* TO CONNECT AT SCHOOL - COLEMAN UNIVERSITY
          */
         builder.DataSource = "mssql-2-34";
         builder.UserID = "db84270";
         builder.InitialCatalog = "db84270";
         builder.Password = "5a0c1de0";
         //
         return new SqlConnection(builder.ConnectionString);
      }
   }
}