﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
namespace ArkhamBooks
{
   public partial class Orders : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!IsPostBack)
         {
            BindGridViewCustomerOrders();
         }
      }
      private void BindGridViewCustomerOrders()
      {
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         //"SELECT o.CustomerOrderId, { fn CONCAT(c.LastName + ', ', c.FirstName) } AS CustomerName, " +
         //"o.DateOrdered, o.Subtotal, o.Taxes, o.Shipping, o.Total, o.CustId, " + 
         //"FROM CustomerOrders AS o INNER JOIN Customer AS c " +
         //"ON o.CustId = c.CustId ORDER BY CustomerName"
         comm = new SqlCommand(
         "SELECT CustomerOrderId, " +
         "DateOrdered, Subtotal, Taxes, Shipping, Total, CustId, " +
         "FROM CustomerOrders"
         , conn);

         // Enclose database code in Try-Catch-Finally
         StringBuilder errorMessages = new StringBuilder();
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            gridViewCustomerOrders.DataSource = reader;
            gridViewCustomerOrders.DataKeyNames = new string[] { "CustomerOrderId" };
            gridViewCustomerOrders.DataBind();
            // Close the reader
            reader.Close();
         }
         catch (SqlException ex)
         {
            for (int i = 0; i < ex.Errors.Count; i++)
            {
               errorMessages.Append("Index #" + i + "\n" +
                   "Message: " + ex.Errors[i].Message + "\n" +
                   "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                   "Source: " + ex.Errors[i].Source + "\n" +
                   "Procedure: " + ex.Errors[i].Procedure + "\n");
            }
            Console.WriteLine(errorMessages.ToString());
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
      }

      protected void gridViewCustomerOrders_SelectedIndexChanged(object sender, EventArgs e)
      {
         BindCustomerOrdersDetails();
      }

      private void BindCustomerOrdersDetails()
      {
         // Obtain the index of the selected row
         int selectedRowIndex = gridViewCustomerOrders.SelectedIndex;
         // Read the employee ID
         int CustomerOrderId = Convert.ToInt32(gridViewCustomerOrders.DataKeys[selectedRowIndex].Value);
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT CustomerOrderId, { fn CONCAT(c.LastName + ', ', c.FirstName) } AS CustomerName, " +
         "DateOrdered, Subtotal, Taxes, Shipping, Total, CustId, " + 
         "FROM CustomerOrders AS co INNER JOIN Customer AS c " +
         "ON c.CustId = oc.CustId ORDER BY CustomerName" );
         // Add the Isbn parameter
         comm.Parameters.Add("@CustomerOrderId", SqlDbType.Int);
         comm.Parameters["@CustomerOrderId"].Value = CustomerOrderId;
         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            customerOrdersDetails.DataSource = reader;
            customerOrdersDetails.DataKeyNames = new string[] { "CustomerOrderId" };
            customerOrdersDetails.DataBind();
            // Close the reader
            reader.Close();
         }
         finally
         {
            // Close the connection
         conn.Close();
         }
      }

      protected void customerOrdersDetails_ModeChanging(object sender, DetailsViewModeEventArgs e)
      {
         // Change current mode to the selected one
         customerOrdersDetails.ChangeMode(e.NewMode);
         // Rebind the details view
         BindCustomerOrdersDetails();
      }

      protected void customerOrdersDetails_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
      {
         // Read the book title from the DetailsView object
         int Title = Convert.ToInt32(customerOrdersDetails.DataKey.Value);

         // Find the TextBox controls with updated data
         TextBox newCustomerOrderIdTextBox = (TextBox)customerOrdersDetails.FindControl("editCustomerOrderIdTextBox");
         TextBox newDateOrderedTextBox = (TextBox)customerOrdersDetails.FindControl("editDateOrderedTextBox");
         TextBox newSubtotalTextBox = (TextBox)customerOrdersDetails.FindControl("editSubtotalTextBox");
         TextBox newTaxesTextBox = (TextBox)customerOrdersDetails.FindControl("editTaxesTextBox");
         TextBox newShippingTextBox = (TextBox)customerOrdersDetails.FindControl("editShippingTextBox");
         TextBox newTotalTextBox = (TextBox)customerOrdersDetails.FindControl("editTotalTextBox");
         TextBox newCustIdTextBox = (TextBox)customerOrdersDetails.FindControl("editCustIdTextBox");

         // Extract the updated data from the TextBoxes
         string newCustomerOrderId = newCustomerOrderIdTextBox.Text;
         string newDateOrdered = newDateOrderedTextBox.Text;
         string newSubtotal = newSubtotalTextBox.Text;
         string newTaxes = newTaxesTextBox.Text;
         string newShipping = newShippingTextBox.Text;
         string newTotal = newTotalTextBox.Text;
         string newCustId = newCustIdTextBox.Text;

         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand("sp_UpdateCustomerOrdersDetails", conn);
         comm.CommandType = CommandType.StoredProcedure;
         // Add command parameters
         comm.Parameters.Add("@newCustomerOrderId", SqlDbType.Int);
         comm.Parameters["@newCustomerOrderId"].Value = newCustomerOrderId;
         comm.Parameters.Add("@newDateOrdered", SqlDbType.NVarChar, 50);
         comm.Parameters["@newDateOrdered"].Value = newDateOrdered;
         comm.Parameters.Add("@newSubtotal", SqlDbType.NVarChar, 50);
         comm.Parameters["@newSubtotal"].Value = newSubtotal;
         comm.Parameters.Add("@newTaxes", SqlDbType.NVarChar, 50);
         comm.Parameters["@newTaxes"].Value = newTaxes;
         comm.Parameters.Add("@newShipping", SqlDbType.NVarChar, 50);
         comm.Parameters["@newShipping"].Value = newShipping;
         comm.Parameters.Add("@newTotal", SqlDbType.NVarChar, 50);
         comm.Parameters["@newTotal"].Value = newTotal;
         comm.Parameters.Add("@newCustId", SqlDbType.NVarChar, 50);
         comm.Parameters["@newCustId"].Value = newCustId;

         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            comm.ExecuteNonQuery();
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
         // Exit edit mode
         customerOrdersDetails.ChangeMode(DetailsViewMode.ReadOnly);
         // Reload the book grid
         BindGridViewCustomerOrders();
         // Reload the book details view
         BindCustomerOrdersDetails();
      }

   }
}