﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
namespace ArkhamBooks
{
   public partial class Booksbyauthor : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!IsPostBack)
         {
            BindGridViewBooks();
         }
      }
      private void BindGridViewBooks()
      {
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT t.Isbn, t.Title, t.Type, " +
         "{ fn CONCAT(a.LastName + ', ', a.FirstName) } AS AuthorName, t.SellingPrice " +
         "FROM Title AS t INNER JOIN Author AS a " +
         "INNER JOIN Wrote AS w ON a.AuthorId = w.AuthorId ON t.Isbn = w.Isbn ORDER BY AuthorName"
         , conn);

         // Enclose database code in Try-Catch-Finally
         StringBuilder errorMessages = new StringBuilder();
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            gridViewBooks.DataSource = reader;
            gridViewBooks.DataKeyNames = new string[] {"Title"};
            gridViewBooks.DataBind();
            // Close the reader
            reader.Close();
         }
         catch (SqlException ex)
         {
            for (int i = 0; i < ex.Errors.Count; i++)
            {
               errorMessages.Append("Index #" + i + "\n" +
                   "Message: " + ex.Errors[i].Message + "\n" +
                   "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                   "Source: " + ex.Errors[i].Source + "\n" +
                   "Procedure: " + ex.Errors[i].Procedure + "\n");
            }
            Console.WriteLine(errorMessages.ToString());
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
      }

      protected void gridViewBooks_SelectedIndexChanged(object sender, EventArgs e)
      {
         BindBookDetails();
      }

      private void BindBookDetails()
      {
         // Obtain the index of the selected row
         int selectedRowIndex = gridViewBooks.SelectedIndex;
         // Read the employee ID
         String Title = Convert.ToString(gridViewBooks.DataKeys[selectedRowIndex].Value);
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT Isbn, Title, PubId, Type, QtyOnHand, Cost, " +
         "SellingPrice FROM Title " +
         "WHERE Title=@Title", conn);

         // Add the Isbn parameter
         comm.Parameters.Add("@Title", SqlDbType.VarChar);
         comm.Parameters["@Title"].Value = Title;
         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            bookDetails.DataSource = reader;
            bookDetails.DataKeyNames = new string[] { "Title" };
            bookDetails.DataBind();
            // Close the reader
            reader.Close();
         }
         finally
         {
            // Close the connection
         conn.Close();
         }
      }

      protected void bookDetails_ModeChanging(object sender, DetailsViewModeEventArgs e)
      {
         // Change current mode to the selected one
         bookDetails.ChangeMode(e.NewMode);
         // Rebind the details view
         BindBookDetails();
      }

      protected void bookDetails_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
      {
         // Read the book title from the DetailsView object
         //int Title = Convert.ToInt32(bookDetails.DataKey.Value);

         // Find the TextBox controls with updated data
         TextBox newIsbnTextBox = (TextBox)bookDetails.FindControl("editIsbnTextBox");
         TextBox newTitleTextBox = (TextBox)bookDetails.FindControl("editTitleTextBox");
         TextBox newPubIdTextBox = (TextBox)bookDetails.FindControl("editPubIdTextBox");
         TextBox newTypeTextBox = (TextBox)bookDetails.FindControl("editTypeTextBox");
         TextBox newQtyOnHandTextBox = (TextBox)bookDetails.FindControl("editQtyOnHandTextBox");
         TextBox newCostTextBox = (TextBox)bookDetails.FindControl("editCostTextBox");
         TextBox newSellingPriceTextBox = (TextBox)bookDetails.FindControl("editSellingPriceTextBox");

         // Extract the updated data from the TextBoxes
         string newIsbn = newIsbnTextBox.Text;
         string newTitle = newTitleTextBox.Text;
         string newPubId = newPubIdTextBox.Text;
         string newType = newTypeTextBox.Text;
         string newQtyOnHand = newQtyOnHandTextBox.Text;
         string newCost = newCostTextBox.Text;
         string newSellingPrice = newSellingPriceTextBox.Text;

         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand("sp_UpdateTitle", conn);
         comm.CommandType = CommandType.StoredProcedure;
         // Add command parameters
         comm.Parameters.Add("@NewIsbn", SqlDbType.NVarChar, 13);
         comm.Parameters["@NewIsbn"].Value = newIsbn;
         comm.Parameters.Add("@NewTitle", SqlDbType.NVarChar, 50);
         comm.Parameters["@NewTitle"].Value = newTitle;
         comm.Parameters.Add("@NewPubId", SqlDbType.Int);
         comm.Parameters["@NewPubId"].Value = newPubId;
         comm.Parameters.Add("@NewType", SqlDbType.NVarChar, 15);
         comm.Parameters["@NewType"].Value = newType;
         comm.Parameters.Add("@NewQtyOnHand", SqlDbType.Int);
         comm.Parameters["@NewQtyOnHand"].Value = newQtyOnHand;
         comm.Parameters.Add("@NewCost", SqlDbType.Decimal, 6);
         comm.Parameters["@NewCost"].Value = newCost;
         comm.Parameters.Add("@NewSellingPrice", SqlDbType.Decimal, 6);
         comm.Parameters["@NewSellingPrice"].Value = newSellingPrice;

         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            comm.ExecuteNonQuery();
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
         // Exit edit mode
         bookDetails.ChangeMode(DetailsViewMode.ReadOnly);
         // Reload the book grid
         BindGridViewBooks();
         // Reload the book details view
         BindBookDetails();
      }

   }
}