﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;  // for string builder
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace ArkhamBooks
{
   public partial class WebForm1 : System.Web.UI.Page
   {
      protected System.Web.UI.WebControls.DropDownList ddlBooks;
      protected System.Web.UI.WebControls.RadioButtonList rbList;
      protected System.Web.UI.WebControls.CheckBoxList cbList;
      protected System.Web.UI.WebControls.Button Submit;
      protected System.Web.UI.WebControls.Label lblMsg;

      public WebForm1()
      {
         Page.Init += new System.EventHandler(Page_Init);
      }

      protected void Page_Init(object sender, EventArgs e)
      {
         //
         // CODEGEN: This call is required by the
         // ASP.NET Windows Form Designer.
         //
         InitializeComponent();
      }

      #region Web Form Designer generated code
      /// <summary>
      ///   Required method for Designer support - do not modify
      ///   the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.Load +=
            new System.EventHandler(this.Page_Load);

      }
      #endregion

      public class Book
      {
         public Book(float price, string title, string ISBN)
         {
            this.price = price;
            this.title = title;
            this.isbn = ISBN;
         }

         public float Price { get { return price; } }
         public string Title { get { return title; } }
         public string ISBN { get { return isbn; } }

         private float price;
         private string title;
         private string isbn;

      }

      private void Page_Load(object sender, System.EventArgs e)
      {
         if (!Page.IsPostBack)
         {
            // create the array list
            ArrayList bookList = new ArrayList();

            // add all the books
            // (formatted to fit in margins)
            bookList.Add(
               new Book(49.95f, "Programming ASP.NET",
                     "100000000"));
            bookList.Add(
               new Book(49.95f, "Programming C#",
                     "100000001"));
            bookList.Add(
               new Book(34.99f, "Teach Yourself C++ In 21 Days",
                     "067232072x"));
            bookList.Add(
               new Book(24.95f, "Teach Yourself C++ In 24 Hours",
                     "0672315165"));
            bookList.Add(
               new Book(12.99f, "TY C++ In 10 Minutes",
                     "067231603X"));
            bookList.Add(
               new Book(24.95f, "C++ Unleashed",
                     "1199000663"));
            bookList.Add(
               new Book(29.99f, "C++ From Scratch",
                     "0789720795"));
            bookList.Add(
               new Book(39.99f, "XML From Scratch",
                  "0789723166"));

            // set the data source
            ddlBooks.DataSource = bookList;

            // bind to the data
            ddlBooks.DataBind();

            // shippingMethods array list stands in for
            // data retrieved from database
            ArrayList shippingMethods = new ArrayList();
            shippingMethods.Add("3rd Class");
            shippingMethods.Add("1st Class");
            shippingMethods.Add("Ground");
            shippingMethods.Add("2nd Day");
            shippingMethods.Add("Next Day");

            // set the data source for the dynamic
            // radio button list
            rbList.DataSource = shippingMethods;

            // bind the data
            rbList.DataBind();

            // extras array list stands in for
            // data retrieved from database
            ArrayList extras = new ArrayList();
            extras.Add("Gift Wrap");
            extras.Add("Gift Card");
            extras.Add("Book Mark");
            extras.Add("Autographed copy");
            extras.Add("Source Code");

            // set the data source for the
            // dynamic checkbox list
            cbList.DataSource = extras;

            // bind the data
            cbList.DataBind();
         }
         else     // is post-back, form was submitted
         {
            // string builders to hold text from controls
            StringBuilder extrasChosen =
               new StringBuilder(" with these extras: ");
            StringBuilder shippingMethod =
               new StringBuilder(" We will ship ");

            // build up string of choices. if more than one choice
            // make them comma delmited
            int chosen = 0;
            for (int i = 0; i < cbList.Items.Count; i++)
            {
               // if the item was selected
               if (cbList.Items[i].Selected == true)
               {
                  // if this is not the first item
                  // add a comma after the previous
                  // before adding this one
                  chosen++;
                  if (chosen > 1)
                     extrasChosen.Append(", ");

                  // add the item to the string builder
                  extrasChosen.Append(cbList.Items[i].Text);

               }
            }

            // find the selected shipping method and add it
            // to the string builder
            for (int i = 0; i < rbList.Items.Count; i++)
               if (rbList.Items[i].Selected)
                  shippingMethod.Append(rbList.Items[i].Text);


            // create the output text by concatenating the book title
            // isbn, the selected items and the shipping method
            lblMsg.Text = "Selected: " + ddlBooks.SelectedItem.Text +
               "(" + ddlBooks.SelectedItem.Value + ")" + extrasChosen +
               ".  " + shippingMethod + ".";

         }  // end else
      }     // end page load
   }        // end class
}