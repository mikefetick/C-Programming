﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
namespace ArkhamBooks
{
   public partial class Catalog : System.Web.UI.Page
   {
      //1) Declaring the variables and ...
      public static bool isSort = false;
      public static bool isAscend = false;
      private const string ASCENDING = " ASC";
      private const string DESCENDING = " DESC";
      public static bool showImage = false;

      protected void Page_Load(object sender, EventArgs e)
      {
         if (!IsPostBack)
         {
            BindGridViewBooks();
         }
      }
      private void BindGridViewBooks()
      {
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT t.Isbn, t.Title, t.Type, " +
         "{ fn CONCAT(a.LastName + ', ', a.FirstName) } AS AuthorName, t.SellingPrice " +
         "FROM Title AS t INNER JOIN Author AS a " +
         "INNER JOIN Wrote AS w ON a.AuthorId = w.AuthorId ON t.Isbn = w.Isbn"
         , conn);
         //+ "ORDER BY AuthorName"

         // Enclose database code in Try-Catch-Finally
         StringBuilder errorMessages = new StringBuilder();
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            gridViewBooks.DataSource = reader;
            gridViewBooks.DataKeyNames = new string[] { "Title" };
            gridViewBooks.DataBind();
            // Close the reader
            reader.Close();
         }
         catch (SqlException ex)
         {
            for (int i = 0; i < ex.Errors.Count; i++)
            {
               errorMessages.Append("Index #" + i + "\n" +
                   "Message: " + ex.Errors[i].Message + "\n" +
                   "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                   "Source: " + ex.Errors[i].Source + "\n" +
                   "Procedure: " + ex.Errors[i].Procedure + "\n");
            }
            Console.WriteLine(errorMessages.ToString());
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
      }

      // 1) ... and Adding the RowCreated Event
      protected void gridView_RowCreated(object sender, GridViewRowEventArgs e)
      {
         int sortColumnIndex = -1;

         if (e.Row.RowType == DataControlRowType.Header)
         {
            sortColumnIndex = GetSortColumnIndex(e.Row);
            if (sortColumnIndex != 1)
            {
               AddSortImage(sortColumnIndex, e.Row);
            }
         }
      }

      // 2) Adding a method which will return the Index of the column selected
      protected int GetSortColumnIndex(object sender)
      {

         foreach (DataControlField field in gridViewBooks.Columns)
         {
            if (field.SortExpression == gridViewBooks.SortExpression)
            {
               return (int) gridViewBooks.Columns.IndexOf(field);
            }
            else
            {
               return -1;
            }
         }
         return -1;
/* 
         foreach (DataControlField field in gridViewBooks.Columns)
         {
            if (field.SortExpression == gridViewBooks.SortExpression)
            {
               return (int) gridViewBooks.Columns.IndexOf(field);
            }
            else
            {
               return -1;
            }
         }
         return -1;
*/
      }

      //3) Adding the SortImage Method
      protected void AddSortImage(int columnIndex, GridViewRow HeaderRow)
      {
         Image sortImage = new Image();

         if (showImage) // this is a boolean variable which should be false 
         {            //  on page load so that image wont show up initially.
            //if (ViewState["sortDirection"] == null )
            //{
            //   ViewState["sortDirection"] = SortDirection.Ascending;
            //}
            if (ViewState["sortDirection"].ToString() == "Ascending")
            {
               sortImage.ImageUrl = "~/Images/sort_asc.png";
               sortImage.AlternateText = " Ascending Order";
            }
            else
            {
               sortImage.ImageUrl = "~/Images/sort_desc.png";
               sortImage.AlternateText = " Descending Order";
            }
            //HeaderRow.Cells[2].Controls.Add(sortImage);
            HeaderRow.Cells[columnIndex+2].Controls.Add(sortImage);
         }
      }
         
      protected void GridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
      {
         gridViewBooks.PageIndex = e.NewPageIndex;

         if (!isSort) // this will get executed if user clicks paging
         {            // before sorting itself
            gridViewBooks.DataSource = e; // I gave Datasource as null for instance.
            gridViewBooks.DataBind();        // Provide your datasource to bind the data
         }

         else if (isAscend)// this will get executed if user clicks paging
         // after clicking ascending order
         {
            // Passing only "DateRequest" as sortexpression for instance because
            // of implementing sorting for only one column. You can generalize it to 
            // pass that particular column on sorting.
            SortGridView(gridViewBooks.SortExpression, ASCENDING);
            //SortGridView("DateRequest", ASCENDING);
         }
         else // this will get exectued if user clicks paging
         // after cliclking descending order
         {
            SortGridView(gridViewBooks.SortExpression, DESCENDING);
            //SortGridView("DateRequest", DESCENDING);
         }
      }

      // to set the height of row.
      protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
      {
         e.Row.Height = Unit.Pixel(20);
      }

      private SortDirection GridViewSortDirection
      {
         get
         {
            if (ViewState["sortDirection"] == null)
            {
                ViewState["sortDirection"] = SortDirection.Ascending;
            }
            return (SortDirection)ViewState["sortDirection"];
         }
         set {  ViewState["sortDirection"] = value; }
      }

      protected void SortGridView(string sortExpression, string direction)
      {
         DataTable dataTable = gridViewBooks.DataSource as DataTable;

         if (dataTable != null)
         {
            //gridViewBooks.AllowSorting = true;
            DataView dataView = new DataView(dataTable);
            dataView.Sort = sortExpression + direction;

            gridViewBooks.DataSource = dataView;
            //gridViewBooks.DataKeyNames = new string[] { "Title" };
            gridViewBooks.DataBind();
            //gridViewBooks.AllowSorting = false;
         }
      }
      protected void gridView_Sorting(object sender, GridViewSortEventArgs e)
      {
         isSort = true;

         string sortExpression = e.SortExpression;

         ViewState["SortExpression"] = sortExpression;
         showImage = true;

         if (GridViewSortDirection == SortDirection.Ascending)
         {
            isAscend = true;
            SortGridView(sortExpression, DESCENDING);
            GridViewSortDirection = SortDirection.Descending;
         }
         else
         {
            isAscend = false;
            SortGridView(sortExpression, ASCENDING);
            GridViewSortDirection = SortDirection.Ascending;
         }
      }

      protected void btnExportExcel_Click(object sender, EventArgs e)
      {
         gridViewBooks.DataSource = null; //Give Your Datasource
         //for the time being I set the datasource as null
         gridViewBooks.AllowPaging = false;
         gridViewBooks.DataBind();

         Response.ClearContent();
         Response.AddHeader("content-disposition", "attachment; filename=MyReports.xls");

         Response.ContentType = "application/excel";

         StringWriter sw = new StringWriter();
         HtmlForm fm = new HtmlForm();
         HtmlTextWriter htw = new HtmlTextWriter(sw);

         Controls.Add(fm);

         fm.Controls.Add(gridViewBooks);
         fm.RenderControl(htw);

         Response.Write(sw.ToString());

         Response.End();
         // making the Allowpaging true again and binding it.
         gridViewBooks.AllowPaging = true;
         gridViewBooks.DataBind();
      }

      protected void gridViewBooks_SelectedIndexChanged(object sender, EventArgs e)
      {
         BindBookDetails();
      }

      private void BindBookDetails()
      {
         // Obtain the index of the selected row
         int selectedRowIndex = gridViewBooks.SelectedIndex;
         // Read the employee ID
         int Isbn = Convert.ToInt32(gridViewBooks.DataKeys[selectedRowIndex].Value);
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT Isbn, Title, PubId, Type, QtyOnHand, Cost, " +
         "SellingPrice FROM Title " +
         "WHERE Title=@Title", conn);
         // Add the Isbn parameter
         comm.Parameters.Add("@Title", SqlDbType.Int);
         comm.Parameters["@Title"].Value = Title;
         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            bookDetails.DataSource = reader;
            bookDetails.DataKeyNames = new string[] {"Title"};
            bookDetails.DataBind();
            // Close the reader
            reader.Close();
         }
         finally
         {
            // Close the connection
         conn.Close();
         }
      }

      protected void bookDetails_ModeChanging(object sender, DetailsViewModeEventArgs e)
      {
         // Change current mode to the selected one
         bookDetails.ChangeMode(e.NewMode);
         // Rebind the details view
         BindBookDetails();
      }

      protected void bookDetails_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
      {
         // Read the book title from the DetailsView object
         int Title = Convert.ToInt32(bookDetails.DataKey.Value);

         // Find the TextBox controls with updated data
         TextBox newIsbnTextBox = (TextBox)bookDetails.FindControl("editIsbnTextBox");
         TextBox newTitleTextBox = (TextBox)bookDetails.FindControl("editTitleTextBox");
         TextBox newPubIdTextBox = (TextBox)bookDetails.FindControl("editPubIdTextBox");
         TextBox newTypeTextBox = (TextBox)bookDetails.FindControl("editTypeTextBox");
         TextBox newQtyOnHandTextBox = (TextBox)bookDetails.FindControl("editQtyOnHandTextBox");
         TextBox newCostTextBox = (TextBox)bookDetails.FindControl("editCostTextBox");
         TextBox newSellingPriceTextBox = (TextBox)bookDetails.FindControl("editSellingPriceTextBox");

         // Extract the updated data from the TextBoxes
         string newIsbn = newIsbnTextBox.Text;
         string newTitle = newTitleTextBox.Text;
         string newPubId = newPubIdTextBox.Text;
         string newType = newTypeTextBox.Text;
         string newQtyOnHand = newQtyOnHandTextBox.Text;
         string newCost = newCostTextBox.Text;
         string newSellingPrice = newSellingPriceTextBox.Text;

         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand("sp_UpdateBookDetails", conn);
         comm.CommandType = CommandType.StoredProcedure;
         // Add command parameters
         comm.Parameters.Add("@NewIsbn", SqlDbType.Int);
         comm.Parameters["@NewIsbn"].Value = newIsbn;
         comm.Parameters.Add("@NewTitle", SqlDbType.NVarChar, 50);
         comm.Parameters["@NewTitle"].Value = newTitle;
         comm.Parameters.Add("@NewPubId", SqlDbType.NVarChar, 50);
         comm.Parameters["@NewPubId"].Value = newPubId;
         comm.Parameters.Add("@NewType", SqlDbType.NVarChar, 50);
         comm.Parameters["@NewType"].Value = newType;
         comm.Parameters.Add("@NewQtyOnHand", SqlDbType.NVarChar, 50);
         comm.Parameters["@NewQtyOnHand"].Value = newQtyOnHand;
         comm.Parameters.Add("@NewCost", SqlDbType.NVarChar, 50);
         comm.Parameters["@NewCost"].Value = newCost;
         comm.Parameters.Add("@NewSellingPrice", SqlDbType.NVarChar, 50);
         comm.Parameters["@NewSellingPrice"].Value = newSellingPrice;

         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            comm.ExecuteNonQuery();
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
         // Exit edit mode
         bookDetails.ChangeMode(DetailsViewMode.ReadOnly);
         // Reload the book grid
         BindGridViewBooks();
         // Reload the book details view
         BindBookDetails();
      }

   }
}