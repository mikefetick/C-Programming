﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ArkhamBooks
{
   public partial class Book : System.Web.UI.Page
   {
      public float Price { get { return price; } }
      public string Title { get { return title; } }
      public string ISBN { get { return isbn; } }

      private float price;
      private string title;
      private string isbn;

      public Book(float price, string title, string ISBN)
      {
         this.price = price;
         this.title = title;
         this.isbn = ISBN;
      }

      protected void Page_Load(object sender, EventArgs e)
      {

      }
   }
}