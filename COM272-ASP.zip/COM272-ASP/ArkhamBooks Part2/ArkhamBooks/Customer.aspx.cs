﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
namespace ArkhamBooks
{
   public partial class Customer : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         if (!IsPostBack)
         {
            BindGridViewCustomer();
         }
      }
      private void BindGridViewCustomer()
      {
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT c.CustId, c.LastName, c.FirstName, " +
         "c.Address, c.City, c.State, c.Zip, c.Phone, c.Email, " + 
         "c.CardType, c.CardNumber, c.CardExpire " +
         "FROM Customer AS c ORDER BY LastName"
         , conn);

         // Enclose database code in Try-Catch-Finally
         StringBuilder errorMessages = new StringBuilder();
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            gridViewCustomer.DataSource = reader;
            gridViewCustomer.DataKeyNames = new string[] {"CustId"};
            gridViewCustomer.DataBind();
            // Close the reader
            reader.Close();
         }
         catch (SqlException ex)
         {
            for (int i = 0; i < ex.Errors.Count; i++)
            {
               errorMessages.Append("Index #" + i + "\n" +
                   "Message: " + ex.Errors[i].Message + "\n" +
                   "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                   "Source: " + ex.Errors[i].Source + "\n" +
                   "Procedure: " + ex.Errors[i].Procedure + "\n");
            }
            Console.WriteLine(errorMessages.ToString());
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
      }

      protected void gridViewCustomer_SelectedIndexChanged(object sender, EventArgs e)
      {
         BindCustomerDetails();
      }

      private void BindCustomerDetails()
      {
         // Obtain the index of the selected row
         int selectedRowIndex = gridViewCustomer.SelectedIndex;
         // Read the employee ID
         String CustId = Convert.ToString(gridViewCustomer.DataKeys[selectedRowIndex].Value);
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT CustId, LastName, FirstName, " +
         "Address, City, State, Zip, Phone, Email, " + 
         "CardType, CardNumber, CardExpire " +
         "FROM Customer WHERE CustId=@CustId", conn);
         // Add the Isbn parameter
         comm.Parameters.Add("@CustId", SqlDbType.NVarChar);
         comm.Parameters["@CustId"].Value = CustId;
         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            customerDetails.DataSource = reader;
            customerDetails.DataKeyNames = new string[] { "CustId" };
            customerDetails.DataBind();
            // Close the reader
            reader.Close();
         }
         finally
         {
            // Close the connection
         conn.Close();
         }
      }

      protected void customerDetails_ModeChanging(object sender, DetailsViewModeEventArgs e)
      {
         // Change current mode to the selected one
         customerDetails.ChangeMode(e.NewMode);
         // Rebind the details view
         BindCustomerDetails();
      }

      protected void customerDetails_ItemUpdating(object sender, DetailsViewUpdateEventArgs e)
      {
         // Read the book title from the DetailsView object
         //int CustId = Convert.ToInt32(customerDetails.DataKey.Value);

         // Find the TextBox controls with updated data
         TextBox newCustIdTextBox = (TextBox)customerDetails.FindControl("editCustIdTextBox");
         TextBox newLastNameTextBox = (TextBox)customerDetails.FindControl("editLastNameTextBox");
         TextBox newFirstNameTextBox = (TextBox)customerDetails.FindControl("editFirstNameTextBox");
         TextBox newAddressTextBox = (TextBox)customerDetails.FindControl("editAddressTextBox");
         TextBox newCityTextBox = (TextBox)customerDetails.FindControl("editCityTextBox");
         TextBox newStateTextBox = (TextBox)customerDetails.FindControl("editStateTextBox");
         TextBox newZipTextBox = (TextBox)customerDetails.FindControl("editZipTextBox");
         TextBox newPhoneTextBox = (TextBox)customerDetails.FindControl("editPhoneTextBox");
         TextBox newEmailTextBox = (TextBox)customerDetails.FindControl("editEmailTextBox");
         TextBox newCardTypeTextBox = (TextBox)customerDetails.FindControl("editCardTypeTextBox");
         TextBox newCardNumberTextBox = (TextBox)customerDetails.FindControl("editCardNumberTextBox");
         TextBox newCardExpireTextBox = (TextBox)customerDetails.FindControl("editCardExpireTextBox");

         // Extract the updated data from the TextBoxes
         string newCustId = newCustIdTextBox.Text;
         string newLastName = newLastNameTextBox.Text;
         string newFirstName = newFirstNameTextBox.Text;
         string newAddress = newAddressTextBox.Text;
         string newCity = newCityTextBox.Text;
         string newState = newStateTextBox.Text;
         string newZip = newZipTextBox.Text;
         string newPhone = newPhoneTextBox.Text;
         string newEmail = newEmailTextBox.Text;
         string newCardType = newCardTypeTextBox.Text;
         string newCardNumber = newCardNumberTextBox.Text;
         string newCardExpire = newCardExpireTextBox.Text;

         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         // Read the connection string from Web.config
         string connectionString =
         ConfigurationManager.ConnectionStrings["ArkhamBooks"].ConnectionString;
         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand("sp_UpdateCustomerDetails", conn);
         comm.CommandType = CommandType.StoredProcedure;
         // Add command parameters
         comm.Parameters.Add("@NewCustId", SqlDbType.NText);
         comm.Parameters["@NewCustId"].Value = newCustId;
         comm.Parameters.Add("@NewLastName", SqlDbType.NVarChar, 20);
         comm.Parameters["@NewLastName"].Value = newLastName;
         comm.Parameters.Add("@NewFirstName", SqlDbType.NVarChar, 15);
         comm.Parameters["@NewFirstName"].Value = newFirstName;
         comm.Parameters.Add("@NewAddress", SqlDbType.NVarChar, 30);
         comm.Parameters["@NewAddress"].Value = newAddress;
         comm.Parameters.Add("@NewCity", SqlDbType.NVarChar, 20);
         comm.Parameters["@NewCity"].Value = newCity;
         comm.Parameters.Add("@NewState", SqlDbType.NVarChar, 20);
         comm.Parameters["@NewState"].Value = newState;
         comm.Parameters.Add("@NewZip", SqlDbType.NVarChar, 10);
         comm.Parameters["@NewZip"].Value = newZip;
         comm.Parameters.Add("@NewPhone", SqlDbType.NVarChar, 12);
         comm.Parameters["@NewPhone"].Value = newPhone;
         comm.Parameters.Add("@NewEmail", SqlDbType.NVarChar, 35);
         comm.Parameters["@NewEmail"].Value = newEmail;
         comm.Parameters.Add("@NewCardType", SqlDbType.NVarChar, 16);
         comm.Parameters["@NewCardType"].Value = newCardType;
         comm.Parameters.Add("@NewCardNumber", SqlDbType.NVarChar, 16);
         comm.Parameters["@NewCardNumber"].Value = newCardNumber;
         comm.Parameters.Add("@NewCardExpire", SqlDbType.NVarChar, 5);
         comm.Parameters["@NewCardExpire"].Value = newCardExpire;

         // Enclose database code in Try-Catch-Finally
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            comm.ExecuteNonQuery();
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
         // Exit edit mode
         customerDetails.ChangeMode(DetailsViewMode.ReadOnly);
         // Reload the book grid
         BindGridViewCustomer();
         // Reload the book details view
         BindCustomerDetails();
      }

   }
}