﻿// Michael Fetick, Coleman University Student 84270
// COM272A-1405 ASP.NET (Al-Ajrawi) 
// June 03, 2014
// Lab 1, assigned in Week 1 (Reference: Webclass; Course Student Manual, pages 8-23)
// This Lab demonstrates how server-based controls work using a single page applet. 
// This type of program, which combines user input and the program output on the same page, 
// is used to provide popular tools on many sites. 
// Some examples include: calculators for mortgages, taxes, health or weight indices, 
// and retirement savings plans; single-phrase translators; and stock-tracking utilities.
// The directions can be found in the student manual.
// BUG: Works good but see the comment at the bottom...
using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab1_Fetick_84270
{
   public partial class CurrencyConverter : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {
         if (this.IsPostBack == false)
         {
            Currency.Items.Add(new ListItem("Euros", "0.85"));
            Currency.Items.Add(new ListItem("Japanese Yen", "110.33"));
            Currency.Items.Add(new ListItem("Canadian Dollars", "1.2"));

            Graph.Visible = false;
         }
      }
      protected void Convert_ServerClick(object sender, EventArgs e)
      {
         Decimal amount;
         Decimal.TryParse(US.Value, out amount);

         if (amount <= 0)
         {
            Result.Style["color"] = "Red";
            Result.InnerText = "Input Invalid - Please enter a positive” +  “ numeric value";
         }
         else
         {
            Result.Style["color"] = "Black";

            ListItem item = Currency.Items[Currency.SelectedIndex];

            decimal newAmount = amount * Decimal.Parse(item.Value);
            Result.InnerText = amount.ToString() + " U.S. dollars = ";
            Result.InnerText += newAmount.ToString() + " " + item.Text;
         }

         if (amount <= 0)
         {
            Result.Style["color"] = "Red";
            Result.InnerText = "Input Invalid - Please enter a positive” + “ numeric value";
         }
         else
         {
            Result.Style["color"] = "Black";

            ListItem item = Currency.Items[Currency.SelectedIndex];

            decimal newAmount = amount * Decimal.Parse(item.Value);
            Result.InnerText = amount.ToString() + " U.S. dollars = ";
            Result.InnerText += newAmount.ToString() + " " + item.Text;
         }

         /*
         decimal USAmount = decimal.Parse(US.Value);
         decimal euroAmount = USAmount * 0.85M;
         Result.InnerText = USAmount.ToString() + " U.S. dollars = ";
         Result.InnerText += euroAmount.ToString() + " Euros.";
         */
      }
      protected void ShowGraph_ServerClick(object sender, EventArgs e)
      {
         // BUG: The image file of the graph does not display. 
         // I tried different things... 
         //
         //Graph.Src = "pic1.png";
         //Graph.Src = ".\\pic" + Currency.SelectedIndex.ToString() + ".png";
         Graph.Src = "pic" + Currency.SelectedIndex.ToString() + ".png";
         Graph.Visible = true;
      }
   }
}