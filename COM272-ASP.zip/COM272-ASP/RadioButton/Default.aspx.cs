﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RadioButton
{
   public partial class _Default : System.Web.UI.Page
   {
      protected void Page_Load(object sender, EventArgs e)
      {

      }
      protected void grpColor_CheckedChanged(object sender, EventArgs e)
      {
         if (rdoRed.Checked)
         {
            lblColor.Text = "The color is Red.";
            lblColor.ForeColor = System.Drawing.Color.Red;
         }
         else
            if (rdoBlue.Checked)
            {
               lblColor.Text = "The color is Blue.";
               lblColor.ForeColor = System.Drawing.Color.Blue;
            }
            else
            {
               lblColor.Text = "The color is Green.";
               lblColor.ForeColor = System.Drawing.Color.Green;
            }
      }
      protected void lblColor_Init(object sender, EventArgs e)
      {
         lblColor.Font.Name = "Verdana";
         lblColor.Font.Size = 20;
         lblColor.Font.Bold = true;
         lblColor.Font.Italic = true;
         lblColor.Text = "The color has not been selected.";
      }

      protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
      {
         lblColor.Text = "The color is " + RadioButtonList1.SelectedItem.Text;
         lblColor.ForeColor = System.Drawing.Color.FromName(RadioButtonList1.SelectedItem.Value);
      }
   }
}