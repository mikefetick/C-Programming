-- Drop tables if they exist
IF EXISTS(SELECT name 
FROM sysobjects WHERE name = N'gp_Department' AND xtype='U')
DROP TABLE gp_Department

IF EXISTS(SELECT name 
FROM sysobjects WHERE name = N'gp_Employee' AND xtype='U')
DROP TABLE gp_Employee

IF EXISTS(SELECT name 
FROM sysobjects WHERE name = N'gp_HelpDeskCategory' AND xtype='U')
DROP TABLE gp_HelpDeskCategory

IF EXISTS(SELECT name 
FROM sysobjects WHERE name = N'gp_HelpDeskSubject' AND xtype='U')
DROP TABLE gp_HelpDeskSubject

IF EXISTS(SELECT name 
FROM sysobjects WHERE name = N'gp_HelpDesk' AND xtype='U')
DROP TABLE gp_HelpDesk

IF EXISTS(SELECT name 
FROM sysobjects WHERE name = N'gp_HelpDeskStatus' AND xtype='U')
DROP TABLE gp_HelpDeskStatus



create table gp_HelpDeskCategory
(CategoryId INT NOT NULL Identity PRIMARY KEY,
 Category    NVARCHAR(50) NOT NULL);

insert into gp_helpdeskcategory (Category)
values('Hardware');
insert into gp_helpdeskcategory (Category)
values('Software');
insert into gp_helpdeskcategory (Category)
values('Workstation');
insert into gp_helpdeskcategory (Category)
values('Other/Don''t Know');


create table gp_HelpDeskSubject
(SubjectId  INT NOT NULL Identity PRIMARY KEY,
 Subject     NVARCHAR(50) NOT NULL);

insert into gp_helpdesksubject (Subject)
values('Computer won''t start');
insert into gp_helpdesksubject (Subject)
values('Monitor won''t turn on');
insert into gp_helpdesksubject (Subject)
values('Chair is broken');
insert into gp_helpdesksubject (Subject)
values('Office won''t work');
insert into gp_helpdesksubject (Subject)
values('Windows won''t work');
insert into gp_helpdesksubject (Subject)
values('Computer crashes');
insert into gp_helpdesksubject (Subject)
values('Other');


create table gp_Employee
(EmployeeId  INT NOT NULL Identity PRIMARY KEY,
 DepartmentId INT NOT NULL,
 Name         NVARCHAR(50) NOT NULL,
 Username     NVARCHAR(50) NOT NULL,
 Password     NVARCHAR(50),
 Address      NVARCHAR(50),
 City         NVARCHAR(50),
 State        NVARCHAR(50),
 Zip          NVARCHAR(50),
 HomePhone    NVARCHAR(50),
 Extension    NVARCHAR(50),
 MobilePhone  NVARCHAR(50));
 
 insert into gp_employee (DepartmentId, Name, Username, Password, Address, City, State, Zip, HomePhone, Extension, MobilePhone)
 values(5, 'John Smith', 'john', 'john', null, 'La Mesa', 'CA', null, null, null, '619-254-6573');
 insert into gp_employee (DepartmentId, Name, Username, Password, Address, City, State, Zip, HomePhone, Extension, MobilePhone)
 values(9, 'Fred Brown', 'fred', 'fred', null, 'San Diego', 'CA', null, null, null, '619-254-6473');
 insert into gp_employee (DepartmentId, Name, Username, Password, Address, City, State, Zip, HomePhone, Extension, MobilePhone)
 values(6, 'Tim Jones', 'tim', 'tim', null, 'El Cajon', 'CA', null, null, null, '619-254-6403');
 insert into gp_employee (DepartmentId, Name, Username, Password, Address, City, State, Zip, HomePhone, Extension, MobilePhone)
 values(6, 'Tom Short', 'tom', 'tom', null, 'San Diego', 'CA', null, null, null, '619-254-6303');
 insert into gp_employee (DepartmentId, Name, Username, Password, Address, City, State, Zip, HomePhone, Extension, MobilePhone)
 values(9, 'Richard Hyde-White', 'richard', 'richard', null, 'San Diego', 'CA', null, null, null, '619-554-7303');
 insert into gp_employee (DepartmentId, Name, Username, Password, Address, City, State, Zip, HomePhone, Extension, MobilePhone)
 values(1, 'Ted Hoffman', 'ted', 'ted', null, 'San Diego', 'CA', null, null, null, '619-754-7383');
 
 
 create table gp_Department
 (DepartmentId INT NOT NULL Identity PRIMARY KEY,
  Department   NVARCHAR(50) NOT NULL);

insert into gp_department (Department)
values('Accounting');
insert into gp_department (Department)
values('Administration');
insert into gp_department (Department)
values('Business Development');
insert into gp_department (Department)
values('Customer Support');
insert into gp_department (Department)
values('Executive');
insert into gp_department (Department)
values('Engineering');
insert into gp_department (Department)
values('Facilities');
insert into gp_department (Department)
values('IT');
insert into gp_department (Department)
values('Marketing');
insert into gp_department (Department)
values('Operations');


create table gp_HelpDesk
(RequestId  INT NOT NULL Identity PRIMARY KEY,
 EmployeeId INT NOT NULL,
 StationNumber  INT,
 CategoryId  INT NOT NULL,
 SubjectId   INT NOT NULL,
 Description  NVARCHAR(50),
 StatusId   INT NOT NULL);
 
 
 create table gp_HelpDeskStatus
 (StatusId  INT NOT NULL Identity PRIMARY KEY,
  Status    NVARCHAR(50) NOT NULL);
  
  insert into gp_helpdeskstatus (Status)
  values('Open');
  insert into gp_helpdeskstatus (Status)
  values('Closed');
  
  