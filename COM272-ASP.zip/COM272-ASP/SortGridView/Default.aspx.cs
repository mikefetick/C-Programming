﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;
namespace SortGridView
{
   public partial class _Default : System.Web.UI.Page
   {
/*
*/     
      void Sort_Grid(Object sender, DataGridSortCommandEventArgs e)
      {
         // Retrieve the data source from session state.
         DataTable dt = (DataTable)Session["Source"];

         // Create a DataView from the DataTable.
         DataView dv = new DataView(dt);

         // The DataView provides an easy way to sort. Simply set the
         // Sort property with the name of the field to sort by.
         dv.Sort = e.SortExpression;

         // Rebind the data source and specify that it should be sorted
         // by the field specified in the SortExpression property.
         ItemsGrid.DataSource = dv;
         ItemsGrid.DataBind();
      }

      protected ICollection CreateDataSource()
      {
         // Create a Random object to mix up the 
         // order of items in the sample data.
         Random randNum = new Random();

         // Retrieve the data source from session state.
         DataTable dt = (DataTable)Session["Source"];

         // Define the columns of the table.
         dt.Columns.Add(new DataColumn("IntegerValue", typeof(Int32)));
         dt.Columns.Add(new DataColumn("StringValue", typeof(String)));
         dt.Columns.Add(new DataColumn("CurrencyValue", typeof(Double)));

         // Populate the table with sample values.
         for (int i = 0; i <= 8; i++)
         {
            DataRow dr = dt.NewRow();
            dr[0] = i;
            dr[1] = "Item " + randNum.Next(1, 15).ToString();
            dr[2] = 1.23 * randNum.Next(1, 15);
            dt.Rows.Add(dr);
         }

         // To persist the data source between posts to the server,
         // store it in session state.  
         Session["Source"] = dt;
         DataView dv = new DataView(dt);
         return dv;
      }

      //private void BindGridViewBooks()
      private void BindGridViewBooks()
      {
         // Define data objects
         SqlConnection conn;
         SqlCommand comm;
         SqlDataReader reader;
         string connectionString ="Data Source=(localdb)\\Projects " +
         "Initial Catalog=db84270 " +
         "providerName=System.Data.SqlClient";


         // Initialize connection
         conn = new SqlConnection(connectionString);
         // Create command
         comm = new SqlCommand(
         "SELECT t.Isbn, t.Title, t.Type, " +
         "{ fn CONCAT(a.LastName + ', ', a.FirstName) } AS AuthorName, t.SellingPrice " +
         "FROM Title AS t INNER JOIN Author AS a " +
         "INNER JOIN Wrote AS w ON a.AuthorId = w.AuthorId ON t.Isbn = w.Isbn"
         , conn);
         //+ "ORDER BY AuthorName"

         // Enclose database code in Try-Catch-Finally
         StringBuilder errorMessages = new StringBuilder();
         try
         {
            // Open the connection
            conn.Open();
            // Execute the command
            reader = comm.ExecuteReader();
            // Fill the grid with data
            //gridViewBooks.DataSource = reader;
            ItemsGrid.DataSource = reader;
            //ItemsGrid.DataKeyNames = new string[] { "Title" };
            ItemsGrid.DataBind();
            // Close the reader
            reader.Close();
         }
         catch (SqlException ex)
         {
            for (int i = 0; i < ex.Errors.Count; i++)
            {
               errorMessages.Append("Index #" + i + "\n" +
                   "Message: " + ex.Errors[i].Message + "\n" +
                   "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                   "Source: " + ex.Errors[i].Source + "\n" +
                   "Procedure: " + ex.Errors[i].Procedure + "\n");
            }
            Console.WriteLine(errorMessages.ToString());
         }
         finally
         {
            // Close the connection
            conn.Close();
         }
         // To persist the data source between posts to the server,
         // store it in session state.  
         //Session["Source"] = ItemsGrid.DataSource;
     }

      protected void Page_Load(object sender, EventArgs e)
      {
         // Load sample data only once, when the page is first loaded.
         if (!IsPostBack)
         {
            BindGridViewBooks();
            //ItemsGrid.DataSource = CreateDataSource();
            //ItemsGrid.DataBind();
         }
      }
   }
}