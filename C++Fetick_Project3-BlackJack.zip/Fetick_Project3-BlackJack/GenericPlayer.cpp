// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: GenericPlayer.cpp
// Other files: GenericPlayer.h, House.h, House.cpp, Player.h, Player.cpp, 
//              Hand.h, Hand.cpp 
// Description: This file implementates the GenericPlayer class.
//
#include <string>
#include <iostream>
#include "GenericPlayer.h"

using namespace std;

// Constructor of the abstract-base-class GenericPlayer.
// Initialize member variables using the member initializer in the constructor.
GenericPlayer::GenericPlayer( const string& aName ) 
                            : name( aName ) 
{} // empty body

// destructor
GenericPlayer::~GenericPlayer()
{} // empty body

// Function isHitting() is a pure virtual, so it is not implemented

// Function isBusted() is a predicate function
bool GenericPlayer::isBusted() const
{  
   return ( getTotal() > 21 ); // Returns true if a GenericPlayer bust.
} // END FUNCTION

// Function bust() - announces that a GenericPlayer has busted
void GenericPlayer::bust() const // Changed from specification of type bool
{  
   cout << "\n\t" << getName() << " busts. \n";
} // END FUNCTION

// function to (set) the name
void GenericPlayer::setName( const string& aName ) 
{
   name = aName;
}

// function to (get) the name
string GenericPlayer::getName() const 
{
   return name;
}
