// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Card.h
// Other files: Card.cpp, Hand.h, Hand.cpp  
// Description: This header file has prototype functions for the Card class. 
//
#include <iostream>

using namespace std;

#ifndef CARD_H
#define CARD_H

// Card class
class Card
{
   // Friend the Overload operator<<() function prototypes
   // so the Card object can be sent to cout 
   friend ostream& operator<<(ostream& output, const Card& aCard);

public:
   // enumurators declared and initialized before the member variables
   enum RANK {ACE=1,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE,TEN,JACK,QUEEN,KING};
   enum SUIT {CLUBS,DIAMONDS,HEARTS,SPADES};

protected:
   // member variables
   RANK rank;
   SUIT suit;

public:
   // constructor - overloaded
   Card( RANK rank=ACE, SUIT suit=SPADES, bool isFaceUp=true);

   // member functions
   // Returns the card value if it is facing up. Otherwise return 0
	int getValue() const; 
	void flip(); // Flips a card; face up becomes face down, and vice-versa.
   
private:
   // member variable
   bool isFaceUp;
};
#endif //CARD_H