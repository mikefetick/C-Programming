// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Card.cpp
// Other files: Card.h, Hand.h, Hand.cpp, 
// Description: This file implementates the Card class.
//
#include "Card.h"

using namespace std;

// Constructor - Initialize member variables using the member initializer
Card::Card( RANK r, SUIT s, bool ifUp ) 
    : rank(r), suit(s), isFaceUp(ifUp)
{} // empty body

// Function getValue
int Card::getValue() const
{
   // Return the value of the card if the card is face up, 
   int value = 0;
   if ( isFaceUp )
   {
      // NOTE: The jack, queen, king have a value 10
      if ( ( (int) rank ) > 10 )
      {
         value = 10; 
      }
      else 
      {
         value = (int) rank;
      }
   }
   else
   {  // Otherwise not faceUp returns 0
      return 0; 
   }
   return value; 
} // END FUNCTION

// Function flip() flips a card. 
void Card::flip()
{
   isFaceUp = !isFaceUp;
} // END FUNCTION
