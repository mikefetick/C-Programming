// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: GenericPlayer.h
// Other files: GenericPlayer.cpp, House.h, House.cpp, Player.h, Player.cpp, 
//              Hand.h, Hand.cpp 
// Description: This header file has prototype functions for the GenericPlayer class.
//
#include <string>
#include "Hand.h"

using namespace std;

#ifndef GENERIC_PLAYER_H
#define GENERIC_PLAYER_H   

// GenericPlayer class is derived, inheriting implementation from the base-class Hand 
// And indirectly is an abstract-base-class for the derived-classes House and Player.
class GenericPlayer : public Hand
{
   // Friend the Overload operator<<() function prototypes
   // so the Card object can be sent to cout 
   friend ostream& operator<<(ostream& output, const GenericPlayer& aGenericPlayer);

public:
   // constructor
   // Initialize the member variables using the member initializer in the constructor.
   GenericPlayer( const string& aName = "" );

   // deconstructor
   virtual ~GenericPlayer();

   // member functions
   // The keyword virtual signals intent to override
   // A pure virtual function makes GenericPlayer an abstract-base-class

   // Predicate function isHitting()- indicates GenericPlayer wants a hit 
   virtual bool isHitting() const = 0; // pure virtual function, not implemented

   // Predicate function isBusted()- indicates GenericPlayer has gone over 21 
   bool isBusted() const; // predicate function

   // Function bust()- announces that a GenericPlayer has busted 
   void bust() const; // function - not bool

   // member accessor functions
   // NOTE: WRITE APPROPRIATE CODE FOR SETTER AND GETTER FUNCTIONS FOR THIS CLASS
   void setName( const string & ); // function to (set) the name
   string getName() const; // function to (get) the name

protected:
   // member variable
   string name;
};
#endif //GENERIC_PLAYER_H