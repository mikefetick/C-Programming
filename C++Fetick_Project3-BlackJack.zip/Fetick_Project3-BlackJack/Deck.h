// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Deck.h
// Other files: Deck.cpp, Game.h, Game.cpp, Hand.h, Hand.cpp 
// Description: This header file has prototype functions for the Deck class.
//
#include "Hand.h"
#include "Card.h"
#include "GenericPlayer.h"

using namespace std;
   
#ifndef DECK_H
#define DECK_H

// Deck class is a derived-class of the base-class Hand
class Deck : public Hand
{
public:
   // constructor
   Deck();

   // destructor
	virtual ~Deck();

   // member functions
	void populate(); // Creates a standard deck of 52 cards

	void shuffle(); // Rearranges the order of the cards

   // Deals one card to a hand. A hand is any player
	void deal(Hand& aHand); 

   // Gives additional cards to a player
	void additionalCards( GenericPlayer& aGenericPlayer); 
};
#endif //DECK_H