// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: June 26, 2014
// Project: Fetick_Project3-BlackJack
// File name: BlackJack.h
// Design: Separated interface from implementation in other files
// Other files: Main.cpp and BlackJack.cpp
// Description: This program is a console application for a simple version 
// of the single player casino game BlackJack. 

// prevent multiple inclusions of the header file
#ifndef BLACKJACK_H
#define BLACKJACK_H

#include <stdio.h>
#include <iostream>
#include <string> // program uses C++ standard string class
#include <conio.h>
#include <windows.h>
using namespace std;

// BlackJack class definition
class BlackJack
{
public:
   // overloaded constructor to initialize data members of the class
   BlackJack();

   // destructor
   ~BlackJack();

   // - - - - - - (bool) Member Getter and Setter prototype functions - - - - - - 

   // private function to (set) bool computerPlays1st
   void setComputerPlays1st( bool );

   // function to (get) bool computerPlays1st
   bool getComputerPlays1st();

   // function to (set) the gameOver
   void setGameOver( bool );

   // function to (get) the gameOver
   bool getGameOver();

   // function to (set) bool goodPlay
   void setGoodPlay( bool );

   // function to (get) bool goodPlay
   bool getGoodPlay();

   // function to (set) bool isTie
   void setIsTie( bool );

   // function to (get) bool isTie
   bool getIsTie();

   // - - - - - - (char) Member Getter and Setter prototype functions - - - - - - 

   // function to (set) the level
   void setLevel( char );

   // function to (get) the level
   char getLevel();

   // private function to (set) whoPlaysNext
   void setWhoPlaysNext( char );

   // function to (get) whoPlaysNext
   char getWhoPlaysNext();

   // - - - - - - (int & size_t) Member Getter and Setter prototype functions - - - - - - 

   // function to (set) the position
   void setPosition( int );

   // function to (get) the position
   int getPosition();

   // function to (set) int winCase
   void setWinCase( int );

   // function to (get) int winCase
   int getWinCase();

   // function to (get) the boardSize
   int getBoardSize();

   // function to (set) the position
   void setStrategyIndex( size_t );

   // function to (get) the position
   size_t getStrategyIndex();

   // - - - - - - (array[] & string) Member Getter and Setter prototype functions - - - - - - 

   // function to (set) the board[]
   void setBoard();

   // function to (set) the board[]
   void setBoard( char board[] );

   // function to (get) the board[]
   char getBoard(); 

   // function to (set) the boardPlays[]
   void setBoardPlays();

   // function to (set) the boardPlays[]
   void setBoardPlays( char board[] );

   // function to (get) the board[]
   char getBoardPlays(); 

   // function to (set) the strategy1[]
   void setStrategy1();

   // function to (get) the strategy1[]
   size_t getStrategy1( size_t ); 

   // function to (set) the strategy2[]
   void setStrategy2();

   // function to (get) the strategy2[]
   size_t getStrategy2( size_t ); 

   // function to (set) the name
   void setName( string );

   // function to (get) the name;
   string getName();

   // - - - - - - (enum) Member Getter and Setter prototype functions - - - - - - 

   // - - - - - - Utility prototype functions - - - - - - 

   // Function shared from http://social.msdn.microsoft.com/Forums/en-US/d50184d2-313b-4944-8307-e0343e865879/cc-putting-the-window-in-center-of-screen
   int CenterWindow();

   // function to display the game instuctions
   void displayInstructions();

   // function to display the game board
   void displayBoard();

   // function to display the game board
   void displayBoardPlays();

   // function to run the game
   void run();

   // gotoXY() is a private member function to set the Cursor Position
   void gotoXY(int, int ); 

protected:
   static const int boardSize = 9;

private:
   static const char computer = 'O';
   static const char human = 'X';
   static const int lineSize = 3;
   bool computerPlays1st;
   bool gameOver;
   bool goodPlay;
   bool isTie;
   char level;
   char whoPlaysNext;
   int position;
   int winCase;
   size_t strategyIndex;
   char board[boardSize];
   char boardPlays[boardSize];
   int strategy1[boardSize];
   int strategy2[boardSize]; 
   string name;
   
   // switchTurns() between users' chance to play
   void switchTurns();

}; // end a class with the semicolon delimiter  
#endif