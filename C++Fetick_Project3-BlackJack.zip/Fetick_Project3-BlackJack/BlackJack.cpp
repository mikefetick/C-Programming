// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: June 26, 2014
// Project: Fetick_Project3-BlackJack
// File name: BlackJack.cpp
// Design: Separated interface from implementation with other files
// Other files: Main.cpp and BlackJack.h
// Description: The main function begins program execution
// Note: A copy of the formal specification is at the end.
// Description: This program is a simple version (console application) 
// of the single player casino game BlackJack. 
#include <stdio.h>
#include <iostream>
#include <string> // program uses C++ standard string class
#include <iomanip>
#include <conio.h>
#include <windows.h>
#include "BlackJack.h" // include definition of class TicTacToe
;using namespace std;

// To call the CenterWindow function to center and resize the window
// Downloaded from http://social.msdn.microsoft.com/Forums/en-US/d50184d2-313b-4944-8307-e0343e865879/cc-putting-the-window-in-center-of-screen
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

// Overloaded constructor to initialize data members of the class
// with defaults
BlackJack::BlackJack()
{
   // call set functions to set member data
   setComputerPlays1st( false );
   setGameOver( false );
   setGoodPlay( false );
   setIsTie ( false ); 
   setLevel( level );
   setWhoPlaysNext( human );
   setPosition( position );
   setWinCase( 0 ); 
   setStrategyIndex( 0 );
	setBoard();
	setBoardPlays();
   setStrategy1();
   setStrategy2();
	setName( name );
} // end constructor

// deconstructor
BlackJack::~BlackJack()
{
   // no comment
} // end deconstructor

// - - - - - - (bool) Member Getter and Setter functions - - - - - - 

// function to (set) bool computerPlays1st
void BlackJack::setComputerPlays1st( bool computerPlays )
{
   computerPlays1st = computerPlays;
}
// function to (get) bool computerPlays1st
bool BlackJack::getComputerPlays1st()
{
   return computerPlays1st;
}
// function to (set) the gameOver
void BlackJack::setGameOver( bool isOver )
{
   gameOver = isOver;
}
// function to (get) the gameOver
bool BlackJack::getGameOver()
{
   return gameOver;
}
// function to (set) bool goodPlay
void BlackJack::setGoodPlay( bool good )
{
   goodPlay = good;
}
// private function to (get) bool goodPlay
bool BlackJack::getGoodPlay()
{
   return goodPlay;
}
// function to (set) bool isWin
void BlackJack::setIsTie( bool tie )
{
   isTie = tie;
}
// function to (get) bool isWin
bool BlackJack::getIsTie()
{
   return isTie;
}

// - - - - - - (char) Member Getter and Setter functions - - - - - - 

// private function to (set) the level
void BlackJack::setLevel( char theLevel )
{
   level = theLevel;
}
// function to (get) the level
char BlackJack::getLevel()
{
   return level;
}
// function to (set) whoPlaysNext
void BlackJack::setWhoPlaysNext( char whoPlays )
{
   whoPlaysNext = whoPlays;
}
// function to (get) whoPlaysNext
char TicTacToe::getWhoPlaysNext()
{
   return whoPlaysNext;
}

// - - - - - - (int & size_t) Member Getter and Setter functions - - - - - - 

// function to (set) the position
void BlackJack::setPosition( int thePosition )
{
   position = thePosition;
}
// function to (get) the position
int BlackJack::getPosition()
{
   return position;
}

void BlackJack::setWinCase( int win )
{
   winCase = win;
}
// function to (get) bool isWin
int BlackJack::getWinCase()
{
   return winCase;
}
// function to (get) the boardSize
int BlackJack::getBoardSize()
{
   return boardSize;
}
// function to (set) the strategy index
void BlackJack::setStrategyIndex( size_t theIndex )
{
   strategyIndex = theIndex;
}
// function to (get) the strategy index
size_t BlackJack::getStrategyIndex()
{
   return strategyIndex;
}

// - - - - - - (array[] & string) Member Getter and Setter functions - - - - - - 

// function to (set) the board[boardSize]
void BlackJack::setBoard()
{
   // declare control variable size_t (unsigned)
   for ( size_t i = 0; i < boardSize; i++ ) 
   {
      board[ i ] = ('1' + i);
   }
}
// overloaded function to (set) the board[boardSize]
void BlackJack::setBoard( char theBoard[boardSize] )
{
   board[boardSize] = theBoard[boardSize];
}
// function to (get) the board[boardSize]
char BlackJack::getBoard()
{
   return board[boardSize];
}
// function to (set) the boardPlays[boardSize]
void BlackJack::setBoardPlays()
{
   // declare control variable size_t (unsigned)
   for ( size_t j = 0; j < boardSize; j++ ) 
   {
      boardPlays[ j ] = (' ');
   }
}
// overloaded function to (set) the boardPlays[boardSize]
void BlackJack::setBoardPlays( char thatBoard[boardSize] )
{
   boardPlays[boardSize] = thatBoard[boardSize];
}
// function to (get) the boardPlays[boardSize]
char BlackJack::getBoardPlays()
{
   return boardPlays[boardSize];
}

// function to (set) the strategy1[]
void BlackJack::setStrategy1()
{
   // {4,0,2,6,8,1,3,5,7}
   strategy1[ 0 ] = 4;
   strategy1[ 1 ] = 0;
   strategy1[ 2 ] = 2;
   strategy1[ 3 ] = 6;
   strategy1[ 4 ] = 8;
   strategy1[ 5 ] = 1;
   strategy1[ 6 ] = 3;
   strategy1[ 7 ] = 5;
   strategy1[ 8 ] = 7;
}
// function to (get) the strategy1[]
size_t BlackJack::getStrategy1( size_t ndex )
{
   return strategy1[ndex];
}
// function to (set) the strategy2[]
void BlackJack::setStrategy2()
{
   // {4,0,2,6,8,1,3,5,7}
   strategy2[ 0 ] = 4;
   strategy2[ 1 ] = 0;
   strategy2[ 2 ] = 2;
   strategy2[ 3 ] = 6;
   strategy2[ 4 ] = 8;
   strategy2[ 5 ] = 1;
   strategy2[ 6 ] = 3;
   strategy2[ 7 ] = 5;
   strategy2[ 8 ] = 7;
}
// function to (get) the strategy2[]
size_t BlackJack::getStrategy2( size_t ndex )
{
   return strategy2[ndex];
}

// function to (set) the name
void BlackJack::setName( string theName )
{
   name = theName;
}
// function to (get) the name
string BlackJack::getName()
{
   return name;
}

// - - - - - - (enum) Member Getter and Setter functions - - - - - - 

// - - - - - - Utility functions - - - - - - 

// Function downloaded from http://social.msdn.microsoft.com/Forums/en-US/d50184d2-313b-4944-8307-e0343e865879/cc-putting-the-window-in-center-of-screen
int BlackJack::CenterWindow()
{
	// Get the window console handle(isn't the right code but works for this sample
	HWND ConsoleWindow;
	ConsoleWindow=GetForegroundWindow();

	// Getting the desktop handle and rectangle
	HWND   hwndScreen;
	RECT   rectScreen;		
	hwndScreen=GetDesktopWindow ();  
	GetWindowRect(hwndScreen,&rectScreen); 		
	
	// Set windows size(see the width problem)
	SetWindowPos (ConsoleWindow,NULL,0,0,1000,500, SWP_SHOWWINDOW); 

	// Get the current width and height of the console
	RECT rConsole;
	GetWindowRect (ConsoleWindow,&rConsole); 		
	int Width = rConsole.left = rConsole.right;
	int Height = rConsole.bottom - rConsole.top;
	
	// Calculate the window console to the center of the screen	
	int ConsolePosX;
	int ConsolePosY;		
	ConsolePosX = ((rectScreen.right-rectScreen.left)/2-Width/2 );
	ConsolePosY = ((rectScreen.bottom-rectScreen.top)/2- Height/2 );	
	SetWindowPos(ConsoleWindow,NULL,ConsolePosX,ConsolePosY, Width, Height, SWP_SHOWWINDOW || SWP_NOSIZE);

	return 0;
}
// function to display the game instuctions
void BlackJack::displayInstructions()
{
   CenterWindow();
   cout << endl;
   cout << setw(55) << "  - - -   T I C - T A C - T O E   - - - \n\n" << endl;
   cout << "  Instructions: This is the traditional TIC-TAC-TO game. Players take turns " << endl;
   cout << "  positioning thier token on an empty spot and win by being first to place " << endl;
   cout << "  three tokens in a straight line, in any direction.\n" << endl;
   cout << "  Player:  X - Human " << "  Tests: {5,6,4} {1,4,7} {2,4,6,8} {5,2,4,9} {1,6,7,2,8}" << endl;
   cout << "  Player:  O - Computer\n" << endl;
} // end function
// function to display the game board
void BlackJack::displayBoard()
{
   // Single dimension array to represent 3 x 3 grid for representing BlackJack board,
   // the board[] array has elements with position numbers to show positions for human choices.
   gotoXY(0,17); // origin of the board grid
   cout << "     |   |   " <<  endl;
   cout << setw(4) << board[0] <<  " | " << board[1] << " | " << board[2] << endl;
   cout << "     |   |   " <<  endl;
   cout << "  ---+---+---" <<  endl;
   cout << "     |   |   " <<  endl;
   cout << setw(4) << board[3] <<  " | " << board[4] << " | " << board[5] << endl;
   cout << "     |   |   " <<  endl;
   cout << "  ---+---+---" <<  endl;
   cout << "     |   |   " <<  endl;
   cout << setw(4) << board[6] <<  " | " << board[7] << " | " << board[8] << endl;
   cout << "     |   |   " <<  endl;
} // end function
void BlackJack::displayBoardPlays()
{
   // Single dimension array to represent 3 x 3 grid for representing BlackJack board,
   // the boardPlays[] array does not have elements with position numbers and shows white space.
   gotoXY(0,17); // origin of the board grid
   cout << "     |   |   " <<  endl;
   cout << setw(4) << boardPlays[0] <<  " | " << boardPlays[1] << " | " << boardPlays[2] << endl;
   cout << "     |   |   " <<  endl;
   cout << "  ---+---+---" <<  endl;
   cout << "     |   |   " <<  endl;
   cout << setw(4) << boardPlays[3] <<  " | " << boardPlays[4] << " | " << boardPlays[5] << endl;
   cout << "     |   |   " <<  endl;
   cout << "  ---+---+---" <<  endl;
   cout << "     |   |   " <<  endl;
   cout << setw(4) << boardPlays[6] <<  " | " << boardPlays[7] << " | " << boardPlays[8] << endl;
   cout << "     |   |   " <<  endl;
} // end function
// function to run the game
void BlackJack::run()
{
   // Display board with function displayBoard()
   displayBoard(); 

   // Locally define a delta factor of the difference between the human
   // (input) 'position' - (size_t) '0' to identify the array[index]
   size_t delta;
   do // Loop while not gameOver
   {
      goodPlay = false; 
      do // Loop While not goodPlay
      {
         if (getWhoPlaysNext() == 'c') // (computer)
         {
            if ( getComputerPlays1st() ) // (true)
            {
               // Set position = strategy1 array [iterated] element
               size_t thisIndex = getStrategyIndex();
               position = getStrategy1( thisIndex );

               // To validate an empty position on the game board:
               // 1) Get the play as a char position. 
               // 2) For the corresponding board position, delta: position - (int)'0' - 3 
               // 3) Compare (char) content of (int) board position to tokens. 
               // 4) Accept position if compare does not equal 'X' or 'O' thus, not taken.
               boardPlays[boardSize] = getBoardPlays();
               if ( !( (char) ( boardPlays[ (size_t) position ] ) == 'X'
                    || (char) ( boardPlays[ (size_t) position ] ) == 'O' ) ) // (available)
               {
                  // Update board
                  board[ (size_t) position ] = 'O'; // board with numbers (computer)
                  // Update boardPlays
                  boardPlays[ (size_t) position ] = 'O'; // board without numbers (computer)
                  // display board
                  displayBoard(); 
                  goodPlay = true; 
               }
               gotoXY(0,15); // Show who's turn to play here
               cout << "  Player: \'O\' (Computer)                                    "; 
               gotoXY(0,29); // Show prompt here
               cout << "  Computer's \'O\' played at position " << position + 1 << endl; 
               setStrategyIndex( getStrategyIndex() + 1 );
            } // getComputerPlays1st() (true)
            else // (false)
            {
               // Set position = strategy2 array [iterated] element
               size_t thisIndex = getStrategyIndex();
               position = getStrategy2( thisIndex );

               // To validate an empty position on the game board:
               // 1) Get the play as a char position. 
               // 2) For the corresponding board position: - (int)'0' = delta integer, - 1 
               // 3) Compare (char) content of (int) board position to tokens. 
               // 4) Accept position if compare does not equal 'X' or 'O' thus, not taken.
               boardPlays[boardSize] = getBoardPlays();
               if ( !( (char) ( boardPlays[ (size_t) position ] ) == 'X'
                    || (char) ( boardPlays[ (size_t) position ] ) == 'O' ) ) // (available)
               {
                  // Update board
                  board[ (size_t) position ] = 'O'; // board with numbers (computer)
                  // Update boardPlays
                  boardPlays[ (size_t) position ] = 'O'; // board without numbers (computer)
                  // set and display board
                  displayBoard(); 
                  goodPlay = true; 
               }
               gotoXY(0,15); // Show who's turn to play here
               cout << "  Player: \'O\' (Computer)                                    "; 
               gotoXY(0,29); // Show prompt here
               cout << "  Computer's \'O\' played at position " << position + 1 << endl; 
               setStrategyIndex( getStrategyIndex() + 1 );
            } // getComputerPlays1st() (false)
         } // getWhoPlaysNext() (computer)
         else  // else if getWhoPlaysNext() (human)
         {
            position = 0;
            while ( position < char(1) && position < char(9) ) // Loop for valid input (1..9)
            {
               gotoXY(0,15); // Show who's turn to play here
               cout << "  Player: \'X\' (Human) " << getName() << "                                  "; 
               gotoXY(0,29); // Show prompt here
               cout << "  Play which position (1..9)? "; // Prompt user to pick position
               position = _getch();
            }
            // To validate an empty position on the game board:
            // 1) Get the play as a char position. 
            // 2) For the corresponding board position: - (int)'0' = delta integer, - 1 
            // 3) Compare (char) content of (int) board position to tokens. 
            // 4) Accept position if compare does not equal 'X' or 'O' thus, not taken.
            cout << ( position - (size_t) '0' );
            delta = ( position - (size_t) '0' ) - 1;
            boardPlays[boardSize] = getBoardPlays();
            if ( !( (char) ( boardPlays[ (size_t) delta ] ) == 'X'
                  || (char) ( boardPlays[ (size_t) delta ] ) == 'O' ) ) // (available)
            {
               // Update board
               board[ (size_t) delta ] = 'X'; // board with numbers (human)
               // Update boardPlays
               boardPlays[ (size_t) delta ] = 'X'; // board without numbers (human)
               // set and display board
               displayBoard(); 
               goodPlay = true; 
            }
         } // else if getWhoPlaysNext() (human)
      } while (!goodPlay); // End While Loop (not goodPlay)

      // For each play, check all the conditions for a winner, the winCase is 0
      board[boardSize] = getBoard();
      // If 3 across 1st row
      if ( ( (char) board[0] == 'X' && (char) board[1] == 'X' && (char) board[3] == 'X' )
        || ( (char) board[0] == 'O' && (char) board[1] == 'O' && (char) board[3] == 'O' ) ) 
      {
         setWinCase(1); // If 3 across 1st row
         setGameOver( true );
      }
      // If 3 across 2nd row
      if ( !getGameOver() && 
           ( ( (char) board[3] == 'X' && (char) board[4] == 'X' && (char) board[5] == 'X' )
          || ( (char) board[3] == 'O' && (char) board[4] == 'O' && (char) board[5] == 'O' ) ) )
      {
         setWinCase(2); // If 3 across 2nd row
         setGameOver( true );
      }
      // If 3 across 3rd row
      if ( !getGameOver() && 
           ( ( (char) board[6] == 'X' && (char) board[7] == 'X' && (char) board[8] == 'X' )
          || ( (char) board[6] == 'O' && (char) board[7] == 'O' && (char) board[8] == 'O' ) ) )
      {
         setWinCase(3); // If 3 across 3rd row
         setGameOver( true );
      }
      // If 3 down 1st column
      if ( !getGameOver() && 
           ( ( (char) board[0] == 'X' && (char) board[3] == 'X' && (char) board[6] == 'X' )
          || ( (char) board[0] == 'O' && (char) board[3] == 'O' && (char) board[6] == 'O' ) ) )
      {
         setWinCase(4); // If 3 down 1st column
         setGameOver( true );
      }
      // If 3 down 2nd column
      if ( !getGameOver() && 
           ( ( (char) board[1] == 'X' && (char) board[4] == 'X' && (char) board[7] == 'X' )
          || ( (char) board[1] == 'O' && (char) board[4] == 'O' && (char) board[7] == 'O' ) ) )
      {
         setWinCase(5); // If 3 down 2nd column
         setGameOver( true );
      }
      // If 3 down 3rd column
      if ( !getGameOver() && 
           ( ( (char) board[2] == 'X' && (char) board[5] == 'X' && (char) board[8] == 'X' )
          || ( (char) board[2] == 'O' && (char) board[5] == 'O' && (char) board[8] == 'O' ) ) )
      {
         setWinCase(6); // If 3 down 3rd column
         setGameOver( true );
      }
      // If 3 diagonally down from top-left to bottom-right
      if ( !getGameOver() && 
           ( ( (char) board[0] == 'X' && (char) board[4] == 'X' && (char) board[8] == 'X' )
          || ( (char) board[0] == 'O' && (char) board[4] == 'O' && (char) board[8] == 'O' ) ) )
      {
         setWinCase(7); // If 3 diagonally down from top-left to bottom-right
         setGameOver( true );
      }
      // If 3 diagonally up from bottom-left to top-right
      if ( !getGameOver() && 
           ( ( (char) board[2] == 'X' && (char) board[4] == 'X' && (char) board[6] == 'X' )
          || ( (char) board[2] == 'O' && (char) board[4] == 'O' && (char) board[6] == 'O' ) ) )
      {
         setWinCase(8); // If 3 diagonally up from bottom-left to top-right
         setGameOver( true );
      } 
      // ...All the conditions for a winner were just checked

      // If not getGameOver() by a winner then check for a tie.
      if ( !getGameOver() )
      {
         // if any positions are available, then the game is not a tie
         setIsTie( true );
         for ( int i = 0; i < boardSize; i++)
         {
            if ( (char) ( boardPlays[ i ] ) == ' ' ) // (available)
            {
               setIsTie( false );
               i = getBoardSize();
            }
         }
         // if all positions are not available, then the game is a tie
         if ( getIsTie() )
         {
            setWinCase(9);
            setGameOver( true );
         }
      }

      // If the flag for a winning case changed (is not the initial value)...
      if ( getWinCase() != 0 )
      {
         // Display board plays without lines or number positions
         displayBoardPlays();

         // Display one of eight ways to be a �Winner!� with the winning line
         int k; // declare a type K now for multiple refernces of a row
         switch ( getWinCase() )
         {
            case 1: // 3 across 1st row
               // gotoXY(0,18)..gotoXY(11,18)
               for (int j = 2; j < 14; j++)
               {
                  gotoXY(j,18); // symbol location on the board here
                  cout << "-";
                  j++;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 2: // 3 across 2nd row
               // gotoXY(0,22)..gotoXY(11,22)
               for (int j = 2; j < 14; j++)
               {
                  gotoXY(j,22); // symbol location on the board here
                  cout << "-";
                  j++;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 3: // 3 across 3rd row
               // gotoXY(0,26)..gotoXY(11,26)
               for (int j = 2; j < 14; j++)
               {
                  gotoXY(j,26); // symbol location on the board here
                  cout << "-";
                  j++;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 4: // 3 down 1st column
               // gotoXY(1,17)..gotoXY(1,27)
               for (int j = 17; j < 29; j++)
               {
                  gotoXY(3,j); // symbol location on the board here
                  cout << "|";
                  j++;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 5: // 3 down 2nd column
               // gotoXY(5,17)..gotoXY(5,27)
               for (int j = 17; j < 29; j++)
               {
                  gotoXY(7,j); // symbol location on the board here
                  cout << "|";
                  j++;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 6: // 3 down 3rd column
               // gotoXY(9,17)..gotoXY(9,27)
               for (int j = 17; j < 29; j++)
               {
                  gotoXY(11,j); // symbol location on the board here
                  cout << "|";
                  j++;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 7: // 3 diagonally down from top-left to bottom-right
               // gotoXY(0,17)..diagonally down..gotoXY(10,27)
               k = 17;
               for (int j = 2; j < 14; j++)
               {
                  gotoXY(j,k); // symbol location on the board here
                  cout << "\\";
                  j++;
                  k = k + 2;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 8: // 3 diagonally up from bottom-left to top-right
               // gotoXY(0,17)..diagonally up..gotoXY(10,27)
               k = 27;
               for (int j = 2; j < 14; j++)
               {
                  gotoXY(j,k); // symbol location on the board here
                  cout << "\/";
                  j++;
                  k = k - 2;
               }
               gotoXY(0,29); // show message here
               cout << "  WINNER!                              " << endl;
               break;
            case 9: // A tie with no winner
               gotoXY(0,29); // show message here
               cout << "  TIE - NO WINNER!                     " << endl;
               break;
         } // end switch ( getIsWin() )
         setGameOver(true); // no more plays to loop through
         if (getWhoPlaysNext() != 'c') // (computer)
         {
            cout << "  Press a key to continue... "; 
            _getch();
         }
      } // if ( getIsWin() != 0 )

      // if a good play, switch turns to the other player
      if ( goodPlay )
      {
         switchTurns();
      }
      
   } while ( ! getGameOver() ); // End while loop gameOver

} // End function run()
void BlackJack::switchTurns()
{
   if ( getWhoPlaysNext() == 'c' ) // (computer)
   {
      // Pause the display and prompt the user to continue
      cout << "  Press a key to continue... "; 
      _getch();
      gotoXY(0,29); // clear the message that is here
      cout << "                                       " << endl; 
      cout << "                                       "; 
      setWhoPlaysNext('h'); // (human)
   }
   else 
   {
      setWhoPlaysNext('c'); // (computer)
   }
}
void BlackJack::gotoXY( int x, int y ) 
{ 
   // position the cursor to an x, y position on the console window
   CursorPosition.X = x; 
   CursorPosition.Y = y; 
   SetConsoleCursorPosition(console,CursorPosition); 
}