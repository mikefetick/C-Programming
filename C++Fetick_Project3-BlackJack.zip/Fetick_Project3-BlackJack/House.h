// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: House.h
// Other files: House.cpp, Game.h, Game.cpp, GenericPlayer.h, GenericPlayer.cpp 
// Description: This header file has prototype functions for the House class.
//
#include <string>
#include <vector>
#include "GenericPlayer.h"

using namespace std;

#ifndef HOUSE_H
#define HOUSE_H

// House class is a derived-class of the base-class GenericPlayer
class House : public GenericPlayer
{
public:
   // constructor
   // Call the base class GenericPlayer constructor to initialize the member variable
   House( const string& aName = "Dealer" );

   // destructor
	virtual ~House(); 

   // member functions
	virtual bool isHitting() const; // Concrete function. Indicates dealer wants a hit
	void flipFirstCard() const; // Flips over the first card
};
#endif //HOUSE_H