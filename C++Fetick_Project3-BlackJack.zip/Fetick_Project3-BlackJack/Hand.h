// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name:Hand.h
// Other files: Hand.cpp, Deck.h, Deck.cpp, GenericPlayer.h, GenericPlayer.cpp, 
//              Card.h, Card.cpp 
// Description: This header file has prototype functions for the Hand class.
//
#include <vector>
#include "Card.h"

using namespace std;
   
#ifndef HAND_H
#define HAND_H

// Hand class is the base-class for the derived-classes Deck and GenericPlayer
class Hand
{
public:
   // constructor
   Hand();

   // destructor
	virtual ~Hand(); 

   // member functions
	void add( Card* cardPtr ); // Adds a card* to the hand
	void clearHand(); // Clears all cards from the hand
	int getTotal() const; // Returns the total value of the hand

protected:
   // member variable
   vector<Card*> cardVector;
};
#endif //HAND_H