﻿// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Main.cpp
// Other files: Game.h, Game.cpp
// Description: This file has the main function that begins program execution. 
// The program is a console application for a simple version of the single player 
// casino game BlackJack.
//
// Note: A copy of the BlackJack Project Specification is located in the file 
// ProjectLog.cpp and the progress of code development is documented in the 
// Progress Log, located at the end of the file.
//
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <windows.h>
#include "Game.h"
#include "Card.h"

using namespace std;

// Overload operator<<() function prototypes
// so the Card object can be sent to cout 
ostream& operator<<(ostream& output, const Card& aCard);
ostream& operator<<(ostream& output, const GenericPlayer& aGenericPlayer);

// Get console Cursor Position
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

// Helper Functions prototypes
void instructions();
void gotoXY( int, int ); 
void clearPrevious();

// The main function begins program execution
// NOTE: This file contains the bare minimum code for the project, 
// with an object declaration and host member function calls.
int main()
{
   // Get and set console window size
   HWND console = GetConsoleWindow();
   RECT r;
   GetWindowRect(console, &r); //stores the console's current dimensions
   MoveWindow(console, r.left, r.top, 800, 850, TRUE); // 800 width, 850 height

   // Print appropriate welcome message to begin the game
   cout << "\n\n\t\t\tB L A C K J A C K \n" << endl;
   cout << "\t\tWelcome to Blackjack! Have fun playing!\n" << endl;

   // Print game instructions
   instructions();

   // For one player
   string aName;
   // Prompt for the player's name and store it.
   cout << "\tPlease enter the player's name: ";
   cin >> aName;
   cout << "\n" << endl;

   // the game loop
   // Create a character variable called 'again' and initialize it to 'y'
   char again = 'y';
   do // while (again = 'y')
   {
      // Create a game object and pass the name to it
      Game aGame(aName);

      // Call the function play() using the game object. 
      gotoXY(0,32); // Clear previous here, including quiry for name
      clearPrevious();
      gotoXY(0,34); // Show prompt here
      aGame.play();

      // [Use a sentinel controlled loop around this to prompt the player 
      // and check if he wants to play again to stay in the game. 
      cout << "\n\tDo you want to play again (y/n)? ";
      cin >> again;
      cout << endl;
      // You exit the game when the user chooses 'no']
   } while (again != 'n');

   // Program termination
   return 0;

} // end function main

// Overloads the << operator so the Card object can be sent to cout 
   // Note that the left parameter is a reference to object of the output stream 
	// and the right parameter is a reference to an object of a user defined datatype 
ostream& operator<<(ostream& output, const Card& aCard)
{
   const string RANKS[] = {"0","A","2","3","4","5","6","7","8","9","10","J","Q","K"};
   //const string SUITS[] = {"C","D","H","S"};
   const char SUITS[] = {'C','D','H','S'};
   // If the card is face up, output the value of the card. 
   if ( aCard.isFaceUp )
   {
      output << RANKS[ aCard.rank ] << SUITS[ aCard.suit ];
   }
   else
   {  // Otherwise the card is face down, output XX
      output << "XX";
   }
	return output;
}

// Overloads the << operator so the GenericPlayer object can be sent to cout 
   // Note that the left parameter is a reference to object of the output stream 
	// and the right parameter is a reference to an object of a user defined datatype 
ostream& operator<<(ostream& output, const GenericPlayer& aGenericPlayer)
{
	// Store the name followed by a tab space in the output object
   output << "\t" << aGenericPlayer.getName() << ":\t";

   // Create a vector iterator of type Card*
   vector<Card*>::const_iterator vectorIter;

   // If cardVector is not empty [use empty() in vector library] THEN
   if ( !aGenericPlayer.cardVector.empty() )
   {  
      // Loop though all the cards for that player
      for ( vectorIter  = aGenericPlayer.cardVector.begin(); 
            vectorIter != aGenericPlayer.cardVector.end(); 
            ++vectorIter )
      {
         output << *(*vectorIter) << "\t";
      }
      // If the total score does not equal zero
      int totalScore = aGenericPlayer.getTotal();
      if ( totalScore != 0 )
      {
         // then append the total score to the output object
         cout << "(" << totalScore << ")";
      }
   }
   else // ELSE
   { // append an empty hand.
      output << "<empty>";
   } // END IF
   output << "\n";

   return output; // object

} // END ostream& operator<<

void instructions()
{
   cout << "\tOverview \n" << endl;
   cout << "\tIn blackjack, the cards are valued as follows:" << endl;
   cout << "\to An Ace can count as either 1 or 11." << endl;
   cout << "\to The cards from 2 through 9 are valued at their face value." << endl;
   cout << "\to The 10, Jack, Queen, and King are all valued at 10. \n" << endl;
   cout << "\tThe suits of the cards do not have any meaning in the game." << endl;
   cout << "\tThe value of a hand is simply the sum of the point counts of " << endl;
   cout << "\teach card in the hand. For example, a hand containing (5,7,9) " << endl;
   cout << "\thas the value of 21. The Ace can be counted as either 1 or 11." << endl;
   cout << "\tThe value of the Ace is not specified. It's assumed to always " << endl;
   cout << "\thave the value that makes the best hand. Once all the players" << endl;
   cout << "\tare ready, the dealer will deal the cards to the players." << endl;
   cout << "\tHe'll make two passes so that the players and the dealer have " << endl;
   cout << "\ttwo cards each. The dealer will flip one of his cards over, " << endl;
   cout << "\texposing its value. Once the cards are dealt play proceeds " << endl;
   cout << "\taround the table. Each player in turn indicates to the dealer " << endl;
   cout << "\thow he wishes to play the hand. The most common decision a " << endl;
   cout << "\tplayer must make during the game is whether to draw another " << endl;
   cout << "\tcard to the hand 'hit', or stop at the current total 'stand'." << endl;
   cout << "\tA blackjack, or natural, is a total of 21 in your first two " << endl;
   cout << "\tcards. The basic premise of the game is that you want to have" << endl;
   cout << "\ta hand value that is closer to 21 than that of the dealer, "<< endl;
   cout << "\twithout going over 21. \n" << endl;
}
void gotoXY( int x, int y ) 
{ 
   // position the cursor to an x, y position on the console window
   CursorPosition.X = x; 
   CursorPosition.Y = y; 
   SetConsoleCursorPosition(console,CursorPosition); 
}
void clearPrevious()
{
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
   cout << "                                                              " << endl;
}