// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name:Hand.cpp
// Other files: Hand.h, Deck.h, Deck.cpp, GenericPlayer.h, GenericPlayer.cpp, 
//              Card.h, Card.cpp 
// Description: This file implementates the Hand class.
//
#include <vector>
#include <algorithm>
#include "Hand.h"
#include "Card.h"

using namespace std;

// Constructor has-a (composite) relationship to Card
Hand::Hand()
{
   cardVector.reserve(7); // Call the function cardVector.reserve(52)
}
// destructor
Hand::~Hand() 
{
   clearHand(); // Call function clearHand()
}

// Function add - Adds a card to the hand.
void Hand::add( Card* cardPtr ) // cardPtr is declared in the parameter list
{  
   // Call push_back() on the cardVector and pass the cardPtr as its argument
   cardVector.push_back( cardPtr );
} // END FUNCTION

// Function clearHand - Clears all cards from the hand
void Hand::clearHand()
{
   // Declare an iterator of the type vector<Card*> as a pointer to a card
   vector <Card*>::iterator iter = cardVector.begin();

   // using the iterator, delete each *iter [name of the iterator]
   for ( iter = cardVector.begin(); iter != cardVector.end(); ++iter )
   {
      delete *iter;
      *iter = 0; // Set the *iter to NULL -- Good practice
   }

   // Call function clear() on cardVector
   cardVector.clear();

} // END FUNCTION

// Function getTotal - Returns the total value of the hand.
int Hand::getTotal() const
{
   // If no cards in the hand (cardVector is empty) 
   // Hint: empty is a function defined in vector class
   if ( cardVector.empty() )
   {
      return 0;
   } // ENDIF

   // If the card is face down then the value of the first card is 0
   // Hint: use cardVector[0]-> getValue()
   if ( ( cardVector[0]-> getValue() ) == 0 )  // Run-time error here
   {
      return 0;
   }
   else
   {
   } // END ELSE

   // To add up the card values LOOP through the vector (using an iterator)
    vector <Card*>::const_iterator iter;
   // Hint use (*iter)->getValue() to get the value of each card.

   // Return the total of the sum value for all the cards of the hand.
   int total = 0;
   // during the LOOP, check if it contains an Ace and keep a count.
   int aceCount = 0;
   for ( iter = cardVector.begin(); iter != cardVector.end(); ++iter )
   {
      total += (*iter)->getValue();
      // Determine if the hand contains an Ace
      if ( (*iter)->getValue() == Card::ACE )
      {
         aceCount++;
      }
   } // END LOOP
   // while there are Aces to evaluate
   while ( aceCount > 0 )
   // The value of an Ace is determined for a win
   {
      // IF the total IS LESS THAN AND EQUAL TO 11, THEN
      if ( total <= 11 )
      {
         // add 10 to the total [since we have already set the ace to 1].
         total += 10;
         // decrement the count down to no Aces.
         aceCount--;

      } // ENDIF
      else
      {
         // would BUST the hand (over 21) if the value was increased by 10, 
         // and no interest to change more Ace values, so set aceCount to 0.
         aceCount = 0;
      }

   } // END WHILE LOOP

   // Return the total
   return total;

} // END FUNCTION
