// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Game.h
// Other files: main.cpp, Game.cpp, Deck.h, Deck.cpp, House.h, House.cpp, 
//              Player.h, Player.cpp 
// Description: This header file has prototype functions for the Game class.
//
#include <string>
#include <vector>
#include "Deck.h"
#include "House.h"
#include "Player.h"

using namespace std;

#ifndef GAME_H
#define GAME_H

// Game class
class Game
{
public:
   // constructor, static is not allowed
   Game( const string& name ); 

   // destructor
   ~Game(); 

   // member functions
	void play(); // function to play
   
private:
   // member variables of objects
   Deck deck; // composition: member object
	House house; // composition: member object
	Player player; // composition: member object

}; // end a class with the semicolon delimiter 
#endif //GAME_H