// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Player.cpp
// Other files: Player.h, Game.h, Game.cpp, GenericPlayer.h, GenericPlayer.cpp 
// Description: This file implementates the Player class.
//
#include <iostream>
#include <string>
#include "Player.h"

using namespace std;

// The constructor for a Player object
// Call the base class constructor to initialize the member variable: name
Player::Player( const string& aName ) : GenericPlayer( aName )
{} // empty body

// destructor
Player::~Player()
{} // empty body

// Predicate function isHitting() indicates whether the player wants to hit
// Concrete function, overrides pure virtual function in GenericPlayer
bool Player::isHitting() const 
{  
   // Check the player's decision to hit
   char decision;
   // by using the name of the player, prompt to do ...
   cout << "\n\t" << getName() << ", do you want to hit (y/n)? ";

   // check if he wants to hit and return appropriate values
   cin >> decision;
   cout << endl;
   return ( decision == 'y' || decision == 'Y' );

} // END FUNCTION

// Predicate function win() - Announces the player won
bool Player::win( ) const
{  
   cout << "\n\t" << GenericPlayer::getName() << ", you won! \n";
   return 0;
} 
// Predicate function lose() - Announces the player lost
bool Player::lose( ) const
{  
   cout << "\n\t" << GenericPlayer::getName() << ", you lost. \n";
   return 0;
} 
// Predicate function push() - Announces the player pushes (tie)
bool Player::push( ) const
{  // Print the name and display that the player has pushes (tie)
   cout << "\n\t" << GenericPlayer::getName() << ", you pushed. \n";
   return 0;
} 