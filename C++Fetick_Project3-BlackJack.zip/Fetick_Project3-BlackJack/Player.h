// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Player.h
// Other files: Player.cpp, Game.h, Game.cpp, GenericPlayer.h, GenericPlayer.cpp 
// Description: This header file has prototype functions for the Player class.
//
#include <iostream>
#include <string>
#include "GenericPlayer.h"

using namespace std;

#ifndef PLAYER_H
#define PLAYER_H

// Player class is a derived-class of the base-class GenericPlayer
class Player : public GenericPlayer
{
public:
   // constructor
   // Call the base class GenericPlayer constructor to initialize the member variable
   Player( const string& aName = "" );

   // destructor
	virtual ~Player(); 

   // member functions
	virtual bool isHitting() const; // Concrete function. Check if player wants to hit
	bool win() const; // Predicate function - Announces the player won
	bool lose() const; // Predicate function - Announces the player lost
	bool push() const; // Predicate function - Announces the player pushes (tie)
};
#endif //PLAYER_H