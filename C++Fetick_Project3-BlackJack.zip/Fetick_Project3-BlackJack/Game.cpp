// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Game.cpp
// Other files: main.cpp, Game.h, Deck.h, Deck.cpp, House.h, House.cpp, 
//              Player.h, Player.cpp 
// Description: This file implementates the Game class.
//
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>
#include <ctime>

#include "Deck.h"
#include "House.h"
#include "Player.h"
#include "Game.h"
#include "GenericPlayer.h"

using namespace std;

// Constructor for a Game object
Game::Game( const string& name )
{
   // Seed the random number generator for shuffle
   srand( (unsigned int) time(0) ); 

   // Call setter function for player object and pass it the name
   player.setName( name ); 

   // Call function populate() using the deck object
   deck.populate(); 

   // Call function shuffle() using the deck object
   deck.shuffle();  
} // end constructor

// destructor
Game::~Game()
{
   // no comment
} // end destructor

// Function play
void Game::play()
{
   // Deal initial 2 cards to the player and the house
   // [You will need a loop that runs twice and call deal function for each player]
   Player* playerPtr = &player;
   for ( int i = 0; i < 2; ++i ) 
   {
      deck.deal( player );
      deck.deal( house );
   }

   // Hide the house first card by calling the object function flipFirstCard()
   house.flipFirstCard();

   // Display the hand of every player object using cout 
   //[to invoke the overloaded insertion operator]
   cout << player;
   //cout << *playerPtr;

   // Display the hand of the Dealer (house object) using cout 
   //[to invoke the overloaded insertion operator]
   cout << house << endl;

   // Deal additional cards to players
   deck.additionalCards( *playerPtr );

   // Reveal the house's first card object using cout 
   // Using the house object call function flipFirstCard()
   house.flipFirstCard();
   // [to invoke the overloaded insertion operator]
   cout << endl << house;

   // Deal additional cards to house
   deck.additionalCards( house ); 

   // IF the house has busted [call isBusted()] THEN
   if ( house.isBusted() )
   {
      //house.bust();
      // everyone still playing wins if they had not busted
      if ( !( playerPtr->isBusted() ) )
      {
         // invoke the win function using the player object
         playerPtr->win();
      }
      else
      {
         playerPtr->bust();
      }
   } // ELSE
   else
   {
      // compare to the hand of each player still playing 
      ++playerPtr;
      if ( !playerPtr->isBusted() )
      {
         // compare the total score of the player with the house 
         // and display the appropriate winning, losing, push messages
         // [requires nested if..else statements]
         if ( playerPtr->getTotal() > house.getTotal()  )
         {
            playerPtr->win();
         } // END if ( playerPtr->getTotal() > house.getTotal()  )
         else
         {
            if ( playerPtr->getTotal() < house.getTotal()  )
            {
               // if the player loses
               playerPtr->lose();
            } // END if ( playerPtr->getTotal() < house.getTotal()  )
            else // not < nor > so they're equal, it's called a push
            {
               // if the player pushes
               playerPtr->push();
            }
         } // END if else.. >
      } // END if ( !playerPtr->isBusted() )
      else
      {
         playerPtr->bust();
      }
   } 
   // call the clearHand function for all player objects
   playerPtr->clearHand();

   // Call the clearHand() funtion for the house object
   house.clearHand();
  
} // END FUNCTION