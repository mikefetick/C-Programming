// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: Deck.cpp
// Other files: Deck.h, Game.h, Game.cpp, Hand.h, Hand.cpp, 
// Description: This file implementates the Deck class.
//
#include <string>
#include <vector>
#include <algorithm>
#include <iostream>

#include "Deck.h"
#include "Hand.h"
#include "Card.h"

using namespace std;
   
// The constructor for a Deck object
Deck::Deck()
{
   // Call the function cardVector.reserve(52)
   cardVector.reserve(52);

   // Call function populate()
   populate();
}
// destructor
Deck::~Deck() 
{
	// The body of the constructor remains empty.
}

// Function populate - Creates a standard deck of 52 cards.
void Deck::populate()
{  
   clearHand(); // Call function clearHand()

   // To create standard deck iterate through all ranks and suits 
   // [use nested loop on each enumerator]
   for ( int s = Card::CLUBS; s <= Card::SPADES; ++s ) // 4 suits
   {
      for ( int r = Card::ACE; r <= Card::KING; ++r ) // 13 ranks
      {
         // call function add( new Card( RANK, SUIT ) )
         // Note: Cards will be deleted from the Hand class with an iterator
         add( new Card( static_cast<Card::RANK> (r), 
                        static_cast<Card::SUIT> (s) ) );
      }
   }

} // END FUNCTION

// Function shuffle - Rearranges the order of the cards.
void Deck::shuffle()
{   
   // Call function random_shuffle(cardVector.begin(), cardVector.end())
   // [include the standard library named algorithms for this to work]
   random_shuffle( cardVector.begin(), cardVector.end() );
}

// Function deal - Deals one card to a hand. A hand is any player
void Deck::deal( Hand& aHand)
{
   // IF cardVector is not empty [use empty() in vector library] THEN
   if ( !cardVector.empty() )
   {  
      aHand.add( cardVector.back() );// add a card to the hand
      cardVector.pop_back(); // turn over the added card
   } // ELSE
   else
   {  // display an appropriate message indicating that 
      // you are out of cards and are unable to deal.
      cout << "\n\tWe are out of cards and are unable to deal! \n";
   } // END IF

} // END FUNCTION

// Function additionalCards gives additional cards to any player, 
// as long as that player can hit and wants to hit
void Deck::additionalCards( GenericPlayer& aGenericPlayer )
{  
   cout << endl;
   // WHILE a genericPlayer object is not busted and keeps hitting
   while ( !( aGenericPlayer.isBusted() ) && ( aGenericPlayer.isHitting() ) )
   {
      // call the function deal and pass the generic player object to it
      deal( aGenericPlayer );

      // Display generic player object using cout 
      // [this will invoke the overloaded insertion operator]
      cout << aGenericPlayer << endl;

      // If a generic player object is busted THEN
      if ( aGenericPlayer.isBusted() )
      {
         // call the function bust() using the generic player object
         aGenericPlayer.bust();

      } // END IF

   } // END WHILE

} // END FUNCTION
