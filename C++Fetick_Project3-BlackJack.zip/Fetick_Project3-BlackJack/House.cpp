// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 10, 2014
// Project: Fetick_Project3-BlackJack
// File name: House.cpp
// Other files: House.h, Game.h, Game.cpp, GenericPlayer.h, GenericPlayer.cpp 
// Description: This file implementates the House class.
//
#include <iostream>
#include <string>
#include "House.h"

using namespace std;

// The constructor for a House object
// Call the base-class constructor to initialize the member variable: name
House::House( const string& aName ) : GenericPlayer( aName )
{} // empty body

// destructor
House::~House()
{} // empty body

// Predicate function isHitting() indicates whether the dealer wants to hit
// Concrete function, overrides pure virtual function in GenericPlayer
bool House::isHitting() const 
{   
   // IF the value returned by getTotal() IS LESS THAN EQUAL TO 16 THEN
   return ( getTotal() <= 16 );
}

// Function flipFirstCard() - Flips over the first card.
void House::flipFirstCard() const
{  
   // IF cardVector is not empty THEN
   if ( !cardVector.empty() )
   {
       cardVector[0]->flip(); // on the first element of the vector.
   } // ELSE
   else // Display message indicating that there are no cards to flip
   {
      cout << "There are no cards to flip!" <<  endl;
   } // END IF

} // END FUNCTION
