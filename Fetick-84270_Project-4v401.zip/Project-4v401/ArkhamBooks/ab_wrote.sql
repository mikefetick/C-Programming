-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2013 at 08:58 PM
-- Server version: 5.0.95
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pm75280`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_wrote`
--

CREATE TABLE IF NOT EXISTS `ab_wrote` (
  `AuthorId` int(11) NOT NULL default '0',
  `Isbn` varchar(13) NOT NULL default '',
  `Sequence` tinyint(4) default NULL,
  PRIMARY KEY  (`AuthorId`,`Isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ab_wrote`
--

INSERT INTO `ab_wrote` (`AuthorId`, `Isbn`, `Sequence`) VALUES
(2, '0131103628', 1),
(3, '0689318960', 1),
(4, '0445406518', 1),
(4, '0446363383', 1),
(5, '0688092101', 1),
(6, '0785269606', 1),
(7, '0805015825', 1),
(8, '0376050187', 1),
(9, '1878252402', 1),
(10, '1878252186', 1),
(11, '0870541811', 1),
(12, '0345345991', 1),
(12, '0812574990', 1),
(13, '0345453751', 1),
(14, '0425140989', 1),
(14, '0425144062', 1),
(14, '0425193993', 1),
(15, '0870541781', 1),
(16, '0870541757', 1),
(17, '0140296301', 1),
(17, '0670032786', 1),
(18, '042519129X', 1),
(18, '0425198138', 1),
(19, '0380820749', 1),
(19, '0380820765', 1),
(19, '0449214222', 1),
(19, '0688010377', 1),
(20, '0449242463', 1),
(21, '0345470389', 1),
(21, '0385006009', 1),
(22, '0619016620', 1),
(23, '9781595097774', 1),
(24, '9781558464903', 1),
(24, '9781558464910', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
