﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_3
{
    public class OrderDetails : IComparable<OrderDetails>
    {
        // Constructor for the Order object
        public OrderDetails() 
        { 
            OrderDate = orderDate;
            Customer  = customer;
            ItemList  = itemList;
            Subtotal  = subtotal;
            Taxes     = taxes;
            Shipping  = shipping;
            Total     = total;
            Customer = new ContactDetails();
            ItemList = new List<ItemDetails>();
            Booklist = new List<BookDetails>();
        }

        private DateTime dateNow = new DateTime();
        private string orderDate;
        public string OrderDate
        {
            get { return orderDate; }

            set { orderDate = dateNow.ToString("d"); }
        }
        private ContactDetails customer;
        public ContactDetails Customer
        {
            get { return customer; }
            set { customer = value; }
        }
        private List<ItemDetails> itemList;
        internal List<ItemDetails> ItemList
        {
            get { return itemList; }
            set { itemList = value; }
        }
        private List<BookDetails> booklist;
        internal List<BookDetails> Booklist
        {
            get { return booklist; }
            set { booklist = value; }
        }
        private decimal subtotal;
        public decimal Subtotal
        {
            get { return subtotal; }
            set { subtotal = value; }
        }
        private const decimal TAXE_RATE = .0775M;
        private decimal taxes;
        public decimal Taxes
        {
            get { return taxes = Subtotal * TAXE_RATE; }
            set { taxes = value; }
        }
        private const decimal SHIPPING = 5;
        private decimal shipping = SHIPPING;
        public decimal Shipping
        {
            get { return shipping; }
            set { shipping = value; }
        }
        private decimal total;
        public decimal Total
        {
            get { return total; }
            set { total = value; }
        }

        // Implement the IComparable interface to override the CompareTo method
        //   with a comparison of the Order's lastName and firstName properties
        public int CompareTo(OrderDetails obj)
        {
            int returnVal;

            // Comparing the lastName
            if (Customer.LastName.CompareTo(obj.Customer.LastName) > 0)
            { returnVal = 1; }
            else
            {   // Not greater than zero, evaluate further
                if (Customer.LastName.CompareTo(obj.Customer.LastName) == 0)
                {
                    // matches lastName, so compare further with the firstName
                    if (Customer.FirstName.CompareTo(obj.Customer.FirstName) > 0)
                    { returnVal = 1; }
                    else
                    {   // Not greater than zero, evaluate further
                        if (Customer.FirstName.CompareTo(obj.Customer.FirstName) == 0)
                        { returnVal = 0; }
                        else
                        {   // Not equal to zero
                            returnVal = -1; 
                        }
                    }
                }
                else
                {   // Not equal to zero
                    returnVal = -1; 
                }
            }
            return returnVal;
        }

        public override string ToString()
        {
            return Customer.LastName + ", " + Customer.FirstName;
        }
    }
}
