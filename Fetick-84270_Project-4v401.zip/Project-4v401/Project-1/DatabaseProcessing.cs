﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 *
 * At the beginning of the following methods:
 *   AddCustomerData, UpdateCustomerData, and ReadListData
 * select a connection between AtHome or AtSchool
 *               conn = GetConnectionAtHome();
 *               //conn = GetConnectionAtSchool();
 */
using System;
using System.IO;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Project_3
{
    public partial class DatabaseProcessing
    {
        // Build an ArrayList to return to Form1
        public static List<ContactDetails> ReadListData()
        {
            List<ContactDetails> itemList = new List<ContactDetails>();

            string connState;
            SqlConnection conn = null;
            SqlDataReader reader = null;
            try
            {
                // Select a connection between AtHome or AtSchool
                conn = GetConnectionAtSchool();
                //conn = GetConnectionAtHome();

                string query = @"SELECT CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, CardType, CardNumber, CardExpire FROM Customer";
                // string query = @"SELECT CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, CardType, CardNumber, CardExpire FROM Customer WHERE LastName = @LastName";

                SqlCommand cmd = new SqlCommand(query, conn);

                //string strInput = "Smith";
                //cmd.Parameters.AddWithValue("@LastName", strInput);

                conn.Open();
                connState = conn.State.ToString();
                if (!connState.Equals("Open"))
                {
                    MessageBox.Show(connState);
                }

                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    itemList.Add(new ContactDetails(
                                         reader["CustId"].ToString(),
                                         reader["FirstName"].ToString(),
                                         reader["LastName"].ToString(),
                                         reader["Address"].ToString(),
                                         reader["City"].ToString(),
                                         reader["State"].ToString(),
                                         reader["Zip"].ToString(),
                                         reader["Phone"].ToString(),
                                         reader["Email"].ToString(),
                                         reader["CardType"].ToString(),
                                         reader["CardNumber"].ToString(),
                                         reader["CardExpire"].ToString()));
                    itemList.Sort();

                    //Test: MessageBox.Show(reader[1] + ":" + reader[0] + ":" + reader[2]);
                    //reader.Close();
                    //RetrieveIdentity(conn);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
            return itemList;
        }

        public static SqlConnection GetConnectionAtHome()
        {
            //  Create... Connection
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            /* TO CONNECT AT HOME - LOCALHOST
             */
            builder.DataSource = @"(localdb)\Projects";
            builder.InitialCatalog = "db84270";
            builder.IntegratedSecurity = true;
            builder.ConnectTimeout = 30;
            builder.Encrypt = false;
            builder.TrustServerCertificate = false;
            //
            return new SqlConnection(builder.ConnectionString);
        }

        public static SqlConnection GetConnectionAtSchool()
        {
            //  Create... Connection
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();

            /* TO CONNECT AT SCHOOL - COLEMAN UNIVERSITY
             */
            builder.DataSource = "mssql-2-34";
            builder.UserID = "db84270";
            builder.InitialCatalog = "db84270";
            builder.Password = "5a0c1de0";
            //
            return new SqlConnection(builder.ConnectionString);
        }

        public static void AddCustomerData(ContactDetails customer)
        {

            SqlConnection conn = null;
            SqlDataAdapter adapter = null;
            try
            {
                // Select a connection between AtHome or AtSchool
                conn = GetConnectionAtSchool();
                //conn = GetConnectionAtHome();

                //string connState;
                //   SqlDataReader reader = null;

                // Create a SqlDataAdapter based on a SELECT query.
                adapter =
                    new SqlDataAdapter(
                    @"SELECT CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, CardType, CardNumber, CardExpire FROM Customer",
                    conn);

                /*
                //For test - Created the Insert Sql statement with literal data
                string insertSQLstmt = @"INSERT INTO Customer "
                                     + "(CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, "
                                     + "CardType, CardNumber, CardExpire) "
                                     + "VALUES "
                                     + "(NEWID(), "
                                     + "'Fetick', "
                                     + "'Mike', "
                                     + "'2181 Rebecca Way', "
                                     + "'Lemon Grove', "
                                     + "'CA', "
                                     + "'91945', "
                                     + "'619-750-7317', "
                                     + "'mikefetick@yahoo.com', "
                                     + "'Visa', "
                                     + "'1234567890123456', "
                                     + "'04/14')";
                 */

                //For Production - Create the Insert Sql statement to add a customer record
                string insertSQLstmt = @"INSERT INTO Customer "
                                     + "(CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, "
                                     + "CardType, CardNumber, CardExpire) "
                                     + "VALUES "
                                     + "(NEWID(), "
                                     + "'" + customer.LastName + "', "
                                     + "'" + customer.FirstName + "', "
                                     + "'" + customer.Address + "', "
                                     + "'" + customer.City + "', "
                                     + "'" + customer.State + "', "
                                     + "'" + customer.ZipCode + "', "
                                     + "'" + customer.Phone + "', "
                                     + "'" + customer.Email + "', "
                                     + "'" + customer.CardType + "', "
                                     + "'" + customer.CardNumber + "', "
                                     + "'" + customer.CardExpire + "')";
                
                //Create the SqlCommand to execute the Insert Sql statement.
                adapter.InsertCommand = new SqlCommand(insertSQLstmt, conn);
                adapter.InsertCommand.CommandType = CommandType.Text;

                // Add the parameter for the LastName. Specifying the
                // ParameterDirection for an input parameter is not required.
                adapter.InsertCommand.Parameters.Add(
                    new SqlParameter("@LastName", SqlDbType.NVarChar, 15, "LastName"));

                // Add the SqlParameter to retrieve the new identity value.
                // Specify the ParameterDirection as Output.
                SqlParameter parameter =
                    adapter.InsertCommand.Parameters.Add(
                    "@CustId", SqlDbType.UniqueIdentifier, 0, "NEWID()");
                parameter.Direction = ParameterDirection.Output;

                // Create a DataTable and fill it.
                System.Data.DataTable Customer = new DataTable();
                adapter.Fill(Customer);

                // Add a new row. 
                DataRow newRow = Customer.NewRow();
                newRow["LastName"] = "New LastName";
                Customer.Rows.Add(newRow);

                adapter.Update(Customer);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (adapter != null)
                {
                    adapter.Dispose();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        public static void UpdateCustomerData(ContactDetails customer)
        {
            string connState;
            SqlConnection conn = null;
            SqlDataReader reader = null;
            try
            {
                // Select a connection between AtHome or AtSchool
                conn = GetConnectionAtSchool();
                //conn = GetConnectionAtHome();

                string customerRecord = @"UPDATE CustId, LastName, FirstName, Address, City, State, Zip, Phone, Email, CardType, CardNumber, CardExpire FROM Customer WHERE LastName = @LastName";

                SqlCommand cmd = new SqlCommand(customerRecord, conn);

                cmd.Parameters.AddWithValue("@LastName", customerRecord);

                conn.Open();
                connState = conn.State.ToString();
                if (!connState.Equals("Open"))
                {
                    MessageBox.Show(connState);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        private static void RetrieveIdentity(SqlConnection connection)
        {
            // Create a SqlDataAdapter based on a SELECT query.
            SqlDataAdapter adapter =
                new SqlDataAdapter(
                "SELECT CustID, LastName FROM dbo.Customer",
                connection);

            //Create the SqlCommand to execute the stored procedure.
            adapter.InsertCommand = new SqlCommand("dbo.InsertCustomer",
                connection);
            adapter.InsertCommand.CommandType = CommandType.StoredProcedure;

            // Add the parameter for the LastName. Specifying the
            // ParameterDirection for an input parameter is not required.
            adapter.InsertCommand.Parameters.Add(
                new SqlParameter("@LastName", SqlDbType.NVarChar, 15,
                "LastName"));

            // Add the SqlParameter to retrieve the new identity value.
            // Specify the ParameterDirection as Output.
            SqlParameter parameter =
                adapter.InsertCommand.Parameters.Add(
                "@CustId", SqlDbType.Int, 0, "NEWID()");
            parameter.Direction = ParameterDirection.Output;

            // Create a DataTable and fill it.
            System.Data.DataTable Customer = new DataTable();
            adapter.Fill(Customer);

            // Add a new row. 
            DataRow newRow = Customer.NewRow();
            newRow["LastName"] = "New LastName";
            Customer.Rows.Add(newRow);

            adapter.Update(Customer);

            //Console.WriteLine("List All Rows:");
            foreach (DataRow row in Customer.Rows)
            {
                {
                    //Console.WriteLine("{0}: {1}", row[0], row[1]);
                    MessageBox.Show(row[1] + ":" + row[0]);
                }
            }
        }
    }
}
