// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 16, 2014
// Project: Fetick_Project4-Hangman
// File name: Main.cpp
// Other files: Hangman.h and Hangman.cpp 
// Description: This file has the main function that starts the program
//
#include <iomanip>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <fstream> // file stream
#include "Hangman.h"
using std::ifstream; // input file stream

// Helper Functions prototypes
void instructions();

// The main function begins program execution
int main()
{
   // Display the instructions and the menu
   instructions();

   // Menu contains the class object to loop
   Hangman::displayMenu();

   // Program termination
   return 0;

} // end function main

void instructions()
{
   // Welcome the game player
   cout << "\n\n\t\t\t H A N G M A N \n" << endl;
   cout << "\t Overview \n" << endl;
   cout << "\t The player wins the game by guessing the letters of a hidden " << endl;
   cout << "\t secret word, one at a time until the secret word is revealed. " << endl;
   cout << "\t A letter that doesn't reveal, counts as one failed attempt. " << endl;
   cout << "\t More attempts of guessing different letters can win. " << endl;
   cout << "\t But, if the player hasn't guessed the secret word by six " << endl;
   cout << "\t failed attempts, then the game is over and the player loses.\n" << endl;
}
