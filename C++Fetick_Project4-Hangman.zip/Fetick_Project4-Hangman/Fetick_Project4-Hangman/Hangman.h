// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 16, 2014
// Project: Fetick_Project4-Hangman
// File name: Hangman.h
// Other files: Hangman.cpp 
// Description: This header file has prototype functions for the Hangman class.
//
#ifndef HANGMAN_H
#define HANGMAN_H

#include <string>
#include <vector>

using namespace std;

// Hangman class
class Hangman
{
public:
   // constructor will initialize all the variables 
   // except the vector with corresponding null values
   Hangman(); 

   // destructor
   ~Hangman(); 

   // member variables of objects
   int static const MAX_ATTEMPTS_ALLOWED = 6;
   string fileName;

   // member functions

   // The readFromFile() selects a random word from the vector wordlist 
   // which is stored in the variable secretWord.
   void readFromFile();

   // This function keeps track of variables and compares thier values.
	void playGame(); // function to play a game

   // This function inserts the contents of the file into the vector 
   // named wordlist. 
   void enterNewWords();

   // checks if the test string matches with the secretWord or not.
	bool isWin(string&);

   // This function is used to convert characters to uppercase. 
   // It uses the toupper() function from the cctype library. 
	void convertToUpper();

   // The set and get functions of member variables 
   // (These functions are optional)
	void setSecretWord(string);
	string getSecretWord();
	void setFileName(string);
	string getFileName();

   // used to display menu with the following options: 
   // Play, Enter New Words, Quit.
   void static displayMenu();
   
private:
   // member variables of objects

   // used to store all the words read from the file
   vector<string> wordList; 

   // used to store the random secretWord extracted from the vector wordList 
   // which would be the word that the user has to guess
   string secretWord;

}; // end a class with the semicolon delimiter 
#endif //HANGMAN_H
