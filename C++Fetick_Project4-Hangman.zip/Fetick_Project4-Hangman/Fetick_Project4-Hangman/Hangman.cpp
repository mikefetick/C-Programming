// Name: Michael Fetick
// Student number: 84270, Coleman University 
// Course: COM203.2A-1405 C++ Programming (Al-Ajawari) 
// Date: July 16, 2014
// Project: Fetick_Project4-Hangman
// File name: Hangman.cpp
// Other files: Hangman.h 
// Description: This file implemenmts the member functions of the Hangman class.
//
#include <iomanip>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <fstream> // file stream
#include "Hangman.h"
using std::ifstream; // input file stream
using std::ofstream; // output file stream

using namespace std;

// Constructor has-a (composite) relationship to WordList
Hangman::Hangman()
{
}
// destructor
Hangman::~Hangman()
{
   // no comment
} // end destructor

// The readFromFile() selects a random word from the vector wordlist 
// which is stored in the variable secretWord.
void Hangman::readFromFile()
{
	string theSecretWord;
   //fileName = "countries.tpf";

   char choice = 'z';
   do // while ( choice != 'q' && again != 'Q' )
   {
      cout << "\n\t Enter a filename (e.g. countries.tpf) or q=quit: ";
      cin >> fileName;
	   if (fileName != "q" && fileName != "Q")
	   {
         // ifstream constructor opens the file          
	      ifstream inWordsFile(fileName);

	      // ifstream could not open file
	      if (!inWordsFile)
	      {
		      cerr << "\n\t ***** ERROR: FILE COULD NOT BE OPENED *****\n" << endl;
            cout << "\t ";
	         system("pause"); 
            cout << "\n\t ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
	      }
         else
         {
            choice = 'q';
            // Set the fileName to get later for the Menu - Category
            setFileName(fileName);

            // Display the fileName as a catagory to help the player guess
            cout << "\n\t Category: " << getFileName() << endl;

            // used to store all the words read from the file
            char aWord[256]; // up to 256 characters in the file
            size_t i = 0;
            while (inWordsFile.good())  // loop while extraction from file is possible
            {
               if (inWordsFile.good())
               {
                  inWordsFile.getline(aWord,256,' ');  // get character from file
               }
               // Build the wordList, one character at a time from the file
               //vector<string> buildList; 
               wordList.push_back(aWord);
               vector<string> buildList (wordList); 
               i++;
            }

	         inWordsFile.close();  // ifstream destructor closes the file
	         //system("pause"); 

            //choose and copy a word from array of words randomly
            srand( (unsigned int) time(NULL));
            unsigned int n=rand()% 10;
            theSecretWord=wordList[n];

            setSecretWord(theSecretWord);
         } // end if else
	   }
      else
      {
	      // exit program to quit
		   exit(1);
      } // end if (fileName != "q" && fileName != "Q")

   } while ( choice != 'q' && choice != 'Q' );
     
} // end readFromFile()

// This function keeps track of variables and compares thier values.
void Hangman::playGame()
{
   // The variable (blanks) contains the same number of letters as the variable 
   // (secretWord) with all its letters initially set to underscore (_) characters. 
   // The player guesses a letter in the (secretWord) and if it matches, 
   // the letter is stored in the appropriate location in the (blanks).
   // If there is no match then the variable (attempts) is incremented by one. 
   // This continues until the correct word is guessed (the user wins) 
   // or the maximum number of attempts is reached (the user loses)

   // read file of words into the vector wordList
   Hangman::readFromFile();

   int attempts = 0;
   char guessLetter = ' '; 
   // A local copy for efficiency
   string theSecretword = getSecretWord(); 
   // Initialize the secret word with the _underscore character.
   string blanks(theSecretword.length(),'_');

   // Loop until the guesses are used up
   while ( attempts < MAX_ATTEMPTS_ALLOWED )
   {
      cout << "\n\n\t " << blanks;
      cout << "\n\n\t Guess a letter: ";
      cin >> guessLetter;
      toupper(guessLetter);

      // Take a one character guess and the secret word, and fill in the
      // unfinished blanks. Matches avoid incrementing the failed attempts.
      int matches=0;
      int len=theSecretword.length();
      for (int i = 0; i< len; i++)
      {
         // Did we already match this letter in a previous guess?
         if (guessLetter == blanks[i])
         {
            //return 0;
         }
         else
         {
            // If the guess is correct (letter exists in secretWord) then
            if (guessLetter == theSecretword[i])
            {
               // fill the blank(s) and the gameboard with the letter; 
               blanks[i] = guessLetter;
               matches++;
            }
         }
      }

      // If the guess is correct (letter exists in secretWord) then
      if (matches != 0)
      {
         cout << endl << "\t You found a letter! Isn't that exciting!" << endl;
      }
      else
      {
         // otherwise increment the number of wrong guesses (attempts).
         cout << endl << "\t Whoops! That letter isn't in there!" << endl;
         attempts++;
      }
      // Tell user how many guesses has left.
      cout << "\t You have " << MAX_ATTEMPTS_ALLOWED - attempts;
      cout << " guesses left." << endl;

      // Check if user guessed the word.
      if (theSecretword == blanks)
      {
         cout << "\n\t " << theSecretword << endl;
         cout << "\n\t Yeah! You got it!";
         cout << "\n\t ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
         break;
      }
   }
   if(attempts == MAX_ATTEMPTS_ALLOWED)
   {
      cout << "\n\t Sorry, you lose...you've been hanged." << endl;
      cout << "\n\t The word was : " << theSecretword << endl;
      cout << "\n\t ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
   }
   cin.ignore();
   cin.get();
}

void Hangman::enterNewWords() // This code snippet is for console user-input
{
   //string fileName;
   cout << "\n\n\t Enter a filename (e.g. animals.txt): ";
   cin >> fileName;

   // ofstream constructor opens file                
   ofstream outDataFile( fileName, ios::app);
   system("pause"); 

   // exit program if unable to create file
   if ( !outDataFile ) // overloaded ! operator
   {
	   cerr << "\n\t ERROR: FILE COULD NOT BE OPENED" << endl;
      cout << "\t ";
	   system("pause"); 
	   exit( 1 ); //indicates that there were errors while exiting
   } // end if

   cout << "\n\t Enter new words:" << endl
        << "\t Enter end-of-file (ctrl z) to end input.\n? ";
 
   // read new words from cin, then place into the vector named wordlist
   string aWord;
   while ( cin >> aWord )
   {
      //Saves the following info to the file separated by spaces
      outDataFile << aWord << ' ';
      cout << "? ";
   } // end while
}

// checks if the test string matches with the secretWord or not.
bool Hangman::isWin(string &testString)
{
   return false;
}
// This function is used to convert characters to uppercase. 
// It uses the toupper() function from the cctype library. 
void Hangman::convertToUpper()
{
   char letter;
   string theSecretword = getSecretWord(); 
   int len=theSecretword.length();
   for (int i = 0; i< len; i++)
   {
      letter = theSecretword[i];
      toupper(letter);
      theSecretword[i] = letter;
   }
   Hangman::setSecretWord(theSecretword);
}

void Hangman::setSecretWord(string aWord)
{
   // used to store a random word extracted from the vector wordList 
   // which would be the word that the user has to guess (optional)
   secretWord = aWord;
}

string Hangman::getSecretWord()
{
   // used to retrieve the word that the user has to guess (optional)
   return secretWord;
}

void Hangman::setFileName(string aWord)
{
   // used to store the fileName
   fileName = aWord;
}

string Hangman::getFileName()
{
   // used to retrieve the fileName
   return fileName;
}

// The game loop. Used to display menu with the following options: 
// Play, Enter New Words, Quit.
void Hangman::displayMenu() 
{
   // Create a character variable called 'again' and initialize it to 'y'
   char choice = 'z';
   do // while ( choice != 'q' && again != 'Q' )
   {
      // Create a game object
      Hangman game;
      // The default constructor will read data from a file, store it in 
      // a vector, and nested functions will randomly set a secretWord.

      cout << "\n\t You have to type only one letter." << endl;
      cout << "\n\t You have " << MAX_ATTEMPTS_ALLOWED 
           << " tries to guess the word and win!" << endl;
      cout << "\n\t ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;

      // [Use a sentinel controlled loop around this to prompt the player 
      // and check if he wants to play again to stay in the game. 
      cout << "\n\t Choose to P-Play, enter N-New words, Q-Quit (P,N,Q)? ";
      cin >> choice;

      // Menu choice is the controlling expression for multiple selections 
      // of actions
      switch ( choice )
      {
         case 'p': // Play
         case 'P': // Play
            // play the game
            game.playGame();
            break;
         case 'n': // New words
         case 'N': // New words
            // play the game
            game.enterNewWords();
            break;
         case 'q': // Quit
         case 'Q': // Quit
            break;
         //case default: // Default
      } // end switch ( getIsWin() )

      // You exit the game when the user chooses 'no']
   } while ( choice != 'q' && choice != 'Q' );
}