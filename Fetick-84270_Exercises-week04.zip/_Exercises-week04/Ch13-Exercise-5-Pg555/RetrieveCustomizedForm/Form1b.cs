﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Four - Chapter Thirteen, Exercise 5b (Page 555)
 * Date: 01 February 2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;  // Serialization
using System.Runtime.Serialization;   // Serialization

namespace RetrieveCustomizedForm
{
    // Exercise 5:
    // 5.a. In the project called CustomizeAForm:
    //      The form settings are serialized by a BinaryFormatter
    //      and a FileStream writes out to a file.
    // 5.b. This project is called RetrieveCustomizedForm:
    //      A FileStream reads in from the same file 
    //      and the stream is deserialized by a BinaryFormatter
    //      for the data to assign the form settings.
    // Serialization - Converting objects into streams of bytes.
    [Serializable]
    public partial class Form1b : Form
    {
        public Form1b()
        {
            InitializeComponent();
        }

        private void rbnColor1_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnColor1.Checked)
            {
                this.BackColor = Color.LightBlue;
                this.groupBox1.BackColor = Color.LightBlue;
            }
        }

        private void rbnColor2_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnColor2.Checked)
            {
                this.BackColor = Color.Red;
                this.groupBox1.BackColor = Color.Red;
            }
        }

        private void rbnColor3_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnColor3.Checked)
            {
                this.BackColor = Color.LightYellow;
                this.groupBox1.BackColor = Color.LightYellow;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            // Can make the groupBox1 Title change..
            groupBox1.Text = textBox1.Text;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Can make the groupBox1 Title change..
            groupBox1.Text = textBox1.Text;
            // Cannot make the Form1b Title change..(no errors)
            Form1b form1b = new Form1b();
            form1b.Text = textBox1.Text;
        }

        private void rbnSize1_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnSize1.Checked)
            {
                this.SetBounds(100, 100, 300, 300);
            }
        }

        private void rbnSize2_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnSize2.Checked)
            {
                this.SetBounds(100, 100, 400, 400);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            const string FILENAME = @"..\\..\\..\\formsettings.dat";
            string[] settings = new string[4];
            try
            {
                if (File.Exists(FILENAME))
                // Store the object(s)
                // - Here is only one object, so there is no need for looping
                settings[0] = (this.BackColor.ToArgb()).ToString();
                settings[1] = this.Size.Height.ToString();
                settings[2] = this.Size.Width.ToString();
                settings[3] = this.groupBox1.Text;

                // Serialization - Converting objects into streams of bytes.
                // See Fig 13-19, page 534
                FileStream outFile = new FileStream(FILENAME,
                                                    FileMode.Create, 
                                                    FileAccess.Write);
                BinaryFormatter bFormatter = new BinaryFormatter();
                bFormatter.Serialize(outFile, settings);
                outFile.Close();
                button1.Enabled = false;
                button2.Enabled = true;
            }
            catch (Exception)
            {
                MessageBox.Show("File does not exist: " + FILENAME);
            }
            finally
            {
                //
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            const string FILENAME = @"..\\..\\..\\formsettings.dat";
            string[] settings = new string[4];

            try
            {
                if (File.Exists(FILENAME))
                {
                    // Deserialization - Converting streams of bytes into objects 
                    // See Fig 13-19, page 534
                    FileStream inFile = new FileStream(FILENAME,
                                                        FileMode.Open,
                                                        FileAccess.Read);
                    BinaryFormatter bFormatter = new BinaryFormatter();

                    // Read each line of the file
                    // - Here is only one object, so there is no need for looping
                    // -  but it has to know when the end of the stream occurs
                    while (inFile.Position < inFile.Length)
                    {
                        settings = (string[])bFormatter.Deserialize(inFile);
                    }
                    inFile.Close();

                    /*
                    // Test stub
                    MessageBox.Show("this.BackColor = (Color)TypeDescriptor\n"
                                  + ".GetConverter(typeof(Color)).ConvertFromString("
                                  + settings[0] + ");\n"
                                  + "this.Size = (Size) new Size("
                                  + settings[1] + "," + settings[2] + ");\n"
                                  + "this.groupBox1.Text = " + settings[3] + ";\n",
                                    "Retrieve Form Settings");
                    */
            
                    // Retrieve the object(s) and set the properties
                    // .. BackColor
                    this.BackColor = (Color)TypeDescriptor.GetConverter(typeof(Color))
                                    .ConvertFromString(settings[0]);
                    this.groupBox1.BackColor = this.BackColor;

                    int formHeight;
                    int formWidth;

                    // .. Form Size
                    formHeight = Convert.ToInt32(settings[1].ToString());
                    formWidth = Convert.ToInt32(settings[2].ToString());
                    this.Size = (Size) new Size(formHeight, formWidth);

                    // .. Groupbox Text
                    //   Can make the groupBox1 Title change..
                    //   but cannot make the Form1b Title change..(errors) Form1b.
                    this.groupBox1.Text = settings[3];

                    // Set the control settings for form size retrieved
                    if (formHeight == 300)
                    { rbnSize1.Checked = true; }
                    else if (formHeight == 400)
                    { rbnSize2.Checked = true; }
                    // Set the control settings for BackColor retrieved
                    if (BackColor == Color.LightBlue)
                    { rbnColor1.Checked = true; }
                    else if (BackColor == Color.Red)
                    { rbnColor2.Checked = true; }
                    else if (BackColor == Color.LightYellow)
                    { rbnColor3.Checked = true; }
                    // Set the control settings for buttons pressed
                    button2.Enabled = false;
                    button1.Enabled = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("File does not exist: " + FILENAME);
            }
            finally
            {
                //
            }
        }
    }
}
