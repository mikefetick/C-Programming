﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Four - Chapter Thirteen, Exercise 5 (Page 555)
 * Date: 01 February 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace RetrieveCustomizedForm
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1b());
        }
    }
}
