﻿namespace RetrieveCustomizedForm
{
    partial class Form1b
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.gbxSize = new System.Windows.Forms.GroupBox();
            this.rbnSize2 = new System.Windows.Forms.RadioButton();
            this.rbnSize1 = new System.Windows.Forms.RadioButton();
            this.gbxColor = new System.Windows.Forms.GroupBox();
            this.rbnColor3 = new System.Windows.Forms.RadioButton();
            this.rbnColor2 = new System.Windows.Forms.RadioButton();
            this.rbnColor1 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.gbxSize.SuspendLayout();
            this.gbxColor.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.gbxSize);
            this.groupBox1.Controls.Add(this.gbxColor);
            this.groupBox1.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 11);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(260, 238);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select form options";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(36, 209);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(180, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Retrieve form settings";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(50, 182);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Save form settings";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 14);
            this.label1.TabIndex = 3;
            this.label1.Text = "Groupbox:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(72, 156);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(154, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "My favorite form";
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // gbxSize
            // 
            this.gbxSize.Controls.Add(this.rbnSize2);
            this.gbxSize.Controls.Add(this.rbnSize1);
            this.gbxSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxSize.Location = new System.Drawing.Point(136, 34);
            this.gbxSize.Name = "gbxSize";
            this.gbxSize.Size = new System.Drawing.Size(90, 70);
            this.gbxSize.TabIndex = 1;
            this.gbxSize.TabStop = false;
            this.gbxSize.Text = "Size";
            // 
            // rbnSize2
            // 
            this.rbnSize2.AutoSize = true;
            this.rbnSize2.Location = new System.Drawing.Point(17, 42);
            this.rbnSize2.Name = "rbnSize2";
            this.rbnSize2.Size = new System.Drawing.Size(52, 17);
            this.rbnSize2.TabIndex = 4;
            this.rbnSize2.Text = "Large";
            this.rbnSize2.UseVisualStyleBackColor = true;
            this.rbnSize2.CheckedChanged += new System.EventHandler(this.rbnSize2_CheckedChanged);
            // 
            // rbnSize1
            // 
            this.rbnSize1.AutoSize = true;
            this.rbnSize1.Checked = true;
            this.rbnSize1.Location = new System.Drawing.Point(17, 19);
            this.rbnSize1.Name = "rbnSize1";
            this.rbnSize1.Size = new System.Drawing.Size(50, 17);
            this.rbnSize1.TabIndex = 3;
            this.rbnSize1.TabStop = true;
            this.rbnSize1.Text = "Small";
            this.rbnSize1.UseVisualStyleBackColor = true;
            this.rbnSize1.CheckedChanged += new System.EventHandler(this.rbnSize1_CheckedChanged);
            // 
            // gbxColor
            // 
            this.gbxColor.Controls.Add(this.rbnColor3);
            this.gbxColor.Controls.Add(this.rbnColor2);
            this.gbxColor.Controls.Add(this.rbnColor1);
            this.gbxColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxColor.Location = new System.Drawing.Point(20, 34);
            this.gbxColor.Name = "gbxColor";
            this.gbxColor.Size = new System.Drawing.Size(90, 100);
            this.gbxColor.TabIndex = 0;
            this.gbxColor.TabStop = false;
            this.gbxColor.Text = "Color";
            // 
            // rbnColor3
            // 
            this.rbnColor3.AutoSize = true;
            this.rbnColor3.Location = new System.Drawing.Point(17, 65);
            this.rbnColor3.Name = "rbnColor3";
            this.rbnColor3.Size = new System.Drawing.Size(56, 17);
            this.rbnColor3.TabIndex = 2;
            this.rbnColor3.TabStop = true;
            this.rbnColor3.Text = "Yellow";
            this.rbnColor3.UseVisualStyleBackColor = true;
            this.rbnColor3.CheckedChanged += new System.EventHandler(this.rbnColor3_CheckedChanged);
            // 
            // rbnColor2
            // 
            this.rbnColor2.AutoSize = true;
            this.rbnColor2.Location = new System.Drawing.Point(17, 42);
            this.rbnColor2.Name = "rbnColor2";
            this.rbnColor2.Size = new System.Drawing.Size(45, 17);
            this.rbnColor2.TabIndex = 1;
            this.rbnColor2.TabStop = true;
            this.rbnColor2.Text = "Red";
            this.rbnColor2.UseVisualStyleBackColor = true;
            this.rbnColor2.CheckedChanged += new System.EventHandler(this.rbnColor2_CheckedChanged);
            // 
            // rbnColor1
            // 
            this.rbnColor1.AutoSize = true;
            this.rbnColor1.Checked = true;
            this.rbnColor1.Location = new System.Drawing.Point(17, 19);
            this.rbnColor1.Name = "rbnColor1";
            this.rbnColor1.Size = new System.Drawing.Size(46, 17);
            this.rbnColor1.TabIndex = 0;
            this.rbnColor1.TabStop = true;
            this.rbnColor1.Text = "Blue";
            this.rbnColor1.UseVisualStyleBackColor = true;
            this.rbnColor1.CheckedChanged += new System.EventHandler(this.rbnColor1_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 14);
            this.label2.TabIndex = 6;
            this.label2.Text = "Title:";
            // 
            // Form1b
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(600, 600);
            this.MinimizeBox = false;
            this.Name = "Form1b";
            this.Text = "My favorite form";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbxSize.ResumeLayout(false);
            this.gbxSize.PerformLayout();
            this.gbxColor.ResumeLayout(false);
            this.gbxColor.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox gbxSize;
        private System.Windows.Forms.GroupBox gbxColor;
        private System.Windows.Forms.RadioButton rbnColor3;
        private System.Windows.Forms.RadioButton rbnColor2;
        private System.Windows.Forms.RadioButton rbnColor1;
        private System.Windows.Forms.RadioButton rbnSize2;
        private System.Windows.Forms.RadioButton rbnSize1;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
    }
}

