﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Four - Chapter Eleven, Exercise 8 (Page 471)
 * Date: 01 February 2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace carDealer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void rbnCarModel01_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnCarModel01.Checked)
            {
                Form2 form2 = new Form2();
                form2.groupBox1.Text = rbnCarModel01.Text + " - Options";
                form2.ShowDialog();
                rbnCarModel01.Checked = false;
                rbnCarModelDummy.Checked = true;
            }
        }

        private void rbnCarModel02_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnCarModel02.Checked)
            {
                Form2 form3 = new Form2();
                form3.groupBox1.Text = rbnCarModel02.Text + " - Options";
                form3.ShowDialog();
                rbnCarModel02.Checked = false;
                rbnCarModelDummy.Checked = true;
            }
        }

        private void rbnCarModel03_CheckedChanged(object sender, EventArgs e)
        {
            if (rbnCarModel03.Checked)
            {
                Form2 form4 = new Form2();
                form4.groupBox1.Text = rbnCarModel03.Text + " - Options";
                form4.ShowDialog();
                rbnCarModel03.Checked = false;
                rbnCarModelDummy.Checked = true;
            }
        }
    }
}
