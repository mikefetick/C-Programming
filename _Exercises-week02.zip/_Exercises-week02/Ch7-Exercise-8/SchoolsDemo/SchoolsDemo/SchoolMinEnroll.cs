﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Two - Chapter Seven, Exercise 8 (Page 267)
 * Date: 18 January 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// Exercise 8a. Named the file: SchoolsDemo.cs
// Exercise 8b. Modified and renamed the file: SchoolMinEnroll.cs
//        Note: Tried to create both files and had to eliminate
//              conflicts (in the namespace) but things didn't import
// Everything works fine here...

// The schema to group classes of a SchoolsDemo
namespace SchoolsDemo
{
    // Exercise 8a. Created class School with fields and properties
    class School : IComparable
    {
        // Declare instance variables, aka attributes, aka fields
        //  no constructor initializers at this time
        private string schoolName;
        public string SchoolName
        {
            get { return schoolName; }
            set { schoolName = value; }
        }
        private int numberOfStudents;
        public int NumberOfStudents
        {
            get { return numberOfStudents; }
            set { numberOfStudents = value; }
        }

        private static string inputString;  // for console input
        private static int minEnroll;
        private static int schoolCount;
        private const int LOOPS = 5;  // loop to access (five) objects
        bool validInput = false;          // reassure default

        public void setSchoolName(string name)
        {
            schoolName = name;
        }

        // Declare an array of multiple objects of school
        School[] schoolArray = new School[LOOPS];

        public void WelcomeMessage()
        {
            // Use console defaults System, standard out, standard in
            //  to display the program to the user at the console
            Console.WriteLine("\n  School Demonstration\n");
            Console.WriteLine("  Enter ({0}) schools", LOOPS);

            // Prompt user to enter multiple school objects
            for (int i=0; i < schoolArray.Length; ++i)
            {
                // Instatiate the objects at an array index
                schoolArray[i] = new School();

                // 1st Prompt user for school's name
                Console.Write("    #{0} School's name: ", i + 1);
                inputString = Console.ReadLine();
                schoolArray[i].SchoolName = inputString;

                // Check for negative numbers
                //   Do-while not validInput
                do
                {
                    // 2nd Prompt user for school's NumberOfStudents
                    Console.Write("      number of students: ");
                    inputString = Console.ReadLine();
                    //   and convert type string input to integer value for computation
                    schoolCount = Convert.ToInt32(inputString);

                    if (schoolCount < 0)
                    {
                        Console.WriteLine("        (Enter a value >= zero)");
                        validInput = false;
                    }
                    else
                    {
                        schoolArray[i].NumberOfStudents = schoolCount;
                        validInput = true;
                    }
                } while (!validInput);
            }
        }

        public void WriteSchoolData()
        {
            // Typical for the elements in this array of objects
            Console.WriteLine("\n  School Attributes\n");
            for (int i = 0; i < schoolArray.Length; ++i)
            {
                Array.Sort(schoolArray);
                Console.WriteLine("    #{0} School's name: {1}", (i + 1), 
                    schoolArray[i].SchoolName);
                Console.WriteLine("      number of students: {0}", 
                    schoolArray[i].NumberOfStudents);
            }
        }

        // Exercise 8b. Prompt the user to enter a Minimum Enrollment Figure
        protected void GetMinEnroll()
        {
            Console.WriteLine("\n  Minimum Enrollment Figure\n");

            // Check for negative numbers
            //   Do-while not validInput
            validInput = false;
            do
            {
                Console.Write("    Enter the amount of students: ");
                inputString = Console.ReadLine();

                //  and convert type string input to integer value for computation
                minEnroll = Convert.ToInt16(inputString);
                if (minEnroll < 0)
                {
                    Console.WriteLine("         (Enter a value >= zero)");
                    validInput = false;
                }
                else
                {
                    for (int i = 0; i < schoolArray.Length; ++i)
                    {
                        if (schoolArray[i].NumberOfStudents >= minEnroll)
                        {
                            Console.WriteLine("    #{0} School's name: {1}", (i + 1), 
                                schoolArray[i].SchoolName);
                            Console.WriteLine("      number of students: {0}", 
                                schoolArray[i].NumberOfStudents);
                        }
                    }
                    validInput = true;
                }
            } while (!validInput);
        }

        public void GoodbyeMessage()
        {
            // Prompt the user to quit the program and close the window shell
            Console.Write("\n  Thank you. Press any key to quit...");
            Console.ReadKey();
            Console.WriteLine(""); // A clean exit.
        }

        // Implement the IComparable interface 
        //   to override the CompareTo method
        //   with a comparison of the NumberOfStudents property
        int IComparable.CompareTo(object obj)
        {
            int returnVal;
            School temp = (School) obj;

            if (this.NumberOfStudents > temp.NumberOfStudents)
            { returnVal = 1; }
            else
            { if (this.NumberOfStudents < temp.NumberOfStudents)
                { returnVal = -1; }
                else
                { returnVal = 0; }
            }
            return returnVal;
        }

        // The main method is a program for the user to instantiate objects 
        //  of the class School, with it's fields and properties
        static void Main(string[] args)
        {
            // Error handling will catch thrown exceptions caused by 
            //   user input of an improper data type...
            // Try-Catch block for any FormatException
            try
            {
                // Instantiate an object of school
                School thisSchool = new School();

                thisSchool.WelcomeMessage();
                thisSchool.WriteSchoolData();
                thisSchool.GetMinEnroll();
            }
            catch (FormatException fe)
            {
                // A user-friendly error message and instructions to assist.
                Console.WriteLine(
                  "\n  [ERROR] An invalid entry was entered... "
                + "\n          Please RESTART the program and try again.");
            }
            finally
            {
                // Prompt the user to quit the program and close the window shell
                Console.Write("\n  Thank you. Press any key to quit...");
                Console.ReadKey();
                Console.WriteLine(""); // A clean exit.
            }
        }

    } // Class School
} // namespace SchoolsDemo
