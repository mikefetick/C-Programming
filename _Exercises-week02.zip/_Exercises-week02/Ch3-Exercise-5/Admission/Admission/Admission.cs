﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Two - Chapter Three, Exercise 5 (Page 111)
 * Date: 17 January 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// The schema to group classes of an Admission
namespace Admission
{
    // A program for the College's Admission Office
    class Admission
    {
        static void Main(string[] args)
        {
            // Declare identifiers of type decimal versus type double 
            //  for precision and size constraints but use an 'M' suffix 
            //  to create the literal of type decimal from the explicited 
            //  converted type System.Double

            // Declare CONSTANTS for admission criteria
            const decimal CRITERIA_GPA = 3.0m;
            const decimal CRITERIA_LOW_GPA_HIGH_TESTSCORE = 80.0m;
            const decimal CRITERIA_HIGH_GPA_LOW_TESTSCORE = 60.0m;

            // Declare a string for console input,
            string inputString;

            //  declare decimals for High School CRITERIA_GPA and Admission Test Score,
            decimal studentGPA, studentTestScore;

            //  and declare a Boolean for Admission Acceptance and validInput
            bool admissionAccepted = false;   // reassure default
            bool validInput = false;          // reassure default

            // Use console defaults System, standard out, standard in
            //  to display the program to the user at the console
            Console.WriteLine("\n  College Admission Requirements\n");
            Console.WriteLine("    The student's college admission is accepted...");
            Console.Write    ("      if the student's HS GPA >= 3.0");
            Console.WriteLine(" and Admission Test Score >= 60");
            Console.Write    ("      or the student's HS GPA  < 3.0");
            Console.WriteLine(" and Admission Test Score >= 80\n");

            // Error handling will catch thrown exceptions caused by 
            //   user input of an improper data type...
            // Try-Catch block for any FormatException
            try
            {
                // Check for negative numbers
                //   Do-while not validInput
                do
                {
                    // 1st Prompt user for student's admission qualification
                    Console.Write("    Enter student's High School GPA (e.g. 3.2): ");
                    inputString = Console.ReadLine();

                    //  and convert string input to decimal value for computation
                    studentGPA = Convert.ToDecimal(inputString);

                    if ((studentGPA > 4) || (studentGPA < 0))
                    {
                        Console.WriteLine("           (Enter a value, ranged between 0-4)");
                        validInput = false;
                    }
                    else
                    {
                        validInput = true;
                    }
                } while (!validInput);

                // Check for negative numbers
                //   Do-while not validInput
                do
                {
                    // 2nd Prompt user for student's admission qualification 
                    Console.Write("    Enter student's Admission Test Score (e.g. 80): ");
                    inputString = Console.ReadLine();

                    //  and convert type string input to decimal value for computation
                    studentTestScore = Convert.ToDecimal(inputString);

                    if ((studentTestScore > 100) || (studentTestScore < 0))
                    {
                        Console.WriteLine("             (Enter a value, ranged between 0-100)");
                        validInput = false;
                    }
                    else
                    {
                        validInput = true;
                    }
                } while (!validInput);

                // Determine college admission acceptance 
                //  by comparing student qualifications to admission criteria
                if (studentGPA >= CRITERIA_GPA)
                {
                    if (studentTestScore >= CRITERIA_HIGH_GPA_LOW_TESTSCORE)
                    {
                        admissionAccepted = true;
                    }
                    else
                    {
                        admissionAccepted = false;
                    }
                } else if (studentTestScore >= CRITERIA_LOW_GPA_HIGH_TESTSCORE)
                    {
                        admissionAccepted = true;
                    }
                    else
                    {
                        admissionAccepted = false;
                    }

                // Display determination of college admission acceptance 
                Console.WriteLine("");
                if (admissionAccepted)
                {
                    Console.WriteLine("    Accept");
                }
                else
                {
                    Console.WriteLine("    Reject");
                }
            }
            catch (FormatException fe)
            {
                // A user-friendly error message and instructions to assist.
                Console.WriteLine(
                  "\n  [ERROR] An invalid entry was entered... "
                + "\n          Please RESTART the program and try again.");
            }
            finally
            {
                // Prompt the user to quit the program and close the window shell
                Console.Write("\n  Thank you. Press any key to quit...");
                Console.ReadKey();
                Console.WriteLine(""); // A clean exit.
            }

        } // Main
    } // Class Progam
} // namespace Admission
