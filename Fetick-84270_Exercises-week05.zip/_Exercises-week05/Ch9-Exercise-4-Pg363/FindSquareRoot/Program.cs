﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Five - Chapter Nine, Exercise 4 (Page 363)
 * Date: 9 February 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FindSquareRoot
{
    class Program
    {
        static void Main(string[] args)
        {
            double number;
            double sqrt;

            try
            {
                Console.Write("\n  Enter a number: ");
                number = Convert.ToDouble(Console.ReadLine());

                if (number < 0) throw new ApplicationException();
                sqrt = Math.Sqrt(number);
                Console.WriteLine("\n  The square root value of "
                                     + number + " is " + sqrt);
            }
            catch (FormatException fe)
            {
                Console.WriteLine("\n  The input should be a number. ");
                sqrt = 0;
            }
            catch (ApplicationException ae)
            {
                Console.WriteLine("\n  The number can't be negative. ");
                sqrt = 0;
            }
            finally
            {
                // Prompt the user to quit the program and close the window shell
                Console.Write("\n  Thank you. Press any key to quit...");
                Console.ReadKey();
                Console.WriteLine(""); // A clean exit.
            }
        }
    }
}
