﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System;
using System.IO;
using System.Collections;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArkhamBooks
{
    public partial class ListProcessing
    {
        // Build an ArrayList to return to Form1
        public static List<BookDetails> ReadListData()
        {
            // Pg528. Reading from a sequential access text file
            // declare a delimiter, an input text file, and some arrays
            const char DELIM = ',';
            const string FILENAME = "Clean_BookTitles.txt";
            string[] lines;
            string[] fields;
            string errorMsg;

            List<BookDetails> itemList = new List<BookDetails>();

            //  Before creating the FileStream object check if file exists 
            if (File.Exists(FILENAME))
            {
                try
                {
                    // Use the File.ReadAllLines method to read all lines. It
                    //  creates a FileStream object, associates with a StreamWriter
                    //  and closes the file. 
                    // Assign the stream value to the variable: lines 
                    //  which represents all the books (each line = a book)
                    lines = File.ReadAllLines(FILENAME);
                    string line = null;

                    // Pg146. Using a for loop to search the array for each book
                    //   int limits to +/-2,147,483,647 lines
                    for (int i = 0; i < lines.Length; ++i)
                    {
                        // Use the Split method to parse the string into fields
                        line = lines[i];
                        fields = line.Split(DELIM);
                        Console.WriteLine(fields);

                        // Instantiate a book object and assign the fields
                        // in each line of data to the attributes of a book
                        BookDetails book = new BookDetails(fields[0], 
                                             fields[1], 
                                             fields[2], 
                                             Convert.ToDecimal(fields[3]));
                        
                        // Add the book to the ArrayList of books
                        itemList.Add(book);
                        itemList.Sort();
                    }
                }
                catch (Exception)
                {
                    errorMsg = "There is an error with the data file Clean_BookTitles.txt";
                    Console.WriteLine(errorMsg);
                }
                finally 
                {
                    //  the File.ReadAllLines method also, closed the file.
                }
            }
            else
            {
                errorMsg = "The data file Clean_BookTitles.txt does not exist.";
                Console.WriteLine(errorMsg);
            }

            return itemList;
        }
    }
}
