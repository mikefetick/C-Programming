﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_1
{
    public abstract class Book : IComparable<Book>
    {
        public abstract int CompareTo(Book otherBook);
    }

    public class BookItem : Book
    {
        protected string isbn;
        public string ISBN
        {
            get { return isbn; }
            set { isbn = value; }
        }
        private string title;
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        private string author;
        public string Author
        {
            get { return author; }
            set { author = value; }
        }
        private decimal price;
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }
    }
    
    public class BookData
    {
        // The static member is thread safe
        public static void ReadBookData()
        {
            // Pg528. Reading from a sequential access text file
            const char DELIM = ',';
            const string fileName = "Clean_BookTitles.txt";
            string[] lines;
            string[] fields;

            ArrayList books = new ArrayList();

            //  Before creating the FileStream object check if file exists 
            if (File.Exists(fileName))
            {
                try
                {
                    // Create the FileStream object, associate with a StreamWriter using
                    //  the File.ReadAllLines method to read all lines and closes the file.
                    // Assign the stream value to the variable: lines 
                    //  which represents all the books (each line = a book)
                    lines = File.ReadAllLines(fileName);
                    string line = null;
                    // Pg146. Using a for loop to search the array, string[] lines
                    //  an unsigned short will limit it to 65,535 lines
                    //  versus an int limited to +/-2,147,483,647 lines
                    //  versus an uint limited to + 4,294,967,295 lines
                    for (int i = 0; i < lines.Length; ++i)
                    {
                        // Instantiate a book object 
                        //  and assign its attributes to the fields of the line of data
                        Book book = new BookItem() as Book;
                        books.Add(book);
                        line = lines[i];
                        fields = line.Split(DELIM);
                        // Problems here seeing the field names
                        books[i].ISBN   = fields[0];
                        books[i].Title  = fields[1];
                        books[i].Author = fields[2];
                        books[i].Price  = fields[3];
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("The data file Clean_BookTitles.txt does not exist.");
                }
                finally { }
            }
            else
            {
                Console.WriteLine("The data file Clean_BookTitles.txt does not exist.");
            }
        }

    }
}
