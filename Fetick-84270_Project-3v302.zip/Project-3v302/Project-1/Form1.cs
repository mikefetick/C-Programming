﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project_3
{
    public partial class frmOrderForm : Form
    {
        private ErrorProvider txtFirstNameEP;
        private ErrorProvider txtLastNameEP;
        private ErrorProvider txtAddressEP;
        private ErrorProvider txtCityEP;
        private ErrorProvider cboStateEP;
        private ErrorProvider txtZipCodeEP;
        private ErrorProvider txtEmailEP;
        private ErrorProvider txtCcNameEP;
        private ErrorProvider txtCcNumberEP;
        private ErrorProvider txtCcCvcEP;
        private decimal cost;

        // Instance variables
        ContactDetails customer;
        BookDetails book;
        OrderDetails order;

        public frmOrderForm()
        {
            InitializeComponent();
        }

        /*
        void fillData()
        {
            // Open connection
            using (SqlConnection c = new SqlConnection(
                Properties.Settings.Default.DataConnectionString))
            {
            }
        }
        */
        private void frmOrderForm_Load(object sender, EventArgs e)
        {
            // Get database records of customers
            cboCustomer.Items.AddRange(DatabaseProcessing.ReadListData().ToArray());
            cboCustomer.SelectedIndex = 0;
            btnConfirmOrder.Enabled = false;
            btnCancelOrder.Enabled = false;
            
            order = new OrderDetails();

            cboTitle.Items.AddRange(ListProcessing.ReadListData().ToArray());
            cboTitle.SelectedIndex = 0;

            // The selected cboTitle is the pivitol property to use
            //   for setting ALL the text boxes' text values
            nudQty.Text = "1";
            book = (BookDetails)cboTitle.SelectedItem;
            //   calculate the cost = qty x price
            cost = 1 * book.Price;
            //   convert and fill textboxes
            txtPrice.Text = "$" + book.Price.ToString();
            txtCost.Text  = "$" + cost.ToString();

            // Create a Header row in the listbox clbBooks
            string headerRow = string.Format("{0,-42}{1,-9}   {2,-9}  ({3}) {4:-c2,15}|",
                                             "Title", "Author", "ISBN", "Quantity", "Price");
            clbBooks.Items.Add(headerRow);
            pboLink.Image = Project_3.Properties.Resources.linkun;
            pboLink.UseWaitCursor = true;
        }

        // Utility method to register the book
        private void RegisterBook()
        {
 	        throw new NotImplementedException();
        }

        private void cboCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            customer = (ContactDetails)cboCustomer.SelectedItem;
            if (cboCustomer.SelectedIndex >= 0)
            {
                grpCustomer.Text = "CUSTOMER: {" + customer.CustId + "}";
                txtFirstName.Text = customer.FirstName;
                txtLastName.Text = customer.LastName;
                txtAddress.Text = customer.Address;
                txtCity.Text = customer.City;
                cboState.Text = customer.State;
                txtZipCode.Text = customer.ZipCode;
                txtPhone.Text = customer.Phone;
                txtEmail.Text = customer.Email;
                cboCreditCard.Text = customer.CardType;
                txtCcNumber.Text = customer.CardNumber;
                nudCcExpMM.Value = Convert.ToDecimal(customer.CardExpire.Substring(0, 2));
                nudCcExpYYYY.Value = Convert.ToDecimal("20" + customer.CardExpire.Substring(3, 2));
            }

            // Disable the controls for editing customer data
            DisableCustomerEditing();
        }

        private void cboTitle_SelectedIndexChanged(object sender, EventArgs e)
        {
            // The _SelectedIndexChanged of cboTitle is the pivitol property to use
            //   for setting ALL the text boxes' text values
            book = (BookDetails)cboTitle.SelectedItem;
            //   convert and fill textboxes
            txtAuthor.Text = book.Author;
            txtISBN.Text = book.Isbn;
            nudQty.Text = "1";
            //   calculate the cost = qty x price
            cost = 1 * book.Price;
            txtPrice.Text = "$" + book.Price.ToString();
            txtCost.Text = "$" + cost.ToString();

            ValidateCustomerData(order);
            // Add the items the customer has put on the order (cart)
            ItemizeOrder(order);
        }

        private void txtFirstName_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtFirstName value is valid
            if (IsFirstNameValid())
            {
                // Clear the error, if any, in the error provider.
                txtFirstNameEP.SetError(this.txtFirstName, String.Empty);
                btnCustomerSave.Enabled = true;

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the FirstName is not valid.
                txtFirstNameEP.SetError(this.txtFirstName, "FirstName is required.");
            }
        }

        private void txtLastName_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtLastName value is valid
            if (IsLastNameValid())
            {
                // Clear the error, if any, in the error provider.
                txtLastNameEP.SetError(this.txtLastName, String.Empty);
                txtCcName.Text = txtFirstName.Text + " " + txtLastName.Text;

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the LastName is not valid.
                txtLastNameEP.SetError(this.txtLastName, "LastName is required.");
            }
        }

        private void txtAddress_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtAddress value is valid
            if (IsAddressValid())
            {
                // Clear the error, if any, in the error provider.
                txtAddressEP.SetError(this.txtAddress, String.Empty);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the Address is not valid.
                txtAddressEP.SetError(this.txtAddress, "Address is required.");
            }
        }

        private void txtCity_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtCity value is valid
            if (IsCityValid())
            {
                // Clear the error, if any, in the error provider.
                txtCityEP.SetError(this.txtCity, String.Empty);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the City is not valid.
                txtCityEP.SetError(this.txtCity, "City is required.");
            }
        }

        private void cboState_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if cboState value is valid
            if (IsStateValid())
            {
                // Clear the error, if any, in the error provider.
                cboStateEP.SetError(this.cboState, String.Empty);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the State is not valid.
                cboStateEP.SetError(this.cboState, "State is required.");
            }
        }

        private void txtZipCode_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtZipCode value is valid
            if (IsZipCodeValid())
            {
                // Clear the error, if any, in the error provider.
                txtZipCodeEP.SetError(this.txtZipCode, String.Empty);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the ZipCode is not the valid format of
                //  (5 digit US ZIP code) or (5 digit US ZIP code + 4)
                txtZipCodeEP.SetError(this.txtZipCode, "Zip Code (or Zip+4) is required\n" +
                                                       "e.g.'92123' or '92123-1506'");
            }
        }

        private void txtEmail_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtEmail value is valid
            if (IsEmailValid())
            {
                // Clear the error, if any, in the error provider.
                txtEmailEP.SetError(this.txtEmail, String.Empty);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the Email is not valid.
                txtEmailEP.SetError(this.txtEmail, "Email should have a valid format\n" +
                                                   "e.g.'someone@example.com'");
            }
        }

        private void nudQty_Validated(object sender, System.EventArgs e)
        {
            // The selected cboTitle is the pivitol property to use
            //   for setting ALL the text boxes' text values
            book = (BookDetails)cboTitle.SelectedItem;

            //   Calculate the item cost and fill textbox txtCost
            cost = nudQty.Value * book.Price;
            txtCost.Text = "$" + cost.ToString();
        }

        private void txtCcName_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtLastName value is valid
            if (IsCcNameValid())
            {
                // Clear the error, if any, in the error provider.
                txtCcNameEP.SetError(this.txtCcName, String.Empty);
                //                ValidateCustomerData(order);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the LastName is not valid.
                txtCcNameEP.SetError(this.txtCcName, "LastName is required.");
            }
        }

        private void txtCcNumber_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtZipCode value is valid
            if (IsCcNumberValid())
            {
                // Clear the error, if any, in the error provider.
                txtCcNumberEP.SetError(this.txtCcNumber, String.Empty);
                //                ValidateCustomerData(order);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the ZipCode is not the valid format of
                //  (5 digit US ZIP code) or (5 digit US ZIP code + 4)
                txtCcNumberEP.SetError(this.txtCcNumber, "Card Card Number is required\n" +
                                                       "e.g.'92123' or '92123-1506'");
            }
        }

        private void txtCcCvc_Validated(object sender, System.EventArgs e)
        {
            // Calls unique method to determine if txtCcCvc value is valid
            if (IsCcCvcValid())
            {
                // Clear the error, if any, in the error provider.
                txtCcCvcEP.SetError(this.txtCcCvc, String.Empty);
                //                ValidateCustomerData(order);

                // Enable controls to add or update customer data
                if (ValidCustomerData())
                {
                    btnCustomerSave.Enabled = true;
                }
                else
                {
                    btnCustomerSave.Enabled = false;
                }
            }
            else
            {
                // Set the error if the CVC is not the valid format of
                //  (3 or 4 digit, Credit Verification Code)
                txtCcCvcEP.SetError(this.txtCcCvc, "Card Card CVC is required\n" +
                                                       "e.g.'123' or '1234'");
            }
        }

        /* Functions to verify data when grpCustomer loses focus */

        // Determines if the textboxes' values are valid (with a short-circuit)
        //  by being (not null) and (greater than a zero-length string).
        //  with exceptions commented.

        private bool IsFirstNameValid()
        {
            return (txtFirstName.Text.Length > 0);
        }

        private bool IsLastNameValid()
        {
            return (txtLastName.Text.Length > 0);
        }

        private bool IsAddressValid()
        {
            return (txtAddress.Text.Length > 0);
        }

        private bool IsCityValid()
        {
            return (txtCity.Text.Length > 0);
        }

        private bool IsStateValid()
        {
            // Determine whether the state is selected (not null)
            //  AND (with a valid value).
            return ((cboState.SelectedItem != null) &&
                (!cboState.SelectedItem.ToString().Equals("None")));
        }

        private bool IsZipCodeValid()
        {
            // Uses Regular Expression "US ZipCode" described at:
            // http://www.regexlib.com/REDetails.aspx?regexp_id=3532

            string reg = @"^\d{5}(-\d{4})?$";

            if (Regex.IsMatch(txtZipCode.Text, reg))
            {
                return true;
            }
            else
            {
                return false;
            } 
        }

        private bool IsEmailValid()
        {
            // This textbox can be left blank but if it is not left blank ...
            //  determine if the value is the proper format
            if (txtEmail.Text != "")
            {
                // Uses my best choice of a Regular Expression for an Email address described at:
                // http://www.regexlib.com/DisplayPatterns.aspx?cattabindex=0&categoryId=1

                string reg = @"^([0-9a-zA-Z]+[-._+&amp;])*[0-9a-zA-Z]+@([-0-9a-zA-Z]+[.])+[a-zA-Z]{2,6}$";

                if (Regex.IsMatch(txtEmail.Text, reg))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }

        }

        private bool IsCcNameValid()
        {
            return (txtCcName.Text.Length > 0);
        }

        private bool IsCcNumberValid()
        {
            // Uses Regular Expression "Credit Card" described at:
            // http://www.regexlib.com/REDetails.aspx?regexp_id=3532

            string reg = @"^\d{5}$";

            if (Regex.IsMatch(txtCcNumber.Text, reg))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool IsCcCvcValid()
        {
            // Uses Regular Expression "Credit Card" described at:
            // http://www.regexlib.com/REDetails.aspx?regexp_id=3532

            string reg4 = @"^\d{4}$";   // Only American Express
            string reg3 = @"^\d{3}$";   // All other credit cards

            if (Regex.IsMatch(txtCcNumber.Text, reg4))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Validate the controls on this groupbox
        private void grpCustomer_Validating(object sender, CancelEventArgs e)
        {
            txtFirstName_Validated(sender, e);
            txtLastName_Validated(sender, e);
            txtAddress_Validated(sender, e);
            txtCity_Validated(sender, e);
            cboState_Validated(sender, e);
            txtZipCode_Validated(sender, e);
            txtEmail_Validated(sender, e);
            txtCcName_Validated(sender, e);
            txtCcNumber_Validated(sender, e);
            txtCcCvc_Validated(sender, e);
        }

        private void grpBook_Enter(object sender, EventArgs e) { }

        private void btnAddTitle_Click(object sender, EventArgs e)
        {
            ItemDetails newItem = new ItemDetails();
            newItem.Title  = book.Title;
            newItem.Author = book.Author;
            newItem.Isbn   = book.Isbn;
            newItem.Price  = book.Price;
            newItem.Qty    = Convert.ToInt32(nudQty.Text);

            //bookOrder.Booklist.Add(newItem);
            order.ItemList.Add(newItem);
            ItemizeOrder(order);

            // This button adds items to the listbox clbBooks
            //   consisting of the properties of the (selected by the Title) Book
            //   with padding


            string str1 = newItem.Title.ToString();
            int str1Length = str1.Length;
            int str1Pad = 50 - str1Length;

            string str2 = newItem.Author.ToString();
            int str2Length = str2.Length;
            int str2Pad = 20 - str2Length;

            string str3 = newItem.Isbn.ToString();
            int str3Length = str3.Length;
            int str3Pad = 32 - str3Length;

            string bookItem = string.Format("{0,8}{1,16} {2,-25}   ({3}) {4:-c2,15}   |",
            //string bookItem = string.Format("{0}{1} {2}   ({3}) {4:-c2,15}   |",
                                            newItem.Title.PadRight(str1Pad, '-'),
                                            newItem.Author.PadRight(str2Pad, '-'),
                                            newItem.Isbn.PadRight(str3Pad, '-'), 
                                            nudQty.Text, 
                                            txtCost.Text.  PadRight(20, '-'));

            // Previously below, the code relied on the form, requiring high coupling and caused low cohesion
                //cboTitle.Text, txtAuthor.Text, txtISBN.Text, txtQty.Text, txtCost.Text);
            // The bookItem has a delimiter symbol "|" at the end; 
            //   to later, separate books from the clbBooks string, into new-lines 
            clbBooks.Items.Add(bookItem);

            // Add the cost to the SubTotal value
            txtSubtotal.Text = string.Format("{0,9:C}", order.Subtotal);

            // Add the shipping fee
            txtShipping.Text = string.Format("{0,11:C}", order.Shipping);

            // Add the taxes
            txtTax.Text = string.Format("{0,10:C}", order.Taxes);

            // Add everything to the total value
            txtTotal.Text = string.Format("{0,9:C}", order.Total);

            // Validate the Cutomer data for the order
            ValidateCustomerData(order);

        }

        private void lblShipping_Click(object sender, EventArgs e) { }

        StringBuilder receipt = null;
        private void btnConfirmOrder_Click(object sender, EventArgs e)
        {
            
            // Create a new object when confirming the order
            //  with initialized subtotal and total
            if (order == null)
            {
                order = new OrderDetails();
            }

            // Display the order to confirm with a Messagebox OK button
            receipt = BuildOrder(receipt);
            if (MessageBox.Show(receipt.ToString() + "\n" + 
                                "Confirm the order...",
                                "Order Confirmation",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Question) == DialogResult.OK)
            {
                // Write the order
                OrderProcessing.WriteOrder(receipt);
                // Clear the order data for the next order
                order = null;
            }
        }

        // Utility method to validate the customer data
        public bool ValidCustomerData()
        {
            // All GUI data entry is required before adding a customer or updating customer data
            if (IsFirstNameValid() 
             && IsLastNameValid()
             && IsAddressValid()
             && IsCityValid() 
             && IsStateValid() 
             && IsZipCodeValid())
            // Phone is optional
            // Email is optional - for our newsletter subscription list
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Utility method to validate the order
        public bool ValidateCustomerData(OrderDetails order)
        {
            bool isValid = false;

            // All GUI data entry is required before building the order
            if (IsFirstNameValid() && IsLastNameValid()
             && IsAddressValid()
             && IsCityValid() && IsStateValid() && IsZipCodeValid()
             && IsEmailValid()
             && (clbBooks.Items.Count > 1))
            // Phone, Email, and Credit Card data are optional
            {
                btnConfirmOrder.Enabled = true;
                btnCancelOrder.Enabled = true;
                isValid = true;
            }
            else 
            {
                btnConfirmOrder.Enabled = false;
                btnCancelOrder.Enabled = false;
                isValid = false; 
            }
            return isValid;
        }
        /* A StringBuilder object appends to one string vs many literal strings;
         * the delimiter "|" is inserted to later parse the lines and items 
         * from the single string which represents one line for each order (record).
         */

        // Instance variable for a StringBuilder
        protected StringBuilder sb;

        // Utility method to create the order
        public StringBuilder BuildOrder(StringBuilder receipt)
        {
            // Add the customer data
            RegisterCustomer(order);

            // Add the items the customer has put on the order (cart)
            ItemizeOrder(order);

            // Display the order details for confirmation and a receipt
            sb = DisplayOrder(order);

            return sb;
        }

        // Utility method to register the Customer in the Contact List
        protected void RegisterCustomer(OrderDetails order)
        {
            // Assign the (GUI) user-input to the properties of the Customer
            order.Customer.FirstName = txtFirstName.Text;
            order.Customer.LastName = txtLastName.Text;
            order.Customer.Address = txtAddress.Text;
            order.Customer.City = txtCity.Text;
            order.Customer.State = cboState.Text;
            order.Customer.ZipCode = txtZipCode.Text;
            order.Customer.Email = txtEmail.Text;

            // Add the Customer to the List of contacts
            List<ContactDetails> contactList = new List<ContactDetails>();
            contactList.Add(order.Customer);
            contactList.Sort();
        }

        // Utility method to Itemize the order for the customer
        protected void ItemizeOrder(OrderDetails order)
        {
            // Initialize all variables
            decimal subtotal = 0;
            order.Subtotal = 0;

            foreach (ItemDetails item in order.ItemList)
            {
                subtotal = item.Price * item.Qty;
                order.Subtotal += subtotal;
            }

            // Total the cost for the order for payment
            order.Total = order.Subtotal
                        + order.Shipping
                        + order.Taxes;
        }

        // Utility method to display the order to the customer
        protected StringBuilder DisplayOrder(OrderDetails order)
        {
            /* 
             * Specified in the Student Handbook on page 20.
             */
            // StringBuilder appends to one string vs many literal strings;
            // delimiter "|" is inserted to parse the lines and items later,
            // from the single line of each order.
            //
            // Start the string with the order date and the customer data
            sb.AppendFormat("Order Date: {0}|{1} {2}|{3}|{4}, {5} {6}|",
                            order.OrderDate,
                            order.Customer.FirstName.ToString(), 
                            order.Customer.LastName.ToString(),
                            order.Customer.Address.ToString(),
                            order.Customer.City.ToString(), 
                            order.Customer.State.ToString(), 
                            order.Customer.ZipCode.ToString()
                            );
            //order.Customer.Email.ToString()
            // Append the list of books ordered
            sb.AppendFormat("{0,-24}\t{1,-5}   {2}  ({3}) {4:-c2,15}|",
                            "Title", "Author", "ISBN", "Quantity", "Price");

            foreach (ItemDetails item in order.ItemList)
            {
                sb.AppendFormat("{0,-24}\t{1,-5}   {2}  ({3}) {4:-c2,15}|",
                            item.Title, item.Author, item.Isbn, item.Qty, item.Price);
            }

            // Append the summary line
            sb.AppendFormat("SubTotal: {0}   Tax: {1}   Shipping: {2}   Total {3} |",
                             order.Subtotal, order.Taxes, order.Shipping, order.Total);

            // Append the final line to separate orders
            sb.AppendFormat("-----------------------------------------------------------------\n");

            return sb;
        }

        // Utility method to write the order
        public static void WriteOrder(StringBuilder sb)
        {
            // Pg528. Writing to a sequential access text file
            // declare a delimiter, an output text file, and some arrays
            const string FILENAME = "OrderData.txt";

            if (File.Exists(FILENAME))
            {
                try
                {
                    // Use the File.WriteLine method to write the StringBuilder line. 
                    //  It creates a FileStream object, associates it with a StreamWriter
                    //  and later, closes the file. 

                    // Write to order file
                    File.WriteAllText(FILENAME, sb.ToString());

                }
                catch (Exception)
                {
                    //  throws NotEmplemented
                }
                finally
                {
                    //  the File.WriteAllLines method also, closed the file.
                }
            }
        }

        private void nudQty_Leave(object sender, EventArgs e)
        {
            //  throws NotEmplemented
            // - Display a message for orders above a certain quantity
        }

        private void grpCustomer_Leave(object sender, EventArgs e)
        {
            ValidateCustomerData(order);
        }

        private void nudExpMM_Click(object sender, EventArgs e)
        {
            nudCcExpMM.BringToFront();
        }

        private void nudExpYYYY_Click(object sender, EventArgs e)
        {
            nudCcExpYYYY.BringToFront();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            //  throws NotEmplemented
        }

        private void clbBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            //  throws NotEmplemented
        }

        private void cboCustomer_Click(object sender, EventArgs e)
        {
            // Get database records of customers
            //getDatabaseRecords();
        }

        private void btnCustomerEdit_Click(object sender, EventArgs e)
        {
            // Enable the controls for editing customer data
            EnableCustomerEditing();
        }

        private void btnCustomerAdd_Click(object sender, EventArgs e)
        {
            // Initialize the controls for user input
            InitializeCustomerEditing();

            // Enable the controls for editing customer data
            EnableCustomerEditing();
            btnCustomerSave.Enabled = false;  // Override till validated
            txtFirstName.Focus();
        }

        private void nudCcExpMM_MouseClick(object sender, MouseEventArgs e)
        {
            nudCcExpMM.Enabled = true;
            nudCcExpYYYY.Enabled = true;
        }

        private void btnCustomerSave_Click(object sender, EventArgs e)
        {
            // Instantiate a new customer to store the form's control data
            ContactDetails customer = new ContactDetails();
            int cboCustomerItem = 0;

            // Update the list item with the customer's data from the form controls
            customer.LastName = txtLastName.Text;
            customer.FirstName  = txtFirstName.Text;
            customer.Address    = txtAddress.Text;
            customer.City       = txtCity.Text;
            customer.State      = cboState.Text;
            customer.ZipCode    = txtZipCode.Text;
            customer.Phone      = txtPhone.Text;
            customer.Email      = txtEmail.Text;
            customer.CardType   = cboCreditCard.Text;
            customer.CardNumber = txtCcNumber.Text;

            // Update the customer's Credit Card Expiration Date from the form controls
            if (nudCcExpMM.Value > 9)
            {
                customer.CardExpire = (nudCcExpMM.Value.ToString() + "/" + nudCcExpYYYY.Value.ToString().Substring(2, 2));
            }
            else
            {
                customer.CardExpire = ("0" + nudCcExpMM.Value.ToString() + "/" + nudCcExpYYYY.Value.ToString().Substring(2, 2));
            }

            // Determine if saving edits 
            //  for updating a record or for creating an additional record 
            if (cboCustomer.SelectedIndex >= 0)  // not -1 so this is updating an existing record
            {
                // Update customer data by updating a record in the database
                DatabaseProcessing.UpdateCustomerData(customer);
            }
            else  // is negative so this is adding a new record
            {
                // Add customer data by inserting a record into the database
                DatabaseProcessing.AddCustomerData(customer);
            }

            // Refresh the customer combobox
            // Get database records of customers
            cboCustomer.BeginUpdate();
            cboCustomer.Items.Clear();
            cboCustomer.Items.AddRange(DatabaseProcessing.ReadListData().ToArray());
            cboCustomer.SelectedText = txtLastName.Text;
            cboCustomer.Refresh();
            cboCustomer.Focus();

            // Disable the controls for editing customer data
            DisableCustomerEditing();
        }

        private void btnCustomerCancel_Click(object sender, EventArgs e)
        {
            // Disable the controls for editing customer data
            InitializeCustomerEditing();
            DisableCustomerEditing();
        }

        // Initialize values in the controls for adding or canceling new customer data
        private void InitializeCustomerEditing()
        {
            cboCustomer.SelectedIndex = -1;
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            cboState.Text = null;
            txtZipCode.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            cboCreditCard.Text = "";
            txtCcName.Text = "";
            txtCcNumber.Text = "";
            nudCcExpMM.Value = 06;
            nudCcExpYYYY.Value = 2014;
        }

        // Enable the controls for editing customer data
        private void EnableCustomerEditing()
        {
            txtFirstName.Enabled = true;
            txtLastName.Enabled = true;
            txtAddress.Enabled = true;
            txtCity.Enabled = true;
            cboState.Enabled = true;
            txtZipCode.Enabled = true;
            txtPhone.Enabled = true;
            txtEmail.Enabled = true;
            cboCreditCard.Enabled = true;
            txtCcName.Enabled = true;
            txtCcNumber.Enabled = true;
            nudCcExpMM.Enabled = true;
            nudCcExpYYYY.Enabled = true;
            txtCcCvc.Enabled = true;
            btnCustomerEdit.Enabled = false;
            btnCustomerAdd.Enabled = false;
            btnCustomerSave.Enabled = true;
            btnCustomerCancel.Enabled = true;
        }

        // Disable the controls for editing customer data
        private void DisableCustomerEditing()
        {
            txtFirstName.Enabled = false;
            txtLastName.Enabled = false;
            txtAddress.Enabled = false;
            txtCity.Enabled = false;
            cboState.Enabled = false;
            txtZipCode.Enabled = false;
            txtPhone.Enabled = false;
            txtEmail.Enabled = false;
            cboCreditCard.Enabled = false;
            txtCcName.Enabled = false;
            txtCcNumber.Enabled = false;
            nudCcExpMM.Enabled = false;
            nudCcExpYYYY.Enabled = false;
            txtCcCvc.Enabled = false;
            btnCustomerEdit.Enabled = true;
            btnCustomerAdd.Enabled = true;
            btnCustomerSave.Enabled = false;
            btnCustomerCancel.Enabled = false;
        }
    }
}
