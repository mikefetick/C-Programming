COM 270 - Project 1 Status:

I am getting exhausted trying to get the combobox for the Book Title (cboTitle) to populate with data between the BookData.cs (ArrayList booklist) � to � the Form1.cs (Array books) � to � AddRange<List>. 

I�ll submit what I have for now and keep working on it until the deadline.
I have other assignments that are due also.

Mike Fetick
