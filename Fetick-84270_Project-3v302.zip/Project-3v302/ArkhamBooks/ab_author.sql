-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2013 at 08:56 PM
-- Server version: 5.0.95
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pm75280`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_author`
--

CREATE TABLE IF NOT EXISTS `ab_author` (
  `AuthorId` int(11) NOT NULL auto_increment,
  `LastName` varchar(20) NOT NULL,
  `FirstName` varchar(15) default NULL,
  PRIMARY KEY  (`AuthorId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `ab_author`
--

INSERT INTO `ab_author` (`AuthorId`, `LastName`, `FirstName`) VALUES
(1, 'King', 'Stephen'),
(2, 'Ritchie', 'Dennis'),
(3, 'Wu', 'Norbert'),
(4, 'Peters', 'Elizabeth'),
(5, 'Stevenson', 'James'),
(6, 'Kinkade', 'Thomas'),
(7, 'Guiberson', 'Brenda'),
(8, 'Braasch', 'Barbara'),
(9, 'Cooper', 'Basil'),
(10, 'Campbell', 'Ramsey'),
(11, 'Harvey', 'John'),
(12, 'Anthony', 'Piers'),
(13, 'Brooks', 'Terry'),
(14, 'Albert', 'Susan'),
(15, 'Malzberg', 'Barry'),
(16, 'Durbin', 'Federic'),
(17, 'Atherton', 'Nancy'),
(18, 'Childs', 'Laura'),
(19, 'Stewart', 'Mary'),
(20, 'Whitney', 'Phyllis'),
(21, 'Holt', 'Victoria'),
(22, 'Zak', 'Diane'),
(23, 'Huddleston', 'James'),
(24, 'Dembski-Bowden', 'Aaron');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
