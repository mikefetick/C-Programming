﻿namespace PickLarger
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.lblPromptLine1 = new System.Windows.Forms.Label();
            this.lblPromptLine3 = new System.Windows.Forms.Label();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblPromptLine2 = new System.Windows.Forms.Label();
            this.lblNo1 = new System.Windows.Forms.Label();
            this.lblNo2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(50, 100);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(150, 100);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblPromptLine1
            // 
            this.lblPromptLine1.AutoSize = true;
            this.lblPromptLine1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromptLine1.Location = new System.Drawing.Point(35, 9);
            this.lblPromptLine1.Name = "lblPromptLine1";
            this.lblPromptLine1.Size = new System.Drawing.Size(211, 17);
            this.lblPromptLine1.TabIndex = 2;
            this.lblPromptLine1.Text = "There are two randum numbers.";
            // 
            // lblPromptLine3
            // 
            this.lblPromptLine3.AutoSize = true;
            this.lblPromptLine3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromptLine3.Location = new System.Drawing.Point(21, 43);
            this.lblPromptLine3.Name = "lblPromptLine3";
            this.lblPromptLine3.Size = new System.Drawing.Size(236, 17);
            this.lblPromptLine3.TabIndex = 3;
            this.lblPromptLine3.Text = "pick a button to indicate your guess:";
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(70, 140);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(52, 17);
            this.lblResult.TabIndex = 4;
            this.lblResult.Text = "Result:";
            // 
            // lblPromptLine2
            // 
            this.lblPromptLine2.AutoSize = true;
            this.lblPromptLine2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPromptLine2.Location = new System.Drawing.Point(47, 26);
            this.lblPromptLine2.Name = "lblPromptLine2";
            this.lblPromptLine2.Size = new System.Drawing.Size(171, 17);
            this.lblPromptLine2.TabIndex = 5;
            this.lblPromptLine2.Text = "Guess which is larger and";
            // 
            // lblNo1
            // 
            this.lblNo1.AutoSize = true;
            this.lblNo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNo1.Location = new System.Drawing.Point(70, 70);
            this.lblNo1.Name = "lblNo1";
            this.lblNo1.Size = new System.Drawing.Size(24, 26);
            this.lblNo1.TabIndex = 4;
            this.lblNo1.Text = "#";
            // 
            // lblNo2
            // 
            this.lblNo2.AutoSize = true;
            this.lblNo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNo2.Location = new System.Drawing.Point(170, 70);
            this.lblNo2.Name = "lblNo2";
            this.lblNo2.Size = new System.Drawing.Size(24, 26);
            this.lblNo2.TabIndex = 4;
            this.lblNo2.Text = "#";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lblPromptLine2);
            this.Controls.Add(this.lblNo2);
            this.Controls.Add(this.lblNo1);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblPromptLine3);
            this.Controls.Add(this.lblPromptLine1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblPromptLine1;
        private System.Windows.Forms.Label lblPromptLine3;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblPromptLine2;
        private System.Windows.Forms.Label lblNo1;
        private System.Windows.Forms.Label lblNo2;
    }
}

