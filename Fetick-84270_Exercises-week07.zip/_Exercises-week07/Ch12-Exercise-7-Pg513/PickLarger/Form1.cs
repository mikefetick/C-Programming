﻿/* School: Coleman University, CIS/AppDev Game 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Seven - Chapter twelve, Exercise 7 (Page 513)
 * Date: 16 February 2014
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PickLarger
{
    delegate void MethodReferencingDelegateObject(int[] arrayName);
    public partial class Form1 : Form
    {
        private int[] intArray1 = new int[100];
        private int[] intArray2 = new int[100];
        private int guessCount = 0;
        private int correctCount = 0;
        private int incorrectCount = 0;
        private string result;

        public Form1()
        {
            MethodReferencingDelegateObject firstDelagate, secondDelagate;
            // Delegate object with a reference to a method to InitializeValues
            firstDelagate = new MethodReferencingDelegateObject(InitializeValues);
            secondDelagate = new MethodReferencingDelegateObject(InitializeValues);
            UseDelegate(firstDelagate, intArray1);
            UseDelegate(secondDelagate, intArray2);

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // Private accessibility avoids a COMPILE ERROR - Inconsistent accessibility
        private void UseDelegate(MethodReferencingDelegateObject mrdo, int[] arrayName)
        {
            mrdo(arrayName);
        }

        public void InitializeValues(int[] arrayName)
        {
            Random rand = new Random();
            for (int i=0; i < arrayName.Length; ++i)
            {
                // This didn't generate different values for the two arrays
                // though debugging showed the delegate method calls worked!
                //arrayName[i] = rand.Next(101);   
                // so this is hard-coded... and it works
                intArray1[i] = rand.Next(101);
                intArray2[i] = rand.Next(101);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Array1isLarger();
            DisplayResult();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Array2isLarger();
            DisplayResult();
        }

        public void Array1isLarger()
        {
            if (intArray1[guessCount] > intArray2[guessCount])
            {
                result = "Result: Correct";
                result += "\nOne: " + intArray1[guessCount] + " is larger";
                correctCount++;
            }
            else
            {
                result = "Result: Incorrect";
                result += "\nTwo: " + intArray2[guessCount] + " is larger";
                incorrectCount++;
            }
        }

        public void Array2isLarger()
        {
            if (intArray2[guessCount] > intArray1[guessCount])
            {
                result = "Result: Correct";
                result += "\nTwo: " + intArray2[guessCount] + " is larger";
                correctCount++;
            }
            else
            {
                result = "Result: Incorrect";
                result += "\nOne: "+ intArray1[guessCount] +" is larger";
                incorrectCount++;
            }
        }

        public void DisplayResult()
        {
            result += "\n\nCorrect Guesses: " + correctCount;
            result += "\nIncorrect Guesses: " + incorrectCount;
            result += "\nTotal Guesses: " + (guessCount + 1);
            lblResult.Text = result;
            
            // Display the numbers
            lblNo1.Text = (intArray1[guessCount]).ToString();
            lblNo2.Text = (intArray2[guessCount]).ToString();

            // Increment the array indices, upto 100 guesses then reset to zero
            if (guessCount < 101)
            {
                guessCount++;
            }
            else
            {
                guessCount = 0;
            }
        }
    }
}
