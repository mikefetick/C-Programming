﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick
 * Chapter One, Exercise 4
 * Date: 09 January 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// The schema to group classes of a Name
namespace Name
{
    class Name
    {
        static void Main(string[] args)
        {
            //using System and standard out is default
            Console.WriteLine("Michael");
            Console.ReadKey();
        }
    }
}
