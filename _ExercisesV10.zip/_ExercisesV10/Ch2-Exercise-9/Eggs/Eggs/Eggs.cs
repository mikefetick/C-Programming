﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick
 * Chapter Two, Exercise 9
 * Date: 09 January 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eggs
{
    class Eggs
    {
        static void Main(string[] args)
        {
            // Declare four variables for the number of eggs 
            // produced in a month by each of four chickens
            int chickenAlfred = 15;
            int chickenBaldy = 9;
            int chickenClucker = 12;
            int chickenDumbmy = 16;
            // Declare constants and variables to sum and display the egg count
            const int EGGS_PER_DOZEN = 12;
            int eggsTotal;
            int dozensOfEggs;
            int eggsRemaining;

            // Sum the eggs into dozens and remaining eggs
            eggsTotal = chickenAlfred + chickenBaldy + chickenClucker + chickenDumbmy;
            dozensOfEggs = eggsTotal / EGGS_PER_DOZEN;
            eggsRemaining = eggsTotal % EGGS_PER_DOZEN;

            // Display the total in dozens and remaining eggs
            Console.WriteLine("The total of {0} eggs is {1} dozen and {2} eggs.", eggsTotal, dozensOfEggs, eggsRemaining);
            Console.ReadKey();
        }
    }
}
