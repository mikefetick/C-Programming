-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2013 at 08:58 PM
-- Server version: 5.0.95
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pm75280`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_publisher`
--

CREATE TABLE IF NOT EXISTS `ab_publisher` (
  `PubId` int(11) NOT NULL auto_increment,
  `Name` varchar(30) NOT NULL,
  `Address` varchar(30) default NULL,
  `City` varchar(20) default NULL,
  `State` char(2) default NULL,
  `Zip` varchar(10) default NULL,
  `Contact` varchar(20) default NULL,
  PRIMARY KEY  (`PubId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `ab_publisher`
--

INSERT INTO `ab_publisher` (`PubId`, `Name`, `Address`, `City`, `State`, `Zip`, `Contact`) VALUES
(1, 'Prentice Hall', '345 Pine', 'Englewood Cliffs', 'NJ', '07632', NULL),
(2, 'Atheneum Books', '1230 Avenue of the Americas', 'New York', 'NY', '10020', 'Debbie Johnson'),
(3, 'Mysterious Press', '386 Park Avenue South', 'New York', 'NY', '10016', 'Kim Richards'),
(4, 'Greenwillow Books', '67 Park Avenue West', 'New York', 'NY', '10023', 'Jody'),
(5, 'Henry Holt and Company', '115 West 18th Street', 'New York', 'NY', '10111', 'John Wagner'),
(6, 'Sunset Books', 'One Sunset Plaza', 'Menlo Park', 'CA', '93547', 'Jim'),
(7, 'Thomas Nelson Publishers', '22 Twain Place', 'Nashville', 'TN', '65789', 'Bob'),
(8, 'Arkham House Publishers', 'P.O. Box 546', 'Sauk City', 'WI', '53583', 'August D'),
(9, 'Berkley Publisher Group', '1289 2nd Street', 'New York', 'NY', '10247', 'John'),
(10, 'Del Rey', '258 Broadway', 'New York', 'NY', '10023', NULL),
(11, 'Tor Fantasy', '2789 First Ave.', 'San Francisco', 'CA', '95687', 'Fred'),
(12, 'Viking Press', '26 Nordic Way', 'New York', 'NY', '10054', NULL),
(13, 'Prime Crime', '1 Mystery Lane', 'Sleepy Hollow', 'NY', '11203', 'Katrina'),
(14, 'Fawcett Books', 'One Park Place', 'New York', 'NY', '10029', 'Andy'),
(15, 'Harper Torch', 'Two Firebrand Lane', 'Chicago', 'IL', '68974', 'Mary'),
(16, 'Thomson Learning', 'One Technology Park', 'Boston', 'MA', '02210', 'Jennifer'),
(17, 'Apress', '2560 Ninth Street, Suite 219', 'Berkeley', 'CA', '94710', 'James'),
(18, 'White Wolf Publishing', '1554 Litton Drive', 'Stone Mountain', 'GA', '30083', 'Bob');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
