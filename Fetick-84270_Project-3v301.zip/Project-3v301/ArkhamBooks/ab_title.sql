-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2013 at 08:58 PM
-- Server version: 5.0.95
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pm75280`
--

-- --------------------------------------------------------

--
-- Table structure for table `ab_title`
--

CREATE TABLE IF NOT EXISTS `ab_title` (
  `Isbn` varchar(13) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `PubId` int(11) default NULL,
  `Type` varchar(15) default NULL,
  `QtyOnHand` int(11) default NULL,
  `Cost` decimal(6,2) default NULL,
  `SellingPrice` decimal(6,2) default NULL,
  PRIMARY KEY  (`Isbn`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ab_title`
--

INSERT INTO `ab_title` (`Isbn`, `Title`, `PubId`, `Type`, `QtyOnHand`, `Cost`, `SellingPrice`) VALUES
('0131103628', 'The C Programming Language', 1, 'Programming', 6, 30.00, 39.95),
('0140296301', 'Aunt Dimity''s Christmas', 12, 'Mystery', 4, 4.00, 5.95),
('0345345991', 'Crewel Lye', 10, 'Fantasy', 4, 4.00, 7.50),
('0345453751', 'The Sword of Shannara Trilogy', 10, 'Fantasy', 10, 12.00, 24.95),
('0345470389', 'On the Night of the Seventh Moon', 14, 'Romance', 1, 5.00, 6.95),
('0376050187', 'Back Roads and Hidden Places', 6, 'Travel', 2, 10.00, 12.50),
('0380820749', 'The Ivy Tree', 15, 'Gothic', 4, 4.00, 6.99),
('0380820765', 'Nine Coaches Waiting', 15, 'Gothic', 6, 4.00, 5.99),
('0385006009', 'The Legend of the Seventh Virgin', 14, 'Romance', 5, 10.00, 15.98),
('0425140989', 'Thyme of Death', 9, 'Mystery', 4, 3.50, 6.95),
('0425144062', 'Witches'' Bane', 9, 'Mystery', 5, 3.50, 6.95),
('042519129X', 'The English Breakfast Murder', 13, 'Mystery', 4, 4.25, 6.95),
('0425193993', 'A Dilly of a Death', 9, 'Mystery', 2, 9.00, 16.95),
('0425198138', 'The Jasmine Moon Murder', 13, 'Mystery', 7, 10.00, 16.95),
('0445406518', 'Crocodile on the Sandbank', 3, 'Mystery', 10, 4.00, 6.75),
('0446363383', 'The Last Camel Died at Noon', 3, 'Mystery', 4, 4.00, 6.75),
('0449214222', 'A Walk in Wolf Wood', 15, 'Gothic', 7, 10.00, 14.95),
('0449242463', 'Snowfire', 14, 'Romance', 8, 5.00, 7.50),
('0619016620', 'Programming with Visual Basic .Net', 16, 'Programming', 5, 15.00, 26.00),
('0670032786', 'Aunt Dimity Snowbound', 12, 'Mystery', 10, 4.00, 5.95),
('0688010377', 'Airs Above the Ground', 15, 'Gothic', 2, 5.00, 7.95),
('0688092101', 'Brrr!', 4, 'Children', 4, 4.00, 5.25),
('0689318960', 'A City Under the Sea', 2, 'Children', 10, 4.00, 4.95),
('0785269606', 'A Village Christmas', 7, 'Art', 23, 21.00, 24.95),
('0805015825', 'Winter Wheat', 5, 'Children', 0, 3.50, 5.95),
('0812574990', 'Up in a Heaval', 11, 'Fantasy', 9, 5.00, 7.50),
('0870541757', 'Dragonfly', 8, 'Fantasy', 8, 12.00, 22.75),
('0870541781', 'In The Stone House', 8, 'Science Fiction', 2, 20.00, 32.50),
('0870541811', 'The Cleansing', 8, 'Horror', 7, 27.00, 32.50),
('1878252186', 'Shadows over Innsmouth', 8, 'Horror', 20, 27.00, 29.95),
('1878252402', 'Whispers in the Night', 8, 'Horror', 2, 30.00, 34.50),
('9781558464903', 'World of Darkness: Book of Spirits', 18, 'Modern Gaming', 7, 16.00, 26.95),
('9781558464910', 'World of Darkness: Asylum', 18, 'Modern Gaming', 5, 16.00, 26.95),
('9781595097774', 'Beginning C# 2005 Databases', 17, 'Programming', 10, 28.00, 39.99);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
