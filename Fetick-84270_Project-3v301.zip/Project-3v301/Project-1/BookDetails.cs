﻿/* School: Coleman University, CIS/AppDev Program 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Project 1 - Student Handbook (Pages 19-20)
 * Date: 18 January 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Project_1
{
    public class BookDetails : IComparable<BookDetails>
    {
        public BookDetails() { }
        // Constructor for the Book object
        public BookDetails(string isbn, string title, string author, decimal price)
        {
            Isbn = isbn;
            Title = title;
            Author = author;
            Price = price;
        }
        // Properties of the Book object
        private string isbn;
        public string Isbn
        {
            get { return isbn; }
            set { isbn = value; }
        }
        private string title;
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        private string author;
        public string Author
        {
            get { return author; }
            set { author = value; }
        }
        private decimal price;
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }
        // Implement the IComparable interface to override the CompareTo method
        //   with a comparison of the Book's Title property
        public int CompareTo(BookDetails obj)
        {
            int returnVal;

            // If comparing just the Title, simply do...
            //   returnVal = this.Title.CompareTo(temp.Title);
            // otherwise, 
            // for more comparisons, do the verbose way like this...
            if (this.Title.CompareTo(obj.Title) > 0)
            { returnVal = 1; }
            else
                if (this.Title.CompareTo(obj.Title) == 0)
                { returnVal = 0; }
                else
                { returnVal = -1; }

            return returnVal;
        }

        public override string ToString()
        {
            return this.Title;
        }
    }
}
