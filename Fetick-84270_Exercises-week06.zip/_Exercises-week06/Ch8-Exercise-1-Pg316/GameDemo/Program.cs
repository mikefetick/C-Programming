﻿/* School: Coleman University, CIS/AppDev Game 
 * Course: COM270A-0114 C# Programming I (Abel) 005
 * Student: Michael Fetick, 84270
 * Assignment: Week Six - Chapter Eight, Exercise 1 (Page 316)
 * Date: 12 February 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameDemo
{
    class GameDemo
    {
        static void Main(string[] args)
        {
            Game RussianRoulette = new Game();
            RussianRoulette.Name = "Russian Roulette";
            RussianRoulette.MaxPlayers = 7;

            GameWithTimeLimit RushingRussianRoulette = new GameWithTimeLimit();
            RushingRussianRoulette.Name = "Rushing Russian Roulette";
            RushingRussianRoulette.MaxPlayers = 6;
            RushingRussianRoulette.TimeLimitMinutes = 1;

            Console.WriteLine("\n  Demonstrate the methods of the base class, Game\n");
            Console.WriteLine("    " + RussianRoulette.ToString());

            Console.WriteLine("\n  Demonstrate the methods of the child class, GameWithTimeLimit\n");
            Console.WriteLine("    " + RushingRussianRoulette.ToString());

            // Prompt the user to quit the program and close the window shell
            Console.Write("\n  Thank you. It's your turn...");
            Console.ReadKey();
            Console.WriteLine(""); // A clean exit.
        }
    }

    class Game
    {
        protected string name;
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        protected int maxPlayers;
        public int MaxPlayers
        {
            get { return maxPlayers; }
            set { maxPlayers = value; }
        }
        public string ToString()
        {
            return ("RussianRoulette.ToString()\n      " + GetType() + ": " + Name
                  + ",\n      Maximum number of players: " + maxPlayers + "\n");
        }
    }
    class GameWithTimeLimit : Game
    {
        private int timeLimitMinutes;
        public int TimeLimitMinutes
        {
            get { return timeLimitMinutes; }
            set { timeLimitMinutes = value; }
        }
        public string ToString()
        {
            return ("RushingRussianRoulette.ToString()\n      " + GetType() + ": " + Name 
                  + ",\n      Maximum number of players: " + maxPlayers
                  + ",\n      Time limit: " + timeLimitMinutes + " min(s)\n");
        }
    }
}
